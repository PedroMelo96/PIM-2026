// =========================================================
// CONFIGURAÇÃO
// =========================================================
const API_RELATORIO = "https://localhost:7128/api/Relatorio";

// =========================================================
// USUÁRIO LOGADO E TOKEN
// =========================================================
const NOME_USUARIO = localStorage.getItem("nome_usuario") || "Usuário";
const ID_USUARIO_LOGADO = localStorage.getItem("id_usuario");
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// Se não existe usuário ou token, volta para o login.
if (!ID_USUARIO_LOGADO || !TOKEN_JWT) {
    window.location.href = "login.html";
}

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }
    
    if (resposta.status === 403) {
        alert("Você não tem permissão para realizar esta ação.");
        throw new Error("Acesso negado.");
    }

    return resposta;
}

// =========================================================
// RELATÓRIO ATUAL
// =========================================================
let relatorioAtual = null;

// =========================================================
// DADOS
// =========================================================
let dadosRelatorio = [];

// =========================================================
// CONFIGURAÇÃO DOS 6 RELATÓRIOS
// =========================================================
const relatorios = {
    pagamento: {
        titulo: "Vendas por forma de pagamento",
        descricao: "Consulte quanto foi vendido em cada forma de pagamento.",
        endpoint: "/vendas-pagamento",
        tituloTabela: "Vendas por forma de pagamento"
    },
    produto: {
        titulo: "Vendas por produto",
        descricao: "Consulte a quantidade e o valor vendido de cada produto.",
        endpoint: "/vendas-produtos",
        tituloTabela: "Vendas por produto"
    },
    diario: {
        titulo: "Vendas diárias",
        descricao: "Consulte o total de vendas realizado em cada dia.",
        endpoint: "/vendas-diarias",
        tituloTabela: "Vendas por dia"
    },
    "mais-vendidos": {
        titulo: "Produtos mais vendidos",
        descricao: "Veja quais produtos possuem maior quantidade de vendas.",
        endpoint: "/produtos-mais-vendidos",
        tituloTabela: "Ranking dos produtos mais vendidos"
    },
    classe: {
        titulo: "Produtos mais vendidos por classe",
        descricao: "Veja os produtos mais vendidos separados por classe.",
        endpoint: "/produtos-por-classe",
        tituloTabela: "Produtos vendidos por classe"
    },
    estornadas: {
        titulo: "Vendas estornadas",
        descricao: "Consulte as vendas que foram estornadas ou canceladas.",
        endpoint: "/vendas-estornadas",
        tituloTabela: "Vendas estornadas"
    }
};

// =========================================================
// INICIALIZAÇÃO
// =========================================================
document.addEventListener("DOMContentLoaded", function () {
    const usuario = document.getElementById("usuarioLogado");

    if (usuario) {
        usuario.textContent = NOME_USUARIO;
    }

    colocarDatasPadrao();
});

// =========================================================
// COLOCAR DATA PADRÃO
// =========================================================
function colocarDatasPadrao() {
    const hoje = new Date();
    const primeiroDia = new Date(hoje.getFullYear(), hoje.getMonth(), 1);

    document.getElementById("dataInicio").value = formatarDataInput(primeiroDia);
    document.getElementById("dataFim").value = formatarDataInput(hoje);
}

// =========================================================
// FORMATAR DATA PARA INPUT
// =========================================================
function formatarDataInput(data) {
    const ano = data.getFullYear();
    const mes = String(data.getMonth() + 1).padStart(2, "0");
    const dia = String(data.getDate()).padStart(2, "0");

    return `${ano}-${mes}-${dia}`;
}

// =========================================================
// ABRIR RELATÓRIO
// =========================================================
function abrirRelatorio(tipo) {
    const relatorio = relatorios[tipo];

    if (!relatorio) {
        return;
    }

    // Guarda qual relatório está aberto
    relatorioAtual = tipo;

    // Esconde menu
    document.getElementById("menuRelatorios").style.display = "none";

    // Mostra relatório
    document.getElementById("areaRelatorio").style.display = "block";

    // Atualiza título
    document.getElementById("tipoRelatorio").textContent = "RELATÓRIO";
    document.getElementById("tituloRelatorio").textContent = relatorio.titulo;
    document.getElementById("descricaoRelatorio").textContent = relatorio.descricao;
    document.getElementById("tituloTabela").textContent = relatorio.tituloTabela;

    // Limpa tabela
    document.getElementById("cabecalhoTabela").innerHTML = "";
    document.getElementById("corpoTabela").innerHTML = `
        <tr>
            <td>
                Clique em "Gerar relatório" para consultar os dados.
            </td>
        </tr>
    `;

    // Zera resumo
    limparResumo();
}

// =========================================================
// VOLTAR PARA MENU
// =========================================================
function voltarRelatorios() {
    relatorioAtual = null;
    dadosRelatorio = [];

    document.getElementById("areaRelatorio").style.display = "none";
    document.getElementById("menuRelatorios").style.display = "block";
}

// =========================================================
// VOLTAR PARA MENU PRINCIPAL
// =========================================================
function voltarMenu() {
    window.history.back();
}

// =========================================================
// GERAR RELATÓRIO ATUAL
// =========================================================
async function gerarRelatorioAtual() {
    if (!relatorioAtual) {
        alert("Selecione um relatório.");
        return;
    }

    const inicio = document.getElementById("dataInicio").value;
    const fim = document.getElementById("dataFim").value;

    if (!inicio || !fim) {
        alert("Informe a data inicial e a data final.");
        return;
    }

    if (inicio > fim) {
        alert("A data inicial não pode ser maior que a data final.");
        return;
    }

    const configuracao = relatorios[relatorioAtual];

    try {
        const endpoint = `${configuracao.endpoint}?inicio=${inicio}&fim=${fim}`;

        const resposta = await fetchComToken(API_RELATORIO + endpoint);

        if (!resposta.ok) {
            let mensagem = "Erro ao gerar relatório.";
            try {
                const erro = await resposta.json();
                mensagem = erro.mensagem || mensagem;
            } catch {}
            throw new Error(mensagem);
        }

        dadosRelatorio = await resposta.json();

        // Mostra o relatório correto
        mostrarRelatorio();

    } catch (erro) {
        console.error(erro);
        alert(erro.message || "Erro ao gerar relatório.");
    }
}

// =========================================================
// MOSTRAR RELATÓRIO
// =========================================================
function mostrarRelatorio() {
    switch (relatorioAtual) {
        case "pagamento":
            mostrarPagamento();
            break;
        case "produto":
            mostrarProduto();
            break;
        case "diario":
            mostrarDiario();
            break;
        case "mais-vendidos":
            mostrarMaisVendidos();
            break;
        case "classe":
            mostrarClasse();
            break;
        case "estornadas":
            mostrarEstornadas();
            break;
    }
}

// =========================================================
// RELATÓRIO POR PAGAMENTO
// =========================================================
function mostrarPagamento() {
    configurarCabecalho(["Forma de pagamento", "Quantidade de vendas", "Valor total"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(3);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map(item => `
        <tr>
            <td><strong>${item.formaPagamento}</strong></td>
            <td>${item.quantidadeVendas}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.reduce((total, item) => total + Number(item.quantidadeVendas), 0);
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(dadosRelatorio.length, quantidade, valor);
}

// =========================================================
// RELATÓRIO POR PRODUTO
// =========================================================
function mostrarProduto() {
    configurarCabecalho(["Código", "Produto", "Quantidade vendida", "Valor total"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(4);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map(item => `
        <tr>
            <td>#${item.idProduto}</td>
            <td><strong>${item.nomeProduto}</strong></td>
            <td>${item.quantidadeVendida}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.reduce((total, item) => total + Number(item.quantidadeVendida), 0);
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(dadosRelatorio.length, quantidade, valor);
}

// =========================================================
// RELATÓRIO DIÁRIO
// =========================================================
function mostrarDiario() {
    configurarCabecalho(["Data", "Quantidade de vendas", "Valor total"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(3);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map(item => `
        <tr>
            <td><strong>${formatarData(item.data)}</strong></td>
            <td>${item.quantidadeVendas}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.reduce((total, item) => total + Number(item.quantidadeVendas), 0);
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(dadosRelatorio.length, quantidade, valor);
}

// =========================================================
// PRODUTOS MAIS VENDIDOS
// =========================================================
function mostrarMaisVendidos() {
    configurarCabecalho(["Posição", "Produto", "Quantidade vendida", "Valor total"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(4);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map((item, index) => `
        <tr>
            <td><strong>${index + 1}º</strong></td>
            <td>${item.nomeProduto}</td>
            <td>${item.quantidadeVendida}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.reduce((total, item) => total + Number(item.quantidadeVendida), 0);
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(dadosRelatorio.length, quantidade, valor);
}

// =========================================================
// PRODUTOS POR CLASSE
// =========================================================
function mostrarClasse() {
    configurarCabecalho(["Classe", "Produto", "Quantidade vendida", "Valor total"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(4);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map(item => `
        <tr>
            <td><span class="badge">${item.nomeClasse}</span></td>
            <td><strong>${item.nomeProduto}</strong></td>
            <td>${item.quantidadeVendida}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.reduce((total, item) => total + Number(item.quantidadeVendida), 0);
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(dadosRelatorio.length, quantidade, valor);
}

// =========================================================
// VENDAS ESTORNADAS
// =========================================================
function mostrarEstornadas() {
    configurarCabecalho(["Venda", "Data", "Usuário", "Valor total", "Status"]);
    const tbody = document.getElementById("corpoTabela");

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        mostrarSemDados(5);
        limparResumo();
        return;
    }

    tbody.innerHTML = dadosRelatorio.map(item => `
        <tr>
            <td><strong>#${item.idVenda}</strong></td>
            <td>${formatarData(item.dataVenda)}</td>
            <td>#${item.idUsuario}</td>
            <td>${formatarMoeda(item.valorTotal)}</td>
            <td><span class="badge vermelho-bg">ESTORNADA</span></td>
        </tr>
    `).join("");

    const quantidade = dadosRelatorio.length;
    const valor = dadosRelatorio.reduce((total, item) => total + Number(item.valorTotal), 0);

    atualizarResumo(quantidade, 0, valor);
}

// =========================================================
// CONFIGURAR CABEÇALHO DA TABELA
// =========================================================
function configurarCabecalho(colunas) {
    const thead = document.getElementById("cabecalhoTabela");
    thead.innerHTML = `
        <tr>
            ${colunas.map(coluna => `<th>${coluna}</th>`).join("")}
        </tr>
    `;
}

// =========================================================
// SEM DADOS
// =========================================================
function mostrarSemDados(colspan) {
    document.getElementById("corpoTabela").innerHTML = `
        <tr>
            <td colspan="${colspan}">
                Nenhum registro encontrado para o período informado.
            </td>
        </tr>
    `;
    document.getElementById("contadorRegistros").textContent = "0 registros";
}

// =========================================================
// ATUALIZAR RESUMO
// =========================================================
function atualizarResumo(registros, quantidade, valor) {
    document.getElementById("resumoQuantidade").textContent = registros;
    document.getElementById("resumoItens").textContent = quantidade;
    document.getElementById("resumoValor").textContent = formatarMoeda(valor);
    document.getElementById("contadorRegistros").textContent = `${registros} registro${registros === 1 ? "" : "s"}`;
}

// =========================================================
// LIMPAR RESUMO
// =========================================================
function limparResumo() {
    document.getElementById("resumoQuantidade").textContent = "0";
    document.getElementById("resumoItens").textContent = "0";
    document.getElementById("resumoValor").textContent = "R$ 0,00";
    document.getElementById("contadorRegistros").textContent = "0 registros";
}

// =========================================================
// FORMATAR MOEDA
// =========================================================
function formatarMoeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

// =========================================================
// FORMATAR DATA
// =========================================================
function formatarData(data) {
    if (!data) {
        return "-";
    }

    const valor = new Date(data);
    return valor.toLocaleDateString("pt-BR");
}

// =========================================================
// FORMATAR DATA DO INPUT
// Evita problemas de fuso horário
// =========================================================
function formatarDataInputBR(data) {
    if (!data) {
        return "-";
    }

    const partes = data.split("-");
    if (partes.length !== 3) {
        return data;
    }

    return `${partes[2]}/${partes[1]}/${partes[0]}`;
}

// =========================================================
// EXPORTAR PDF
// =========================================================
function exportarPDF() {
    if (!relatorioAtual) {
        alert("Selecione um relatório.");
        return;
    }

    if (!dadosRelatorio || dadosRelatorio.length === 0) {
        alert("Gere o relatório antes de exportar o PDF.");
        return;
    }

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF("p", "mm", "a4");
    const configuracao = relatorios[relatorioAtual];
    const inicio = document.getElementById("dataInicio").value;
    const fim = document.getElementById("dataFim").value;

    // =====================================================
    // CABEÇALHO
    // =====================================================
    pdf.setFontSize(18);
    pdf.text("PIM - RELATÓRIO", 14, 18);

    pdf.setFontSize(13);
    pdf.text(configuracao.titulo, 14, 26);

    pdf.setFontSize(9);
    pdf.text(`Período: ${formatarDataInputBR(inicio)} até ${formatarDataInputBR(fim)}`, 14, 33);
    pdf.text(`Operador: ${NOME_USUARIO}`, 14, 39);

    // =====================================================
    // CABEÇALHO E DADOS DO PDF
    // =====================================================
    let cabecalho = [];
    let corpo = [];

    switch (relatorioAtual) {
        case "pagamento":
            cabecalho = ["Forma de pagamento", "Vendas", "Valor total"];
            corpo = dadosRelatorio.map(item => [
                item.formaPagamento,
                item.quantidadeVendas,
                formatarMoeda(item.valorTotal)
            ]);
            break;

        case "produto":
            cabecalho = ["Código", "Produto", "Quantidade", "Valor total"];
            corpo = dadosRelatorio.map(item => [
                `#${item.idProduto}`,
                item.nomeProduto,
                item.quantidadeVendida,
                formatarMoeda(item.valorTotal)
            ]);
            break;

        case "diario":
            cabecalho = ["Data", "Quantidade de vendas", "Valor total"];
            corpo = dadosRelatorio.map(item => [
                formatarData(item.data),
                item.quantidadeVendas,
                formatarMoeda(item.valorTotal)
            ]);
            break;

        case "mais-vendidos":
            cabecalho = ["Posição", "Produto", "Quantidade", "Valor total"];
            corpo = dadosRelatorio.map((item, index) => [
                index + 1,
                item.nomeProduto,
                item.quantidadeVendida,
                formatarMoeda(item.valorTotal)
            ]);
            break;

        case "classe":
            cabecalho = ["Classe", "Produto", "Quantidade", "Valor total"];
            corpo = dadosRelatorio.map(item => [
                item.nomeClasse,
                item.nomeProduto,
                item.quantidadeVendida,
                formatarMoeda(item.valorTotal)
            ]);
            break;

        case "estornadas":
            cabecalho = ["Venda", "Data", "Usuário", "Valor", "Status"];
            corpo = dadosRelatorio.map(item => [
                `#${item.idVenda}`,
                formatarData(item.dataVenda),
                `#${item.idUsuario}`,
                formatarMoeda(item.valorTotal),
                "ESTORNADA"
            ]);
            break;
    }

    // =====================================================
    // TABELA PDF
    // =====================================================
    pdf.autoTable({
        startY: 48,
        head: [cabecalho],
        body: corpo,
        theme: "grid",
        styles: { fontSize: 8 },
        headStyles: { fontSize: 8 },
        margin: { left: 14, right: 14 }
    });

    // =====================================================
    // RODAPÉ
    // =====================================================
    const paginaFinal = pdf.internal.getNumberOfPages();

    for (let pagina = 1; pagina <= paginaFinal; pagina++) {
        pdf.setPage(pagina);
        pdf.setFontSize(8);
        pdf.text(`Página ${pagina} de ${paginaFinal}`, 14, 290);
        pdf.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 196, 290, { align: "right" });
    }

    // =====================================================
    // SALVAR
    // =====================================================
    pdf.save(`relatorio-${relatorioAtual}-${inicio}-${fim}.pdf`);
}
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});

// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});