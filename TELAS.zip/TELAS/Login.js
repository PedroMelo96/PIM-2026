console.log("Login.js foi carregado!");

const formulario = document.getElementById("loginForm");

formulario.addEventListener("submit", async function (event) {
    event.preventDefault();

    console.log("CLIQUEI EM ENTRAR!");

    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;
    const mensagem = document.getElementById("mensagem");

    try {
        const resposta = await fetch(
            "https://localhost:7128/api/Usuario/login",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    usuario: usuario,
                    senha: senha
                })
            }
        );

        console.log("Status da API:", resposta.status);

        const resultado = await resposta.json();

        console.log("Resposta:", resultado);

        // ==========================================
        // LOGIN REALIZADO COM SUCESSO
        // ==========================================
        if (resposta.ok) {
            mensagem.textContent = resultado.mensagem;

            console.log("Login realizado!");
            console.log("ID do usuário logado:", resultado.usuario.id_usuario);

            // ==========================================
            // SALVA O TOKEN JWT (NOVIDADE AQUI!)
            // ==========================================
            localStorage.setItem("meuTokenJWT", resultado.token);

            // ==========================================
            // SALVA OS DADOS DO USUÁRIO LOGADO
            // ==========================================
            localStorage.setItem(
                "id_usuario",
                resultado.usuario.id_usuario
            );

            localStorage.setItem(
                "nome_usuario",
                resultado.usuario.nome_usuario
            );

            localStorage.setItem(
                "usuario",
                resultado.usuario.usuario
            );

            localStorage.setItem(
                "id_perfil",
                resultado.usuario.id_perfil
            );

            // ==========================================
            // VAI PARA O SISTEMA
            // ==========================================
            window.location.href = "Pdv.html";

        } else {
            mensagem.textContent = resultado.mensagem;
        }

    } catch (erro) {
        console.error("Erro:", erro);
        mensagem.textContent = "Não foi possível conectar com o servidor.";
    }
});
