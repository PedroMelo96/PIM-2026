// ==========================================
// CONFIGURAÇÃO
// ==========================================
const API_USUARIO = "https://localhost:7128/api/Usuario";
const API_PERFIL = "https://localhost:7128/api/Perfil";

// ==========================================
// TELA INCORPORADA
// ==========================================
if (new URLSearchParams(window.location.search).get("incorporado") === "1") {
    document.body.classList.add("incorporado");
}

// ==========================================
// USUÁRIO LOGADO E TOKEN
// ==========================================
const ID_USUARIO_LOGADO = localStorage.getItem("id_usuario");
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// Se não existe usuário logado ou token, volta para a tela de login.
if (!ID_USUARIO_LOGADO || !TOKEN_JWT) {
    window.parent.location.href = "login.html";
}

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.parent.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou ou você não tem permissão. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.parent.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }
    
    if (resposta.status === 403) {
        alert("Você não tem permissão de Administrador para realizar esta ação.");
        throw new Error("Acesso negado.");
    }

    return resposta;
}

// ==========================================
// MENU HAMBÚRGUER DO PDV
// ==========================================
document.addEventListener("DOMContentLoaded", function () {
    const btnMenuUsuario = document.getElementById("btnMenuUsuario");
    if (btnMenuUsuario) {
        btnMenuUsuario.addEventListener("click", function () {
            const btnMenuPai = window.parent.document.getElementById("btnMenu");
            if (btnMenuPai) {
                btnMenuPai.click();
            }
        });
    }

    // Carregar dados
    carregarUsuarios();
    carregarPerfis();
});

// ==========================================
// ELEMENTOS DA TELA
// ==========================================
const formularioContainer = document.getElementById("formularioContainer");
const formulario = document.getElementById("formUsuario");
const tabelaUsuarios = document.getElementById("tabelaUsuarios");
const mensagem = document.getElementById("mensagem");
const btnNovoUsuario = document.getElementById("btnNovoUsuario");
const btnFecharFormulario = document.getElementById("btnFecharFormulario");
const btnCancelar = document.getElementById("btnCancelar");
const campoBusca = document.getElementById("campoBusca");

// ==========================================
// CARREGAR USUÁRIOS
// ==========================================
async function carregarUsuarios() {
    try {
        const resposta = await fetchComToken(API_USUARIO);

        if (!resposta.ok) {
            throw new Error("Não foi possível carregar os usuários.");
        }

        const usuarios = await resposta.json();
        mostrarUsuarios(usuarios);

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro ao carregar os usuários.", "erro");
    }
}

// ==========================================
// CARREGAR PERFIS
// ==========================================
async function carregarPerfis() {
    try {
        const resposta = await fetchComToken(API_PERFIL);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar os perfis.");
        }

        const perfis = await resposta.json();
        const selectPerfil = document.getElementById("id_perfil");

        selectPerfil.innerHTML = "";

        const opcaoInicial = document.createElement("option");
        opcaoInicial.value = "";
        opcaoInicial.textContent = "Selecione o perfil";
        selectPerfil.appendChild(opcaoInicial);

        perfis.forEach(perfil => {
            const opcao = document.createElement("option");
            opcao.value = perfil.id_perfil;
            opcao.textContent = perfil.perfil;
            selectPerfil.appendChild(opcao);
        });

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro ao carregar os perfis.", "erro");
    }
}

// ==========================================
// MOSTRAR USUÁRIOS NA TABELA
// ==========================================
function mostrarUsuarios(usuarios) {
    tabelaUsuarios.innerHTML = "";

    if (usuarios.length === 0) {
        tabelaUsuarios.innerHTML = `
            <tr>
                <td colspan="6" class="sem-registros">
                    Nenhum usuário cadastrado.
                </td>
            </tr>
        `;
        return;
    }

    usuarios.forEach(usuario => {
        const tr = document.createElement("tr");

        let nomePerfil = "Desconhecido";
        if (usuario.id_perfil == 1) nomePerfil = "Administrador";
        else if (usuario.id_perfil == 2) nomePerfil = "Gerente";
        else if (usuario.id_perfil == 3) nomePerfil = "Operador";

        const ativo = usuario.ativo === "S";
        const statusHtml = ativo
            ? `<span class="status ativo">Ativo</span>`
            : `<span class="status inativo">Inativo</span>`;

        const botaoStatus = ativo
            ? `<button class="btn-acao btn-inativar" onclick="inativarUsuario(${usuario.id_usuario})">Inativar</button>`
            : `<button class="btn-acao btn-ativar" onclick="ativarUsuario(${usuario.id_usuario})">Ativar</button>`;

        tr.innerHTML = `
            <td>${usuario.id_usuario}</td>
            <td>${usuario.nome_usuario}</td>
            <td>${usuario.usuario}</td>
            <td>${nomePerfil}</td>
            <td>${statusHtml}</td>
            <td>
                <div class="acoes">
                    <button class="btn-acao btn-editar" onclick="editarUsuario(${usuario.id_usuario})">Editar</button>
                    ${botaoStatus}
                </div>
            </td>
        `;

        tabelaUsuarios.appendChild(tr);
    });
}

// ==========================================
// ABRIR NOVO USUÁRIO
// ==========================================
btnNovoUsuario.addEventListener("click", () => {
    limparFormulario();
    document.getElementById("tituloFormulario").textContent = "Novo usuário";
    formularioContainer.classList.add("ativo");
});

// ==========================================
// FECHAR FORMULÁRIO
// ==========================================
btnFecharFormulario.addEventListener("click", fecharFormulario);
btnCancelar.addEventListener("click", fecharFormulario);

function fecharFormulario() {
    formularioContainer.classList.remove("ativo");
    limparFormulario();
}

function limparFormulario() {
    formulario.reset();
    document.getElementById("id_usuario").value = "";
}

// ==========================================
// SALVAR USUÁRIO
// ==========================================
formulario.addEventListener("submit", async function (event) {
    event.preventDefault();

    const id = document.getElementById("id_usuario").value;
    const nome_usuario = document.getElementById("nome_usuario").value;
    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;
    const id_perfil = parseInt(document.getElementById("id_perfil").value);

    // ==========================================
    // CADASTRO
    // ==========================================
    if (!id) {
        if (!senha) {
            mostrarMensagem("Digite uma senha para o usuário.", "erro");
            return;
        }

        const dados = {
            nome_usuario: nome_usuario,
            usuario: usuario,
            senha: senha,
            id_perfil: id_perfil,
            ativo: "S"
        };

        try {
            const resposta = await fetchComToken(API_USUARIO, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(dados)
            });

            const resultado = await resposta.json();

            if (!resposta.ok) {
                throw new Error(resultado.mensagem || "Erro ao cadastrar usuário.");
            }

            mostrarMensagem("Usuário cadastrado com sucesso!", "sucesso");
            fecharFormulario();
            carregarUsuarios();

        } catch (erro) {
            console.error(erro);
            mostrarMensagem(erro.message, "erro");
        }
        return;
    }

    // ==========================================
    // ALTERAÇÃO
    // ==========================================
    const dadosAlteracao = {
        nome_usuario: nome_usuario,
        usuario: usuario,
        senha: senha,
        id_perfil: id_perfil,
        ativo: "S"
    };

    try {
        const resposta = await fetchComToken(`${API_USUARIO}/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(dadosAlteracao)
        });

        const resultado = await resposta.json();

        if (!resposta.ok) {
            throw new Error(resultado.mensagem || "Erro ao alterar usuário.");
        }

        mostrarMensagem("Usuário alterado com sucesso!", "sucesso");
        fecharFormulario();
        carregarUsuarios();

    } catch (erro) {
        console.error(erro);
        mostrarMensagem(erro.message, "erro");
    }
});

// ==========================================
// EDITAR USUÁRIO
// ==========================================
async function editarUsuario(id) {
    try {
        const resposta = await fetchComToken(API_USUARIO);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar usuário.");
        }

        const usuarios = await resposta.json();
        const usuario = usuarios.find(u => u.id_usuario === id);

        if (!usuario) {
            mostrarMensagem("Usuário não encontrado.", "erro");
            return;
        }

        document.getElementById("id_usuario").value = usuario.id_usuario;
        document.getElementById("nome_usuario").value = usuario.nome_usuario;
        document.getElementById("usuario").value = usuario.usuario;
        document.getElementById("senha").value = "";
        document.getElementById("id_perfil").value = usuario.id_perfil;
        
        document.getElementById("tituloFormulario").textContent = "Alterar usuário";
        formularioContainer.classList.add("ativo");

        window.scrollTo({ top: 0, behavior: "smooth" });

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro ao carregar usuário.", "erro");
    }
}

// ==========================================
// INATIVAR USUÁRIO
// ==========================================
async function inativarUsuario(id) {
    const confirmar = confirm("Deseja realmente inativar este usuário?");
    if (!confirmar) return;

    try {
        const resposta = await fetchComToken(`${API_USUARIO}/${id}/inativar`, {
            method: "PUT"
        });

        const resultado = await resposta.json();

        if (!resposta.ok) {
            throw new Error(resultado.mensagem || "Erro ao inativar usuário.");
        }

        mostrarMensagem("Usuário inativado com sucesso!", "sucesso");
        carregarUsuarios();

    } catch (erro) {
        console.error(erro);
        mostrarMensagem(erro.message, "erro");
    }
}

// ==========================================
// ATIVAR USUÁRIO
// ==========================================
async function ativarUsuario(id) {
    const confirmar = confirm("Deseja ativar este usuário?");
    if (!confirmar) return;

    try {
        const resposta = await fetchComToken(`${API_USUARIO}/${id}/ativar`, {
            method: "PUT"
        });

        const resultado = await resposta.json();

        if (!resposta.ok) {
            throw new Error(resultado.mensagem || "Erro ao ativar usuário.");
        }

        mostrarMensagem("Usuário ativado com sucesso!", "sucesso");
        carregarUsuarios();

    } catch (erro) {
        console.error(erro);
        mostrarMensagem(erro.message, "erro");
    }
}

// ==========================================
// BUSCA
// ==========================================
campoBusca.addEventListener("input", async function () {
    const texto = campoBusca.value.toLowerCase().trim();

    try {
        const resposta = await fetchComToken(API_USUARIO);
        const usuarios = await resposta.json();

        const filtrados = usuarios.filter(usuario =>
            usuario.nome_usuario.toLowerCase().includes(texto) ||
            usuario.usuario.toLowerCase().includes(texto)
        );

        mostrarUsuarios(filtrados);

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro ao realizar busca.", "erro");
    }
});

// ==========================================
// MENSAGEM
// ==========================================
function mostrarMensagem(texto, tipo) {
    mensagem.textContent = texto;
    mensagem.className = `mensagem ${tipo}`;

    setTimeout(() => {
        mensagem.className = "mensagem";
    }, 4000);
}