// ==========================================
// CONFIGURAÇÃO
// ==========================================
const API_LOG = "https://localhost:7128/api/Log";
const API_MOVIMENTACAO = "https://localhost:7128/api/MovimentacaoEstoque";

// ==========================================
// USUÁRIO LOGADO E TOKEN
// ==========================================
const ID_USUARIO_LOGADO = localStorage.getItem("id_usuario");
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// ==========================================
// VERIFICAR LOGIN
// ==========================================
if (!ID_USUARIO_LOGADO || !TOKEN_JWT) {
    window.location.href = "login.html";
}

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou ou você não tem permissão. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }
    
    if (resposta.status === 403) {
        alert("Você não tem permissão para realizar esta ação.");
        throw new Error("Acesso negado.");
    }

    return resposta;
}

// ==========================================
// QUANDO A PÁGINA CARREGAR
// ==========================================
document.addEventListener("DOMContentLoaded", function () {

    // ==========================================
    // BOTÃO HAMBÚRGUER
    // ==========================================
    const btnMenuRastreador = document.getElementById("btnMenuRastreador");

    if (btnMenuRastreador) {
        btnMenuRastreador.addEventListener("click", function () {
            const btnMenuPai = window.parent.document.getElementById("btnMenu");
            if (btnMenuPai) {
                btnMenuPai.click();
            }
        });
    }

    // ==========================================
    // ELEMENTOS DAS TABELAS
    // ==========================================
    const tabelaLogs = document.getElementById("tabelaLogs");
    const tabelaMovimentacoes = document.getElementById("tabelaMovimentacoes");

    // ==========================================
    // BOTÕES DAS ABAS
    // ==========================================
    const btnLogs = document.getElementById("btnLogs");
    const btnMovimentacoes = document.getElementById("btnMovimentacoes");

    // ==========================================
    // SEÇÕES
    // ==========================================
    const secaoLogs = document.getElementById("secaoLogs");
    const secaoMovimentacoes = document.getElementById("secaoMovimentacoes");

    // ==========================================
    // CAMPOS DE FILTRO
    // ==========================================
    const buscaLogs = document.getElementById("buscaLogs");
    const dataInicialLogs = document.getElementById("dataInicialLogs");
    const dataFinalLogs = document.getElementById("dataFinalLogs");

    const buscaMovimentacoes = document.getElementById("buscaMovimentacoes");
    const dataInicialMovimentacoes = document.getElementById("dataInicialMovimentacoes");
    const dataFinalMovimentacoes = document.getElementById("dataFinalMovimentacoes");

    // ==========================================
    // GUARDAR DADOS ORIGINAIS
    // ==========================================
    let todosLogs = [];
    let todasMovimentacoes = [];

    // ==========================================
    // ABA LOGS
    // ==========================================
    btnLogs.addEventListener("click", function () {
        secaoLogs.style.display = "block";
        secaoMovimentacoes.style.display = "none";
        btnLogs.classList.add("ativa");
        btnMovimentacoes.classList.remove("ativa");
    });

    // ==========================================
    // ABA MOVIMENTAÇÕES
    // ==========================================
    btnMovimentacoes.addEventListener("click", function () {
        secaoLogs.style.display = "none";
        secaoMovimentacoes.style.display = "block";
        btnLogs.classList.remove("ativa");
        btnMovimentacoes.classList.add("ativa");
    });

    // ==========================================
    // EVENTOS DOS FILTROS - LOGS
    // ==========================================
    buscaLogs.addEventListener("input", aplicarFiltroLogs);
    dataInicialLogs.addEventListener("change", aplicarFiltroLogs);
    dataFinalLogs.addEventListener("change", aplicarFiltroLogs);

    // ==========================================
    // EVENTOS DOS FILTROS - MOVIMENTAÇÕES
    // ==========================================
    buscaMovimentacoes.addEventListener("input", aplicarFiltroMovimentacoes);
    dataInicialMovimentacoes.addEventListener("change", aplicarFiltroMovimentacoes);
    dataFinalMovimentacoes.addEventListener("change", aplicarFiltroMovimentacoes);

    // ==========================================
    // CARREGAR DADOS
    // ==========================================
    carregarLogs();
    carregarMovimentacoes();

    // ==========================================
    // CARREGAR LOGS
    // ==========================================
    async function carregarLogs() {
        try {
            const resposta = await fetchComToken(API_LOG);

            if (!resposta.ok) {
                throw new Error("Erro ao carregar os logs.");
            }

            const logs = await resposta.json();
            todosLogs = logs;
            mostrarLogs(todosLogs);

        } catch (erro) {
            console.error(erro);
            tabelaLogs.innerHTML = `
                <tr>
                    <td colspan="7">Erro ao carregar os logs.</td>
                </tr>
            `;
        }
    }

    // ==========================================
    // FILTRAR LOGS
    // ==========================================
    function aplicarFiltroLogs() {
        const texto = buscaLogs.value.toLowerCase().trim();
        const dataInicial = dataInicialLogs.value;
        const dataFinal = dataFinalLogs.value;

        const resultado = todosLogs.filter(log => {
            // Junta todos os dados do log
            const conteudo = `
                ${log.id_log ?? ""}
                ${log.id_usuario ?? ""}
                ${log.acao ?? ""}
                ${log.tabela ?? ""}
                ${log.id_registro ?? ""}
                ${log.descricao ?? ""}
            `.toLowerCase();

            // Verifica pesquisa
            const correspondeTexto = conteudo.includes(texto);

            // Data do log
            const dataLog = log.data_log ? new Date(log.data_log) : null;
            let correspondeData = true;

            if (dataLog) {
                const data = dataLog.toISOString().split("T")[0];

                if (dataInicial && data < dataInicial) {
                    correspondeData = false;
                }

                if (dataFinal && data > dataFinal) {
                    correspondeData = false;
                }
            }

            return correspondeTexto && correspondeData;
        });

        mostrarLogs(resultado);
    }

    // ==========================================
    // MOSTRAR LOGS
    // ==========================================
    function mostrarLogs(logs) {
        tabelaLogs.innerHTML = "";

        if (logs.length === 0) {
            tabelaLogs.innerHTML = `
                <tr>
                    <td colspan="7">Nenhum log encontrado.</td>
                </tr>
            `;
            return;
        }

        logs.forEach(log => {
            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${log.id_log ?? ""}</td>
                <td>${log.id_usuario ?? ""}</td>
                <td>${log.acao ?? ""}</td>
                <td>${log.tabela ?? ""}</td>
                <td>${log.id_registro ?? ""}</td>
                <td>${log.descricao ?? ""}</td>
                <td>${formatarData(log.data_log)}</td>
            `;

            tabelaLogs.appendChild(tr);
        });
    }

    // ==========================================
    // CARREGAR MOVIMENTAÇÕES
    // ==========================================
    async function carregarMovimentacoes() {
        try {
            const resposta = await fetchComToken(API_MOVIMENTACAO);

            if (!resposta.ok) {
                throw new Error("Erro ao carregar movimentações.");
            }

            const movimentacoes = await resposta.json();
            todasMovimentacoes = movimentacoes;
            mostrarMovimentacoes(todasMovimentacoes);

        } catch (erro) {
            console.error(erro);
            tabelaMovimentacoes.innerHTML = `
                <tr>
                    <td colspan="9">Erro ao carregar as movimentações.</td>
                </tr>
            `;
        }
    }

    // ==========================================
    // FILTRAR MOVIMENTAÇÕES
    // ==========================================
    function aplicarFiltroMovimentacoes() {
        const texto = buscaMovimentacoes.value.toLowerCase().trim();
        const dataInicial = dataInicialMovimentacoes.value;
        const dataFinal = dataFinalMovimentacoes.value;

        const resultado = todasMovimentacoes.filter(movimentacao => {
            const conteudo = `
                ${movimentacao.id_movimentacao ?? ""}
                ${movimentacao.id_produto ?? ""}
                ${movimentacao.id_usuario ?? ""}
                ${movimentacao.tipo ?? ""}
                ${movimentacao.quantidade ?? ""}
                ${movimentacao.estoque_anterior ?? ""}
                ${movimentacao.estoque_atual ?? ""}
                ${movimentacao.descricao ?? ""}
            `.toLowerCase();

            // Verifica pesquisa
            const correspondeTexto = conteudo.includes(texto);

            // Data
            const dataMovimentacao = movimentacao.data_movimentacao ? new Date(movimentacao.data_movimentacao) : null;
            let correspondeData = true;

            if (dataMovimentacao) {
                const data = dataMovimentacao.toISOString().split("T")[0];

                if (dataInicial && data < dataInicial) {
                    correspondeData = false;
                }

                if (dataFinal && data > dataFinal) {
                    correspondeData = false;
                }
            }

            return correspondeTexto && correspondeData;
        });

        mostrarMovimentacoes(resultado);
    }

    // ==========================================
    // MOSTRAR MOVIMENTAÇÕES
    // ==========================================
    function mostrarMovimentacoes(movimentacoes) {
        tabelaMovimentacoes.innerHTML = "";

        if (movimentacoes.length === 0) {
            tabelaMovimentacoes.innerHTML = `
                <tr>
                    <td colspan="9">Nenhuma movimentação encontrada.</td>
                </tr>
            `;
            return;
        }

        movimentacoes.forEach(movimentacao => {
            let tipo = "Desconhecido";

            if (movimentacao.tipo === 1) {
                tipo = "Entrada";
            } else if (movimentacao.tipo === 2) {
                tipo = "Saída";
            } else if (movimentacao.tipo === 3) {
                tipo = "Ajuste";
            }

            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${movimentacao.id_movimentacao ?? ""}</td>
                <td>${movimentacao.id_produto ?? ""}</td>
                <td>${movimentacao.id_usuario ?? ""}</td>
                <td>${tipo}</td>
                <td>${movimentacao.quantidade ?? ""}</td>
                <td>${movimentacao.estoque_anterior ?? ""}</td>
                <td>${movimentacao.estoque_atual ?? ""}</td>
                <td>${movimentacao.descricao ?? ""}</td>
                <td>${formatarData(movimentacao.data_movimentacao)}</td>
            `;

            tabelaMovimentacoes.appendChild(tr);
        });
    }

    // ==========================================
    // FORMATAR DATA
    // ==========================================
    function formatarData(data) {
        if (!data) return "";

        const dataObj = new Date(data);

        if (isNaN(dataObj)) return data;

        return dataObj.toLocaleString("pt-BR");
    }
});
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});