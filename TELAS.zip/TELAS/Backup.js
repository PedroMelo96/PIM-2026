// ==========================================
// CONFIGURAÇÃO
// ==========================================
const API_BACKUP = "https://localhost:7128/api/Backup";

// ==========================================
// USUÁRIO LOGADO E TOKEN
// ==========================================
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// Se não existe token, volta para a tela de login.
if (!TOKEN_JWT) {
    window.parent.location.href = "login.html";
}

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.parent.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou ou você não tem permissão. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.parent.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }
    
    if (resposta.status === 403) {
        alert("Você não tem permissão para realizar esta ação.");
        throw new Error("Acesso negado.");
    }

    return resposta;
}

// ==========================================
// INICIALIZAÇÃO
// ==========================================
document.addEventListener("DOMContentLoaded", function () {
    console.log("BACKUP.JS FOI CARREGADO");
    carregarBackups();
});

// ==========================================
// GERAR BACKUP
// ==========================================
async function gerarBackup() {
    const botao = document.getElementById("btnBackup");
    const mensagem = document.getElementById("mensagemBackup");

    if (botao) {
        botao.disabled = true;
        botao.textContent = "⏳ Gerando backup...";
    }

    if (mensagem) {
        mensagem.textContent = "Gerando backup do banco de dados...";
        mensagem.style.color = "#404040";
    }

    try {
        const resposta = await fetchComToken(`${API_BACKUP}/gerar`, {
            method: "POST"
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || "Erro ao gerar backup.");
        }

        if (mensagem) {
            mensagem.textContent = dados.mensagem || "Backup realizado com sucesso.";
            mensagem.style.color = "#26734d";
        }

        alert(dados.mensagem || "Backup realizado com sucesso.");
        carregarBackups();

    } catch (erro) {
        console.error("Erro ao gerar backup:", erro);

        if (mensagem) {
            mensagem.textContent = erro.message || "Erro ao gerar backup.";
            mensagem.style.color = "#a33a3a";
        }

        alert(erro.message || "Erro ao gerar backup.");

    } finally {
        if (botao) {
            botao.disabled = false;
            botao.textContent = "💾 Gerar Backup";
        }
    }
}

// ==========================================
// CARREGAR BACKUPS
// ==========================================
async function carregarBackups() {
    const lista = document.getElementById("listaBackups");

    if (!lista) {
        return;
    }

    lista.innerHTML = `
        <tr>
            <td colspan="3">Carregando backups...</td>
        </tr>
    `;

    try {
        const resposta = await fetchComToken(API_BACKUP);

        if (!resposta.ok) {
            throw new Error("Não foi possível carregar os backups.");
        }

        const backups = await resposta.json();

        if (!backups || backups.length === 0) {
            lista.innerHTML = `
                <tr>
                    <td colspan="3">Nenhum backup encontrado.</td>
                </tr>
            `;
            return;
        }

        lista.innerHTML = backups.map(backup => `
            <tr>
                <td><strong>${backup.nome}</strong></td>
                <td>${formatarData(backup.data)}</td>
                <td>${formatarTamanho(backup.tamanho)}</td>
            </tr>
        `).join("");

    } catch (erro) {
        console.error("Erro ao carregar backups:", erro);

        lista.innerHTML = `
            <tr>
                <td colspan="3">Erro ao carregar backups.</td>
            </tr>
        `;
    }
}

// ==========================================
// FORMATAR DATA
// ==========================================
function formatarData(data) {
    if (!data) {
        return "-";
    }

    const dataObj = new Date(data);
    return dataObj.toLocaleString("pt-BR");
}

// ==========================================
// FORMATAR TAMANHO
// ==========================================
function formatarTamanho(bytes) {
    bytes = Number(bytes || 0);

    if (bytes === 0) {
        return "0 KB";
    }

    const kb = bytes / 1024;

    if (kb < 1024) {
        return `${kb.toFixed(2)} KB`;
    }

    const mb = kb / 1024;
    return `${mb.toFixed(2)} MB`;
}
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});