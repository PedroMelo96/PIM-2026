// ==========================================================
// CONFIGURAÇÃO
// ==========================================================
const API_PRODUTO = "https://localhost:7128/api/Produto";
const API_VENDA = "https://localhost:7128/api/Venda";
const API_CAIXA = "https://localhost:7128/api/Caixa";
const API_FORMA_PAGAMENTO = "https://localhost:7128/api/FormaPagamento";

// ==========================================================
// USUÁRIO
// ==========================================================
const ID_USUARIO = Number(localStorage.getItem("id_usuario"));
const NOME_USUARIO = localStorage.getItem("nome_usuario") || "Usuário";

// ==========================================================
// VARIÁVEIS
// ==========================================================
let caixaAtual = null;
let produtos = [];
let produtosVenda = [];
let pagamentos = [];

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.parent.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    // Inicializa headers se não existir
    if (!options.headers) {
        options.headers = {};
    }

    // Adiciona o token JWT
    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    // Se o token estiver vencido ou for inválido
    if (resposta.status === 401) {
        alert("Sua sessão expirou. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.parent.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }

    return resposta;
}

// ==========================================================
// INICIALIZAÇÃO
// ==========================================================
document.addEventListener("DOMContentLoaded", async function () {
    // ------------------------------------------------------
    // MOSTRAR USUÁRIO
    // ------------------------------------------------------
    const usuarioLogado = document.getElementById("usuarioLogado");
    if (usuarioLogado) {
        usuarioLogado.textContent = NOME_USUARIO;
    }

    // ------------------------------------------------------
    // FORMA DE PAGAMENTO
    // Preencher automaticamente o restante
    // ------------------------------------------------------
    const formaPagamento = document.getElementById("formaPagamento");
    if (formaPagamento) {
        formaPagamento.addEventListener("change", preencherValorPagamentoAutomatico);
    }

    // ------------------------------------------------------
    // DATA E HORA
    // ------------------------------------------------------
    atualizarDataHora();
    setInterval(atualizarDataHora, 1000);

    // ------------------------------------------------------
    // PESQUISA DE PRODUTO
    // ------------------------------------------------------
    // ==========================================================
// PESQUISAR E ADICIONAR PRODUTOS
// ==========================================================
function pesquisarProduto() {
    const campo = document.getElementById("pesquisaProduto");
    if (!campo) return;

    const termo = campo.value.trim().toLowerCase();

    if (!termo) {
        const resultadoPesquisa = document.getElementById("resultadoPesquisa");
        if (resultadoPesquisa) resultadoPesquisa.innerHTML = "";
        return;
    }

    const encontrados = produtos.filter(function (produto) {
        // 1. REGRA CORRIGIDA: Ignora os produtos inativos (ativo == "N")
        if (produto.ativo === "N") {
            return false;
        }

        // 2. Regra de pesquisa (ID, Barras ou Nome)
        const id = String(produto.id_produto);
        const barras = String(produto.barras ?? "").toLowerCase();
        const nome = String(produto.nome_produto ?? "").toLowerCase();
        
        return (id === termo || barras === termo || nome.includes(termo));
    });

    renderizarResultadoPesquisa(encontrados);
}

    // ------------------------------------------------------
    // CARREGAR DADOS
    // ------------------------------------------------------
    await carregarProdutos();
    await carregarFormasPagamento();
    await verificarCaixa();

    // ------------------------------------------------------
    // ATUALIZAR TELA
    // ------------------------------------------------------
    atualizarTela();
});

// ==========================================================
// DATA E HORA
// ==========================================================
function atualizarDataHora() {
    const agora = new Date();
    const dataAtual = document.getElementById("dataAtual");
    const horaAtual = document.getElementById("horaAtual");

    if (dataAtual) {
        dataAtual.textContent = agora.toLocaleDateString("pt-BR");
    }
    if (horaAtual) {
        horaAtual.textContent = agora.toLocaleTimeString("pt-BR");
    }
}

// ==========================================================
// PREENCHER VALOR DO PAGAMENTO AUTOMATICAMENTE
// ==========================================================
function preencherValorPagamentoAutomatico() {
    const select = document.getElementById("formaPagamento");
    const campo = document.getElementById("valorPagamento");

    if (!select || !campo) {
        return;
    }

    if (!select.value) {
        campo.value = "";
        return;
    }

    const valores = calcularValores();

    const totalPago = pagamentos.reduce(function (total, pagamento) {
        return total + Number(pagamento.valor);
    }, 0);

    const restante = Math.max(0, valores.total - totalPago);

    if (restante > 0) {
        campo.value = restante.toFixed(2);
        campo.focus();
        campo.select();
    } else {
        campo.value = "";
    }
}

// ==========================================================
// CARREGAR PRODUTOS
// ==========================================================
// ==========================================================
// CARREGAR PRODUTOS (SOMENTE ATIVOS)
// ==========================================================
async function carregarProdutos() {
    try {
        const resposta = await fetchComToken(API_PRODUTO);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar produtos.");
        }

        const todosProdutos = await resposta.json();
        
        // CORTA O MAL PELA RAIZ: 
        // Filtra e salva na memória do caixa APENAS os produtos ativos
        produtos = todosProdutos.filter(function (p) {
            // Pega o valor do campo "ativo" (ou "Ativo"), transforma em texto e joga pra maiúsculo
            const status = String(p.ativo || p.Ativo || "").toUpperCase();
            
            // Só deixa passar quem NÃO for "N"
            return status !== "N";
        });

        console.log("Produtos carregados no caixa (apenas ativos):", produtos);

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro", "Não foi possível carregar os produtos.");
    }
}
// ==========================================================
// CARREGAR FORMAS DE PAGAMENTO
// ==========================================================
async function carregarFormasPagamento() {
    try {
        const resposta = await fetchComToken(API_FORMA_PAGAMENTO);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar formas de pagamento.");
        }

        const formas = await resposta.json();
        const select = document.getElementById("formaPagamento");

        if (!select) return;

        select.innerHTML = '<option value="">Selecione</option>';

        formas.forEach(function (forma) {
            const option = document.createElement("option");
            option.value = forma.id_forma_pagamento;
            option.textContent = forma.nome_forma;
            select.appendChild(option);
        });

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro", "Não foi possível carregar as formas de pagamento.");
    }
}

// ==========================================================
// VERIFICAR CAIXA
// ==========================================================
async function verificarCaixa() {
    if (!ID_USUARIO) {
        caixaAtual = null;
        atualizarStatusCaixa("Usuário não identificado", false);
        return;
    }

    try {
        // Agora não passamos mais o ID do usuário na URL, a API pega do Token
        const resposta = await fetchComToken(`${API_CAIXA}/aberto`);

        if (resposta.ok) {
            const dados = await resposta.json();
            caixaAtual = dados.caixa ?? dados;

            if (caixaAtual && caixaAtual.id_caixa) {
                atualizarStatusCaixa(`Caixa #${caixaAtual.id_caixa} aberto`, true);
                console.log("Caixa encontrado:", caixaAtual);
                return;
            }
        }

        console.log("Endpoint /aberto não encontrou caixa. Tratando como sem caixa.");

        caixaAtual = null;
        atualizarStatusCaixa("Nenhum caixa aberto", false);
        abrirModalCaixa();

    } catch (erro) {
        console.error("Erro ao verificar caixa:", erro);
        caixaAtual = null;
        atualizarStatusCaixa("Erro ao verificar caixa", false);
    }
}

// ==========================================================
// STATUS DO CAIXA
// ==========================================================
function atualizarStatusCaixa(texto, aberto) {
    const elemento = document.getElementById("statusCaixa");
    if (!elemento) return;

    elemento.textContent = texto;
    if (aberto) {
        elemento.style.background = "#159447";
    } else {
        elemento.style.background = "#c58b18";
    }
}

// ==========================================================
// ABRIR MODAL DO CAIXA
// ==========================================================
function abrirModalCaixa() {
    const modal = document.getElementById("modalCaixa");
    if (!modal) return;
    
    modal.classList.add("ativo");
    
    const campo = document.getElementById("valorAberturaVenda");
    if (campo) campo.focus();
}

function fecharModalCaixa() {
    const modal = document.getElementById("modalCaixa");
    if (modal) modal.classList.remove("ativo");
}

// ==========================================================
// ABRIR CAIXA
// ==========================================================
async function abrirCaixaVenda() {
    const campo = document.getElementById("valorAberturaVenda");
    const valor = Number(campo?.value) || 0;

    try {
        const resposta = await fetchComToken(`${API_CAIXA}/abrir`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                valor_abertura: valor,
                status: 1
            })
        });

        const resultado = await resposta.json();

        if (!resposta.ok) {
            const mensagem = resultado.mensagem || "";
            if (mensagem.toLowerCase().includes("já possui o caixa")) {
                fecharModalCaixa();
                await verificarCaixa();
                return;
            }
            throw new Error(mensagem || "Não foi possível abrir o caixa.");
        }

        caixaAtual = resultado.caixa ?? resultado;
        fecharModalCaixa();
        atualizarStatusCaixa(`Caixa #${caixaAtual.id_caixa} aberto`, true);
        mostrarMensagem("Caixa aberto", `Caixa #${caixaAtual.id_caixa} aberto com sucesso.`);

    } catch (erro) {
        console.error(erro);
        mostrarMensagem("Erro", erro.message);
    }
}
// ==========================================================
// ESTORNO DE VENDA (APENAS POR ID)
// ==========================================================
function abrirModalEstorno() {
    if (!caixaAtual) {
        mostrarMensagem("Caixa", "Não existe um caixa aberto.");
        return;
    }

    const modal = document.getElementById("modalEstorno");
    if (!modal) return;

    modal.classList.add("ativo");
    
    // Foca automaticamente no campo para o operador já digitar o ID
    const input = document.getElementById("inputEstornoId");
    if (input) {
        input.value = "";
        setTimeout(() => input.focus(), 100);
    }
}

function fecharModalEstorno() {
    const modal = document.getElementById("modalEstorno");
    if (modal) modal.classList.remove("ativo");
}

async function estornarPorInput() {
    const input = document.getElementById("inputEstornoId");
    const idVenda = Number(input.value);

    if (!idVenda || idVenda <= 0) {
        mostrarMensagem("Estorno", "Informe um ID de venda válido.");
        input.focus();
        return;
    }

    await estornarVenda(idVenda);
}

async function estornarVenda(idVenda) {
    if (!caixaAtual) {
        mostrarMensagem("Caixa", "Não existe caixa aberto.");
        return;
    }

    if (!confirm(`Deseja realmente estornar a venda #${idVenda}?`)) {
        return;
    }

    try {
        const resposta = await fetchComToken(`${API_VENDA}/${idVenda}/estornar`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            }
        });

        const texto = await resposta.text();
        let dados = {};

        if (texto) {
            try { dados = JSON.parse(texto); } catch { dados = {}; }
        }

        if (!resposta.ok) {
            throw new Error(dados.mensagem || "Erro ao estornar venda.");
        }

        mostrarMensagem("Estorno", dados.mensagem || "Venda estornada com sucesso!");
        
        // Limpa o campo, fecha o modal e atualiza o estoque
        fecharModalEstorno();
        await carregarProdutos();

    } catch (erro) {
        console.error("Erro ao estornar:", erro);
        mostrarMensagem("Erro", erro.message || "Erro ao estornar venda.");
    }
}
// ==========================================================
// FECHAR CAIXA (MODAL E AÇÃO)
// ==========================================================
function abrirModalFecharCaixa() {
    if (!caixaAtual) {
        mostrarMensagem("Caixa", "Não existe um caixa aberto.");
        return;
    }

    if (produtosVenda.length > 0 || pagamentos.length > 0) {
        mostrarMensagem("Venda em andamento", "Finalize ou cancele a venda atual antes de fechar o caixa.");
        return;
    }

    const modal = document.getElementById("modalFecharCaixa");
    if (!modal) {
        mostrarMensagem("Erro", "Modal de fechamento do caixa não foi encontrado no HTML.");
        return;
    }

    const campo = document.getElementById("valorFechamentoVenda");
    if (campo) campo.value = "";
    
    modal.classList.add("ativo");

    if (campo) {
        setTimeout(function () {
            campo.focus();
        }, 100);
    }
}

function fecharModalFecharCaixa() {
    const modal = document.getElementById("modalFecharCaixa");
    if (modal) modal.classList.remove("ativo");
}

async function fecharCaixaVenda() {
    if (!caixaAtual) {
        mostrarMensagem("Caixa", "Nenhum caixa está aberto.");
        return;
    }

    const valorInput = document.getElementById("valorFechamentoVenda");
    if (!valorInput) return;

    const valorDigitado = valorInput.value.trim();
    if (valorDigitado === "") {
        mostrarMensagem("Caixa", "Informe o valor de fechamento.");
        valorInput.focus();
        return;
    }

    const valorFechamento = Number(valorDigitado);
    if (!Number.isFinite(valorFechamento) || valorFechamento < 0) {
        mostrarMensagem("Caixa", "Informe um valor de fechamento válido.");
        valorInput.focus();
        return;
    }

    try {
        const resposta = await fetchComToken(`${API_CAIXA}/${caixaAtual.id_caixa}/fechar`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                valor_fechamento: valorFechamento
            })
        });

        const texto = await resposta.text();
        let dados = {};

        if (texto) {
            try { dados = JSON.parse(texto); } catch { dados = {}; }
        }

        if (!resposta.ok) {
            throw new Error(dados.mensagem || "Não foi possível fechar o caixa.");
        }

        mostrarMensagem("Caixa fechado", dados.mensagem || "Caixa fechado com sucesso!");
        caixaAtual = null;
        atualizarStatusCaixa("Caixa fechado", false);
        fecharModalFecharCaixa();
        valorInput.value = "";

        setTimeout(function () {
            abrirModalCaixa();
        }, 500);

    } catch (erro) {
        console.error("Erro ao fechar caixa:", erro);
        mostrarMensagem("Erro", erro.message || "Erro ao fechar caixa.");
    }
}


// ==========================================================
// PESQUISAR E ADICIONAR PRODUTOS
// ==========================================================
function pesquisarProduto() {
    const campo = document.getElementById("pesquisaProduto");
    if (!campo) return;

    const termo = campo.value.trim().toLowerCase();

    if (!termo) {
        const resultadoPesquisa = document.getElementById("resultadoPesquisa");
        if (resultadoPesquisa) resultadoPesquisa.innerHTML = "";
        return;
    }

    const encontrados = produtos.filter(function (produto) {
        const id = String(produto.id_produto);
        const barras = String(produto.barras ?? "").toLowerCase();
        const nome = String(produto.nome_produto ?? "").toLowerCase();
        return (id === termo || barras === termo || nome.includes(termo));
    });

    renderizarResultadoPesquisa(encontrados);
}

function renderizarResultadoPesquisa(encontrados) {
    const container = document.getElementById("resultadoPesquisa");
    if (!container) return;

    if (encontrados.length === 0) {
        container.innerHTML = `
            <div class="produto-resultado">
                <div class="produto-resultado-info">
                    <strong>Produto não encontrado</strong>
                    <span>Verifique o código ou nome informado.</span>
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = encontrados.map(function (produto) {
        return `
            <div class="produto-resultado" onclick="adicionarProduto(${produto.id_produto})">
                <div class="produto-resultado-info">
                    <strong>${produto.nome_produto}</strong>
                    <span>ID: ${produto.id_produto} | Barras: ${produto.barras ?? "-"} | Estoque: ${produto.estoque}</span>
                </div>
                <div class="produto-resultado-preco">
                    ${formatarMoeda(produto.valor_venda)}
                </div>
            </div>
        `;
    }).join("");
}

function adicionarProduto(idProduto) {
    const produto = produtos.find(function (p) {
        return Number(p.id_produto) === Number(idProduto);
    });

    if (!produto) {
        mostrarMensagem("Erro", "Produto não encontrado.");
        return;
    }

    if (Number(produto.estoque) <= 0) {
        mostrarMensagem("Estoque", "Este produto está sem estoque.");
        return;
    }

    const existente = produtosVenda.find(function (item) {
        return Number(item.id_produto) === Number(produto.id_produto);
    });

    if (existente) {
        if (existente.quantidade + 1 > Number(produto.estoque)) {
            mostrarMensagem("Estoque", "Quantidade maior que o estoque disponível.");
            return;
        }
        existente.quantidade++;
    } else {
        produtosVenda.push({
            id_produto: produto.id_produto,
            nome_produto: produto.nome_produto,
            barras: produto.barras,
            quantidade: 1,
            valor_unitario: Number(produto.valor_venda)
        });
    }

    const pesquisa = document.getElementById("pesquisaProduto");
    if (pesquisa) pesquisa.value = "";

    const resultado = document.getElementById("resultadoPesquisa");
    if (resultado) resultado.innerHTML = "";

    atualizarTela();
    if (pesquisa) pesquisa.focus();
}

function alterarQuantidade() {
    if (produtosVenda.length === 0) {
        mostrarMensagem("Quantidade", "Adicione um produto primeiro.");
        return;
    }

    const ultimo = produtosVenda[produtosVenda.length - 1];
    const produto = produtos.find(function (p) {
        return Number(p.id_produto) === Number(ultimo.id_produto);
    });

    const novaQuantidade = prompt("Informe a quantidade:", ultimo.quantidade);
    if (novaQuantidade === null) return;

    const quantidade = Number(novaQuantidade);

    if (!Number.isInteger(quantidade) || quantidade <= 0) {
        mostrarMensagem("Quantidade", "Informe uma quantidade válida.");
        return;
    }

    if (produto && quantidade > Number(produto.estoque)) {
        mostrarMensagem("Estoque", "Quantidade maior que o estoque disponível.");
        return;
    }

    ultimo.quantidade = quantidade;
    atualizarTela();
}

function removerProduto(index) {
    produtosVenda.splice(index, 1);
    atualizarTela();
}

// ==========================================================
// CÁLCULOS DA VENDA
// ==========================================================
// ==========================================
// CÁLCULOS DA VENDA COM LIMITE DE DESCONTO DA CLASSE
// ==========================================
function calcularValores() {
    let totalBruto = 0;
    let quantidadeItens = 0;
    let maiorDescontoPermitido = 100; // Padrão se não achar restrição

    // Se houver produtos, vamos descobrir qual é o desconto máximo permitido pelas classes deles
    if (produtosVenda.length > 0) {
        // Pega o menor desconto entre as classes dos produtos na venda (ou define uma regra por item)
        // Aqui vamos pegar o limite da classe do primeiro produto ou o menor teto da venda:
        produtosVenda.forEach(function (item) {
            // Busca o produto correspondente na lista global de produtos carregados
            const produtoOriginal = produtos.find(p => Number(p.id_produto) === Number(item.id_produto));
            
            if (produtoOriginal && produtoOriginal.classe) {
                const descontoClasse = Number(produtoOriginal.classe.desconto) || 0;
                // Se quiser que o limite da venda seja o da classe do produto:
                maiorDescontoPermitido = Math.min(maiorDescontoPermitido, descontoClasse);
            }
        });
    }

    const campoDesconto = document.getElementById("desconto");
    let percentualDesconto = Number(campoDesconto?.value) || 0;

    // TRAVA DE SEGURANÇA: O desconto não pode passar do limite definido na classe
    if (percentualDesconto > maiorDescontoPermitido) {
        mostrarMensagem("Atenção", `O desconto máximo permitido para esta venda é de ${maiorDescontoPermitido}% (conforme a classe do produto).`);
        percentualDesconto = maiorDescontoPermitido;
        if (campoDesconto) campoDesconto.value = maiorDescontoPermitido;
    }

    const percentualSeguro = Math.min(100, Math.max(0, percentualDesconto));
    
    const valorDesconto = totalBruto * (percentualSeguro / 100);
    const total = Math.max(0, totalBruto - valorDesconto);

    // Recalcula o total bruto percorrendo os itens
    produtosVenda.forEach(function (item) {
        totalBruto += Number(item.quantidade) * Number(item.valor_unitario);
        quantidadeItens += Number(item.quantidade);
    });

    // Recalcula o desconto real com o bruto correto
    const valorDescontoReal = totalBruto * (percentualSeguro / 100);
    const totalFinal = Math.max(0, totalBruto - valorDescontoReal);

    return {
        totalBruto: Number(totalBruto.toFixed(2)),
        quantidadeItens: quantidadeItens,
        percentualDesconto: percentualSeguro,
        valorDesconto: Number(valorDescontoReal.toFixed(2)),
        total: Number(totalFinal.toFixed(2))
    };
}

// ==========================================================
// ATUALIZAÇÃO DA TELA
// ==========================================================
function atualizarTela() {
    const valores = calcularValores();

    const totalPago = pagamentos.reduce(function (total, pagamento) {
        return total + Number(pagamento.valor);
    }, 0);

    const totalRecebido = pagamentos.reduce(function (total, pagamento) {
        return total + Number(pagamento.valor_recebido || pagamento.valor);
    }, 0);

    const valorRestante = Math.max(0, valores.total - totalPago);
    const valorTroco = Math.max(0, totalRecebido - valores.total);

    const contadorItens = document.getElementById("contadorItens");
    if (contadorItens) contadorItens.textContent = valores.quantidadeItens;

    const resumoQuantidade = document.getElementById("resumoQuantidade");
    if (resumoQuantidade) resumoQuantidade.textContent = valores.quantidadeItens;

    const totalBruto = document.getElementById("totalBruto");
    if (totalBruto) totalBruto.textContent = formatarMoeda(valores.totalBruto);

    const valorDesconto = document.getElementById("valorDesconto");
    if (valorDesconto) valorDesconto.textContent = formatarMoeda(valores.valorDesconto);

    const totalVenda = document.getElementById("totalVenda");
    if (totalVenda) totalVenda.textContent = formatarMoeda(valores.total);

    const elementoTotalPago = document.getElementById("totalPago");
    if (elementoTotalPago) elementoTotalPago.textContent = formatarMoeda(totalPago);

    const elementoRestante = document.getElementById("restante");
    if (elementoRestante) elementoRestante.textContent = formatarMoeda(valorRestante);

    const elementoTroco = document.getElementById("troco");
    if (elementoTroco) elementoTroco.textContent = formatarMoeda(valorTroco);

    renderizarItens();
    renderizarPagamentos();
}

function renderizarItens() {
    const tbody = document.getElementById("listaProdutos");
    if (!tbody) return;

    if (produtosVenda.length === 0) {
        tbody.innerHTML = `
            <tr class="vazio">
                <td colspan="7">Nenhum produto lançado.<br>Pesquise um produto para começar.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = produtosVenda.map(function (item, index) {
        const subtotal = Number(item.quantidade) * Number(item.valor_unitario);
        return `
            <tr>
                <td>${index + 1}</td>
                <td><strong>${item.nome_produto}</strong></td>
                <td>${item.barras ?? "-"}</td>
                <td>${item.quantidade}</td>
                <td>${formatarMoeda(item.valor_unitario)}</td>
                <td><strong>${formatarMoeda(subtotal)}</strong></td>
                <td>
                    <button type="button" class="btn-remover" onclick="removerProduto(${index})">Remover</button>
                </td>
            </tr>
        `;
    }).join("");
}

// ==========================================================
// PAGAMENTOS
// ==========================================================
function adicionarPagamento() {
    const select = document.getElementById("formaPagamento");
    const campo = document.getElementById("valorPagamento");

    if (!select || !campo) return;

    const idFormaPagamento = Number(select.value);
    const valorRecebido = Number(campo.value);

    if (!idFormaPagamento) {
        mostrarMensagem("Pagamento", "Selecione uma forma de pagamento.");
        return;
    }

    if (isNaN(valorRecebido) || valorRecebido <= 0) {
        mostrarMensagem("Pagamento", "Informe um valor de pagamento válido.");
        return;
    }

    const valores = calcularValores();
    const totalPago = pagamentos.reduce(function (total, pagamento) {
        return total + Number(pagamento.valor);
    }, 0);

    const restante = Math.max(0, valores.total - totalPago);

    if (restante <= 0) {
        mostrarMensagem("Pagamento", "A venda já está totalmente paga.");
        return;
    }

    const valorAplicado = Math.min(valorRecebido, restante);
    const troco = Math.max(0, valorRecebido - valorAplicado);
    
    const optionSelecionada = select.options[select.selectedIndex];
    const nomeForma = optionSelecionada ? optionSelecionada.textContent : "Pagamento";

    pagamentos.push({
        id_forma_pagamento: idFormaPagamento,
        nome_forma: nomeForma,
        valor: Number(valorAplicado.toFixed(2)),
        valor_recebido: Number(valorRecebido.toFixed(2)),
        troco: Number(troco.toFixed(2))
    });

    select.value = "";
    campo.value = "";
    atualizarTela();
}

function removerPagamento(index) {
    pagamentos.splice(index, 1);
    atualizarTela();
}

function renderizarPagamentos() {
    const container = document.getElementById("listaPagamentos");
    if (!container) return;

    if (pagamentos.length === 0) {
        container.innerHTML = `<div class="pagamento-vazio">Nenhum pagamento lançado.</div>`;
        return;
    }

    container.innerHTML = pagamentos.map(function (pagamento, index) {
        return `
            <div class="pagamento-item">
                <strong>${pagamento.nome_forma || "Pagamento"}</strong>
                <span>${formatarMoeda(pagamento.valor)}</span>
                ${pagamento.troco > 0 ? `<small>Troco: ${formatarMoeda(pagamento.troco)}</small>` : ""}
                <button type="button" class="btn-remover-pagamento" onclick="removerPagamento(${index})">×</button>
            </div>
        `;
    }).join("");
}

// ==========================================================
// FINALIZAR VENDA
// ==========================================================
async function finalizarVenda() {
    if (!caixaAtual) {
        await verificarCaixa();
        if (!caixaAtual) {
            mostrarMensagem("Caixa", "Não existe um caixa aberto.");
            return;
        }
    }

    if (produtosVenda.length === 0) {
        mostrarMensagem("Venda", "Adicione pelo menos um produto.");
        return;
    }

    const valores = calcularValores();
    const totalPago = pagamentos.reduce(function (soma, pagamento) {
        return soma + Number(pagamento.valor);
    }, 0);

    if (Math.abs(totalPago - valores.total) > 0.01) {
        mostrarMensagem("Pagamento", `O total pago precisa ser ${formatarMoeda(valores.total)}.`);
        return;
    }

    const venda = {
        id_caixa: Number(caixaAtual.id_caixa),
        valor_total: valores.total,
        desconto: valores.valorDesconto,
        status: 1,
        itens: produtosVenda.map(function (item) {
            return {
                id_produto: Number(item.id_produto),
                quantidade: Number(item.quantidade),
                valor_unitario: Number(item.valor_unitario),
                valor_total: Number((item.quantidade * item.valor_unitario).toFixed(2))
            };
        }),
        pagamentos: pagamentos.map(function (pagamento) {
            return {
                id_forma_pagamento: Number(pagamento.id_forma_pagamento),
                valor: Number(pagamento.valor)
            };
        })
    };

    console.log("Venda enviada para API:", venda);

    try {
        const resposta = await fetchComToken(API_VENDA, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(venda)
        });

        const texto = await resposta.text();
        let resultado = {};

        if (texto) {
            try { resultado = JSON.parse(texto); } catch { resultado = {}; }
        }

        if (!resposta.ok) {
            throw new Error(resultado.mensagem || "Não foi possível finalizar a venda.");
        }

       const idVenda = resultado.id_venda ?? resultado.idVenda ?? resultado.venda?.id_venda ?? resultado.venda?.idVenda ?? "";
        mostrarMensagem("Venda finalizada", `Venda #${idVenda} realizada com sucesso.`);
        
        // ---- NOVO: CHAMA A IMPRESSÃO AQUI ----
        emitirCupomDeVenda(idVenda, valores.total, produtosVenda);
        
        limparVenda();
        await carregarProdutos();
        await verificarCaixa();

    } catch (erro) {
        console.error("Erro ao finalizar venda:", erro);
        mostrarMensagem("Erro na venda", erro.message);
    }
}

function cancelarVenda() {
    if (produtosVenda.length === 0 && pagamentos.length === 0) return;
    if (!confirm("Deseja realmente cancelar a venda atual?")) return;
    
    limparVenda();
    mostrarMensagem("Venda cancelada", "A venda atual foi cancelada.");
}

function limparVenda() {
    produtosVenda = [];
    pagamentos = [];

    const desconto = document.getElementById("desconto");
    if (desconto) desconto.value = 0;

    const pesquisa = document.getElementById("pesquisaProduto");
    if (pesquisa) pesquisa.value = "";

    const resultado = document.getElementById("resultadoPesquisa");
    if (resultado) resultado.innerHTML = "";

    const formaPagamento = document.getElementById("formaPagamento");
    if (formaPagamento) formaPagamento.value = "";

    const valorPagamento = document.getElementById("valorPagamento");
    if (valorPagamento) valorPagamento.value = "";

    atualizarTela();
    if (pesquisa) pesquisa.focus();
}

// ==========================================================
// UTILITÁRIOS
// ==========================================================
function mostrarMensagem(titulo, texto) {
    const elemento = document.getElementById("mensagem");
    if (!elemento) {
        console.log(titulo, texto);
        return;
    }
    
    elemento.innerHTML = `<strong>${titulo}</strong><br>${texto}`;
    elemento.classList.add("exibir");
    
    setTimeout(function () {
        elemento.classList.remove("exibir");
    }, 3500);
}

function fecharCaixa() {
    fecharCaixaVenda();
}

function formatarMoeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});

// Estorno manual digitando o ID
async function estornarPorInput() {
    const input = document.getElementById("inputEstornoId");
    const id = Number(input.value);

    if (!id || id <= 0) {
        mostrarMensagem("Estorno", "Informe um ID de venda válido.");
        return;
    }

    // Chama a função existente que bate na API
    await estornarVenda(id);
    input.value = ""; // Limpa o campo
}

// ==========================================================
// EMITIR CUPOM DE VENDA
// ==========================================================
function emitirCupomDeVenda(idVenda, valorTotal, listaDeItens) {
    document.getElementById("cupomIdVenda").innerText = idVenda;
    document.getElementById("cupomTotal").innerText = Number(valorTotal).toFixed(2).replace(".", ",");
    document.getElementById("cupomData").innerText = new Date().toLocaleString("pt-BR");

    const tbody = document.getElementById("cupomItens");
    tbody.innerHTML = listaDeItens.map(item => `
        <tr>
            <td>${item.quantidade}x</td>
            <td>${item.nome_produto}</td>
            <td>${Number(item.valor_unitario).toFixed(2)}</td>
            <td>${Number(item.quantidade * item.valor_unitario).toFixed(2)}</td>
        </tr>
    `).join("");

    window.print(); // Dispara a tela de impressão do navegador
}