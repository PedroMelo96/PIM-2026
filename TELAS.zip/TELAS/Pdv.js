document.addEventListener("DOMContentLoaded", function () {

    console.log("=================================");
    console.log("PDV.JS FOI CARREGADO");
    console.log("=================================");

    // ==========================================
    // VERIFICA SE O USUÁRIO ESTÁ LOGADO (TEM TOKEN)
    // ==========================================
    const token = localStorage.getItem("meuTokenJWT");
    if (!token) {
        console.warn("Usuário sem token. Redirecionando para login.");
        window.location.href = "login.html";
        return; // Para a execução do script
    }

    // ==========================================================
    // CONTROLE DE PERMISSÕES NO MENU
    // ==========================================================
    // 1. Pega o perfil que foi salvo no login
    const idPerfil = Number(localStorage.getItem("id_perfil"));

    // 2. Seleciona os itens do menu
    const linkVenda = document.getElementById("linkVenda");
    const linkCaixa = document.getElementById("linkCaixa");
    const linkEstoque = document.getElementById("linkEstoque");
    const linkRastreador = document.getElementById("linkRastreador");
    const linkUsuario = document.getElementById("linkUsuario");
    const linkRelatorio = document.getElementById("linkRelatorio");
    const linkBackup = document.getElementById("linkBackup");

    // ==========================================
    // PERFIL 2: CAIXA
    // (Vê Dashboard, Vendas e Caixa)
    // ==========================================
    if (idPerfil === 2) {
        if (linkEstoque) linkEstoque.style.display = "none";
        if (linkRastreador) linkRastreador.style.display = "none";
        if (linkUsuario) linkUsuario.style.display = "none";
        if (linkRelatorio) linkRelatorio.style.display = "none";
        if (linkBackup) linkBackup.style.display = "none";
    }

    // ==========================================
    // PERFIL 3: ESTOQUISTA
    // (Vê Dashboard e Estoque)
    // ==========================================
    else if (idPerfil === 3) {
        if (linkVenda) linkVenda.style.display = "none";
        if (linkCaixa) linkCaixa.style.display = "none";
        if (linkRastreador) linkRastreador.style.display = "none";
        if (linkUsuario) linkUsuario.style.display = "none";
        if (linkRelatorio) linkRelatorio.style.display = "none";
        if (linkBackup) linkBackup.style.display = "none";
    }

    // Nota: O PERFIL 1 (Admin) não entra nos IFs acima, 
    // portanto nada é escondido e ele vê tudo normalmente!

    // ==========================================
    // MOSTRAR NOME DO USUÁRIO NA TELA
    // ==========================================
    const spanNome = document.getElementById("nomeUsuarioLogado");
    if (spanNome) {
        spanNome.textContent = localStorage.getItem("nome_usuario") || "Usuário";
    }

    // ==========================================
    // ELEMENTOS
    // ==========================================
    const btnMenu = document.getElementById("btnMenu");
    const menuLateral = document.getElementById("menuLateral");
    const overlay = document.getElementById("overlay");

    const inicio = document.getElementById("inicioPdv");

    const telaDashboard = document.getElementById("telaDashboard");
    const telaVenda = document.getElementById("telaVenda");
    const telaCaixa = document.getElementById("telaCaixa");
    const telaEstoque = document.getElementById("telaEstoque");
    const telaRastreador = document.getElementById("telaRastreador");
    const telaUsuario = document.getElementById("telaUsuario");
    const telaRelatorio = document.getElementById("telaRelatorio");
    const telaBackup = document.getElementById("telaBackup");

    // ==========================================
    // LINKS
    // ==========================================
    const linkDashboard = document.getElementById("linkDashboard");
    const btnSair = document.getElementById("btnSair");

    // ==========================================
    // ABRIR / FECHAR MENU
    // ==========================================
    if (btnMenu) {
        btnMenu.addEventListener("click", function () {
            console.log("MENU CLICADO");
            menuLateral.classList.toggle("ativo");
            overlay.classList.toggle("ativo");
        });
    }

    // ==========================================
    // FECHAR MENU NO OVERLAY
    // ==========================================
    if (overlay) {
        overlay.addEventListener("click", function () {
            menuLateral.classList.remove("ativo");
            overlay.classList.remove("ativo");
        });
    }

    // ==========================================
    // FECHAR MENU
    // ==========================================
    function fecharMenu() {
        if (menuLateral) menuLateral.classList.remove("ativo");
        if (overlay) overlay.classList.remove("ativo");
    }

    // ==========================================
    // ESCONDER TODAS AS TELAS
    // ==========================================
    function esconderTodas() {
        if (inicio) inicio.style.display = "none";
        if (telaDashboard) telaDashboard.style.display = "none";
        if (telaVenda) telaVenda.style.display = "none";
        if (telaCaixa) telaCaixa.style.display = "none";
        if (telaEstoque) telaEstoque.style.display = "none";
        if (telaRastreador) telaRastreador.style.display = "none";
        if (telaUsuario) telaUsuario.style.display = "none";
        if (telaRelatorio) telaRelatorio.style.display = "none";
        if (telaBackup) telaBackup.style.display = "none";
    }

    // ==========================================
    // ABRIR UMA TELA
    // ==========================================
    function abrirTela(iframe, arquivo) {
        if (!iframe) return;
        console.log("Abrindo tela:", arquivo);
        esconderTodas();
        iframe.src = arquivo;
        iframe.style.display = "block";
        fecharMenu();
    }

    // ==========================================
    // CLIQUES DOS LINKS
    // ==========================================
    if (linkDashboard) {
        linkDashboard.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaDashboard, "Dashboard.html");
        });
    }

    if (linkVenda) {
        linkVenda.addEventListener("click", function (event) {
            event.preventDefault();
            console.log("CLIQUEI EM VENDAS");
            abrirTela(telaVenda, "Venda.html");
        });
    }

    if (linkCaixa) {
        linkCaixa.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaCaixa, "Caixa.html");
        });
    }

    if (linkEstoque) {
        linkEstoque.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaEstoque, "Estoque.html");
        });
    }

    if (linkRastreador) {
        linkRastreador.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaRastreador, "Rastreador.html");
        });
    }

    if (linkUsuario) {
        linkUsuario.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaUsuario, "Usuario.html");
        });
    }

    if (linkRelatorio) {
        linkRelatorio.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaRelatorio, "Relatorio.html");
        });
    }

    if (linkBackup) {
        linkBackup.addEventListener("click", function (event) {
            event.preventDefault();
            abrirTela(telaBackup, "Backup.html");
        });
    }

    // ==========================================
    // SAIR (Limpando também o Token)
    // ==========================================
    if (btnSair) {
        btnSair.addEventListener("click", function (event) {
            event.preventDefault();

            // Limpa tudo o que salvamos no login
            localStorage.removeItem("meuTokenJWT");
            localStorage.removeItem("id_usuario");
            localStorage.removeItem("usuario");
            localStorage.removeItem("nome_usuario");
            localStorage.removeItem("id_perfil");

            window.location.href = "login.html";
        });
    }

    // ==========================================
    // COMEÇA DIRETAMENTE NO DASHBOARD
    // ==========================================
    abrirTela(telaDashboard, "Dashboard.html");

});

// ==========================================================
// TRANSFORMAR TEXTO EM MAIÚSCULO GLOBALMENTE
// (Fica fora do DOMContentLoaded para agir na página inteira)
// ==========================================================
document.addEventListener('input', function (e) {
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        e.target.value = e.target.value.toUpperCase();
        
        e.target.setSelectionRange(start, end);
    }
});