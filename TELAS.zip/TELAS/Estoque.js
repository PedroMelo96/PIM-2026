// ==========================================
// CONFIGURAÇÃO
// ==========================================
const API_PRODUTO = "https://localhost:7128/api/Produto";
const API_CLASSE = "https://localhost:7128/api/Classe";
const API_ESTOQUE = "https://localhost:7128/api/MovimentacaoEstoque";

// ==========================================
// USUÁRIO LOGADO E TOKEN
// ==========================================
const ID_USUARIO_LOGADO = localStorage.getItem("id_usuario");
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// Se não existe usuário ou token, volta para o login.
if (!ID_USUARIO_LOGADO || !TOKEN_JWT) {
    window.parent.location.href = "login.html";
}

// ==========================================
// MODO INCORPORADO
// ==========================================
if (new URLSearchParams(window.location.search).get("incorporado") === "1") {
    document.body.classList.add("incorporado");
}

// ==========================================
// VARIÁVEIS
// ==========================================
let produtos = [];
let classes = [];

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.parent.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.parent.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }
    
    if (resposta.status === 403) {
        alert("Você não tem permissão para realizar esta ação.");
        throw new Error("Acesso negado.");
    }

    return resposta;
}

// ==========================================
// QUANDO A PÁGINA CARREGAR
// ==========================================
document.addEventListener("DOMContentLoaded", function () {
    carregarProdutos();
    carregarClasses();

    // FORMULÁRIO DE PRODUTO
    const formProduto = document.getElementById("formProduto");
    if (formProduto) {
        formProduto.addEventListener("submit", salvarProduto);
    }

    // FORMULÁRIO DE CLASSE
    const formClasse = document.getElementById("formClasse");
    if (formClasse) {
        formClasse.addEventListener("submit", salvarClasse);
    }

    // SELECT DE PRODUTO PARA AJUSTE
    const produtoAjuste = document.getElementById("produtoAjuste");
    if (produtoAjuste) {
        produtoAjuste.addEventListener("change", mostrarEstoqueAtual);
    }
});

// ==========================================
// VERIFICAR USUÁRIO LOGADO
// ==========================================
function verificarUsuarioLogado() {
    const token = localStorage.getItem("meuTokenJWT");
    if (!token) {
        alert("Sua sessão expirou. Faça login novamente.");
        window.parent.location.href = "login.html";
        return false;
    }
    return true;
}

// ==========================================
// TROCAR DE TELA
// ==========================================
function mostrarTela(nomeTela) {
    const telas = document.querySelectorAll(".tela");
    telas.forEach(function (tela) {
        tela.classList.add("escondida");
    });

    const tela = document.getElementById(nomeTela);
    if (tela) {
        tela.classList.remove("escondida");
    }

    // Atualiza dados
    if (nomeTela === "produtos") carregarProdutos();
    if (nomeTela === "classes") carregarClasses();
    if (nomeTela === "ajusteEstoque") carregarProdutosNoSelect();
}

// ==========================================
// PRODUTOS
// ==========================================
async function carregarProdutos() {
    try {
        const resposta = await fetchComToken(API_PRODUTO);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar produtos.");
        }

        produtos = await resposta.json();
        mostrarProdutos(produtos);
        carregarProdutosNoSelect();

    } catch (erro) {
        console.error(erro);
        alert("Não foi possível carregar os produtos.");
    }
}

// ==========================================
// MOSTRAR PRODUTOS
// ==========================================
function mostrarProdutos(lista) {
    const tabela = document.getElementById("listaProdutos");
    tabela.innerHTML = "";

    if (lista.length === 0) {
        tabela.innerHTML = `
            <tr>
                <td colspan="8"> <!-- Alterado de 7 para 8 -->
                    Nenhum produto encontrado.
                </td>
            </tr>
        `;
        return;
    }

    lista.forEach(function (produto) {
        const status = produto.ativo === "S" ? "Ativo" : "Inativo";
        const classeStatus = produto.ativo === "S" ? "ativo" : "inativo";

        // Verifica se tem markup, se não tiver ou for null, mostra 0%
        const markupTexto = produto.markup ? `${produto.markup}%` : "0%";

        tabela.innerHTML += `
            <tr>
                <td>${produto.id_produto}</td>
                <td>${produto.nome_produto}</td>
                <td>${produto.barras ?? ""}</td>
                <td>${produto.estoque}</td>
                
                <!-- NOVA CÉLULA AQUI -->
                <td>${markupTexto}</td>
                
                <td>R$ ${Number(produto.valor_venda).toFixed(2).replace(".", ",")}</td>
                <td>
                    <span class="status ${classeStatus}">${status}</span>
                </td>
                <td>
                    <div class="acoes">
                        <button class="botao-acao botao-editar" onclick="editarProduto(${produto.id_produto})">✏️</button>
                        <button class="botao-acao" onclick="alterarStatusProduto(${produto.id_produto}, '${produto.ativo}')">
                            ${produto.ativo === "S" ? "🔴" : "🟢"}
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
}

// ==========================================
// PESQUISAR PRODUTO
// ==========================================
function filtrarProdutos() {
    const texto = document.getElementById("pesquisaProduto").value.toLowerCase();

    const resultado = produtos.filter(function (produto) {
        return (
            produto.nome_produto.toLowerCase().includes(texto) ||
            String(produto.barras ?? "").toLowerCase().includes(texto) ||
            String(produto.id_produto).includes(texto)
        );
    });

    mostrarProdutos(resultado);
}

// ==========================================
// CADASTRAR / ALTERAR PRODUTO
// ==========================================
async function salvarProduto(event) {
    event.preventDefault();

    if (!verificarUsuarioLogado()) return;

    const id = document.getElementById("produtoId").value;
    const produto = {
        nome_produto: document.getElementById("nome_produto").value,
        barras: document.getElementById("barras").value,
        estoque: Number(document.getElementById("estoque").value),
        id_classe: document.getElementById("id_classe").value ? Number(document.getElementById("id_classe").value) : null,
        valor_venda: Number(document.getElementById("valor_venda").value.replace(",", ".")),
        valor_compra: Number(document.getElementById("valor_compra").value.replace(",", ".")),
        estoque_minimo: Number(document.getElementById("estoque_minimo").value),
        markup: document.getElementById("markup").value ? Number(document.getElementById("markup").value) : null,
        ativo: "S"
    };

    console.log("Produto enviado para API:", produto);

    try {
        let resposta;

        if (id) {
            // ALTERAR
            resposta = await fetchComToken(`${API_PRODUTO}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(produto)
            });
        } else {
            // CADASTRAR
            resposta = await fetchComToken(API_PRODUTO, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(produto)
            });
        }

        const textoResposta = await resposta.text();

        if (!resposta.ok) {
            throw new Error(`Erro ${resposta.status}: ${textoResposta}`);
        }

        alert(id ? "Produto alterado com sucesso!" : "Produto cadastrado com sucesso!");
        limparFormularioProduto();
        mostrarTela("produtos");
        await carregarProdutos();

    } catch (erro) {
        console.error("ERRO AO SALVAR PRODUTO:", erro);
        alert("Erro ao salvar produto.\n\n" + erro.message);
    }
}

// ==========================================
// EDITAR PRODUTO
// ==========================================
async function editarProduto(id) {
    try {
        const resposta = await fetchComToken(`${API_PRODUTO}/${id}`);

        if (!resposta.ok) {
            throw new Error("Produto não encontrado.");
        }

        const produto = await resposta.json();

        document.getElementById("produtoId").value = produto.id_produto;
        document.getElementById("nome_produto").value = produto.nome_produto;
        document.getElementById("barras").value = produto.barras ?? "";
        document.getElementById("estoque").value = produto.estoque;
        document.getElementById("id_classe").value = produto.id_classe ?? "";
        document.getElementById("valor_venda").value = produto.valor_venda;
        document.getElementById("valor_compra").value = produto.valor_compra;
        document.getElementById("estoque_minimo").value = produto.estoque_minimo;
        document.getElementById("markup").value = produto.markup ?? "";
        mostrarTela("cadastroProduto");

    } catch (erro) {
        console.error("ERRO AO CARREGAR PRODUTO:", erro);
        alert("Erro ao carregar produto.");
    }
}

// ==========================================
// ATIVAR / INATIVAR PRODUTO
// ==========================================
async function alterarStatusProduto(id, statusAtual) {
    if (!verificarUsuarioLogado()) return;

    try {
        const endpoint = statusAtual === "S" 
            ? `${API_PRODUTO}/${id}/inativar` 
            : `${API_PRODUTO}/${id}/ativar`;

        const resposta = await fetchComToken(endpoint, {
            method: "PUT"
        });

        if (!resposta.ok) {
            const texto = await resposta.text();
            throw new Error(`Erro ${resposta.status}: ${texto}`);
        }

        await carregarProdutos();

    } catch (erro) {
        console.error(erro);
        alert("Erro ao alterar status do produto.");
    }
}

// ==========================================
// CLASSES
// ==========================================
async function carregarClasses() {
    try {
        const resposta = await fetchComToken(API_CLASSE);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar classes.");
        }

        classes = await resposta.json();
        mostrarClasses(classes);
        preencherSelectClasses();

    } catch (erro) {
        console.error(erro);
        alert("Não foi possível carregar as classes.");
    }
}

// ==========================================
// MOSTRAR CLASSES
// ==========================================
function mostrarClasses(lista) {
    const tabela = document.getElementById("listaClasses");
    tabela.innerHTML = "";

    if (lista.length === 0) {
        tabela.innerHTML = `
            <tr>
                <td colspan="4">Nenhuma classe encontrada.</td>
            </tr>
        `;
        return;
    }

    lista.forEach(function (classe) {
        const status = classe.ativo === "S" ? "Ativo" : "Inativo";
        const classeStatus = classe.ativo === "S" ? "ativo" : "inativo";

        tabela.innerHTML += `
            <tr>
                <td>${classe.id_classe}</td>
                <td>${classe.nome_classe}</td>
                <td><span class="status ${classeStatus}">${status}</span></td>
                <td>
                    <div class="acoes">
                        <button class="botao-acao" onclick="editarClasse(${classe.id_classe})">✏️</button>
                        <button class="botao-acao" onclick="alterarStatusClasse(${classe.id_classe}, '${classe.ativo}')">
                            ${classe.ativo === "S" ? "🔴" : "🟢"}
                        </button>
                        <td>${classe.desconto ?? 0}%</td>
                    </div>
                </td>
            </tr>
        `;
    });
}

// ==========================================
// SELECT DE CLASSES
// ==========================================
function preencherSelectClasses() {
    const select = document.getElementById("id_classe");
    select.innerHTML = `<option value="">Selecione uma classe</option>`;

    classes.filter(c => c.ativo === "S").forEach(function (classe) {
        select.innerHTML += `
            <option value="${classe.id_classe}">
                ${classe.nome_classe}
            </option>
        `;
    });
}

// ==========================================
// CADASTRAR / ALTERAR CLASSE
// ==========================================
async function salvarClasse(event) {
    event.preventDefault();

    if (!verificarUsuarioLogado()) return;

    const id = document.getElementById("classeId").value;
    const classe = {
        nome_classe: document.getElementById("nome_classe").value,
        desconto: Number(document.getElementById("desconto").value), // <-- CAPTURANDO O DESCONTO AQUI
        ativo: "S"
    };

    try {
        let resposta;

        if (id) {
            resposta = await fetchComToken(`${API_CLASSE}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(classe)
            });
        } else {
            resposta = await fetchComToken(API_CLASSE, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(classe)
            });
        }

        const texto = await resposta.text();

        if (!resposta.ok) {
            throw new Error(`Erro ${resposta.status}: ${texto}`);
        }

        alert(id ? "Classe alterada com sucesso!" : "Classe cadastrada com sucesso!");
        limparFormularioClasse();
        await carregarClasses();

    } catch (erro) {
        console.error(erro);
        alert("Erro ao salvar classe.\n\n" + erro.message);
    }
}

// ==========================================
// EDITAR CLASSE
// ==========================================
async function editarClasse(id) {
    try {
        const resposta = await fetchComToken(`${API_CLASSE}/${id}`);

        if (!resposta.ok) {
            throw new Error("Classe não encontrada.");
        }

        const classe = await resposta.json();

        document.getElementById("classeId").value = classe.id_classe;
        document.getElementById("nome_classe").value = classe.nome_classe;
        
        // <-- PREENCHENDO O DESCONTO (se for null no banco, coloca 0)
        document.getElementById("desconto").value = classe.desconto ?? 0; 

        mostrarTela("classes");

    } catch (erro) {
        console.error(erro);
        alert("Erro ao carregar classe.");
    }
}

// ==========================================
// ATIVAR / INATIVAR CLASSE
// ==========================================
async function alterarStatusClasse(id, statusAtual) {
    if (!verificarUsuarioLogado()) return;

    try {
        const endpoint = statusAtual === "S"
            ? `${API_CLASSE}/${id}/inativar`
            : `${API_CLASSE}/${id}/ativar`;

        const resposta = await fetchComToken(endpoint, {
            method: "PUT"
        });

        if (!resposta.ok) {
            const texto = await resposta.text();
            throw new Error(`Erro ${resposta.status}: ${texto}`);
        }

        await carregarClasses();

    } catch (erro) {
        console.error(erro);
        alert("Erro ao alterar status da classe.");
    }
}

// ==========================================
// AJUSTE DE ESTOQUE
// ==========================================
function carregarProdutosNoSelect() {
    const select = document.getElementById("produtoAjuste");
    if (!select) return;

    select.innerHTML = `<option value="">Selecione um produto</option>`;

    produtos.filter(p => p.ativo === "S").forEach(function (produto) {
        select.innerHTML += `
            <option value="${produto.id_produto}">
                ${produto.nome_produto}
            </option>
        `;
    });
}

// ==========================================
// MOSTRAR ESTOQUE ATUAL
// ==========================================
function mostrarEstoqueAtual() {
    const id = Number(document.getElementById("produtoAjuste").value);
    const produto = produtos.find(p => p.id_produto === id);

    if (produto) {
        document.getElementById("estoqueAtual").value = produto.estoque;
    } else {
        document.getElementById("estoqueAtual").value = "";
    }
}

// ==========================================
// AJUSTAR ESTOQUE
// ==========================================
async function ajustarEstoque() {
    if (!verificarUsuarioLogado()) return;

    const id = Number(document.getElementById("produtoAjuste").value);
    const novoEstoque = Number(document.getElementById("novoEstoque").value);

    if (!id) {
        alert("Selecione um produto.");
        return;
    }

    if (isNaN(novoEstoque) || novoEstoque < 0) {
        alert("Informe um estoque válido.");
        return;
    }

    try {
        const respostaBusca = await fetchComToken(`${API_PRODUTO}/${id}`);

        if (!respostaBusca.ok) {
            throw new Error("Produto não encontrado.");
        }

        const produto = await respostaBusca.json();
        const estoqueAnterior = Number(produto.estoque);

        if (novoEstoque === estoqueAnterior) {
            alert("O novo estoque é igual ao estoque atual.");
            return;
        }

        const diferenca = novoEstoque - estoqueAnterior;
        let tipo;
        let quantidade;

        if (diferenca > 0) {
            tipo = 1; // ENTRADA
            quantidade = diferenca;
        } else {
            tipo = 2; // SAÍDA
            quantidade = Math.abs(diferenca);
        }

        const movimentacao = {
            id_produto: id,
            tipo: tipo,
            quantidade: quantidade,
            descricao: tipo === 1 ? "Ajuste de estoque - entrada" : "Ajuste de estoque - saída"
        };

        const resposta = await fetchComToken(`${API_ESTOQUE}/ajustar`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(movimentacao)
        });

        const textoResposta = await resposta.text();

        if (!resposta.ok) {
            throw new Error(`Erro ${resposta.status}: ${textoResposta}`);
        }

        alert("Estoque ajustado com sucesso!");
        document.getElementById("novoEstoque").value = "";
        await carregarProdutos();
        mostrarEstoqueAtual();

    } catch (erro) {
        console.error("ERRO AO AJUSTAR ESTOQUE:", erro);
        alert("Erro ao ajustar estoque.\n\n" + erro.message);
    }
}

// ==========================================
// LIMPAR FORMULÁRIOS
// ==========================================
function limparFormularioProduto() {
    document.getElementById("formProduto").reset();
    document.getElementById("produtoId").value = "";
}

function limparFormularioClasse() {
    document.getElementById("formClasse").reset();
    document.getElementById("classeId").value = "";
}
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});

// ==========================================
// CÁLCULOS AUTOMÁTICOS: MARKUP E VENDA
// ==========================================
const inputCompra = document.getElementById("valor_compra");
const inputMarkup = document.getElementById("markup");
const inputVenda = document.getElementById("valor_venda");

if (inputCompra && inputMarkup && inputVenda) {
    // Se o usuário digitar na Compra ou no Markup, calcula a Venda
    inputCompra.addEventListener("input", calcularVendaPeloMarkup);
    inputMarkup.addEventListener("input", calcularVendaPeloMarkup);

    // Se o usuário digitar direto na Venda, calcula o Markup
    inputVenda.addEventListener("input", calcularMarkupPelaVenda);
}

function calcularVendaPeloMarkup() {
    // Pega os valores digitados (substitui vírgula por ponto para o cálculo)
    const compra = parseFloat(inputCompra.value.replace(",", ".")) || 0;
    const markup = parseFloat(inputMarkup.value) || 0;

    if (compra > 0) {
        // Fórmula: Compra + (Compra * (Markup / 100))
        const venda = compra + (compra * (markup / 100));
        
        // Preenche o campo de venda com 2 casas decimais
        inputVenda.value = venda.toFixed(2);
    }
}

function calcularMarkupPelaVenda() {
    const compra = parseFloat(inputCompra.value.replace(",", ".")) || 0;
    const venda = parseFloat(inputVenda.value.replace(",", ".")) || 0;

    if (compra > 0 && venda >= compra) {
        // Fórmula: ((Venda - Compra) / Compra) * 100
        const markup = ((venda - compra) / compra) * 100;
        
        // Preenche o campo de markup arredondando o valor
        inputMarkup.value = Math.round(markup);
    } else if (compra > 0 && venda < compra) {
        // Se a venda for menor que a compra (prejuízo), zera o markup
        inputMarkup.value = 0;
    }
}