// =========================================================
// CONFIGURAÇÃO
// =========================================================
const API_DASHBOARD = "https://localhost:7128/api/Dashboard";

// =========================================================
// USUÁRIO LOGADO E TOKEN
// =========================================================
const NOME_USUARIO = localStorage.getItem("nome_usuario") || "Usuário";
const TOKEN_JWT = localStorage.getItem("meuTokenJWT");

// Se não existe token, volta para a tela de login.
if (!TOKEN_JWT) {
    window.parent.location.href = "login.html";
}

// ==========================================================
// FUNÇÃO CENTRAL PARA CHAMADAS COM TOKEN JWT
// ==========================================================
async function fetchComToken(url, options = {}) {
    const token = localStorage.getItem("meuTokenJWT");

    if (!token) {
        window.parent.location.href = "login.html";
        throw new Error("Usuário não autenticado.");
    }

    if (!options.headers) {
        options.headers = {};
    }

    options.headers["Authorization"] = `Bearer ${token}`;

    const resposta = await fetch(url, options);

    if (resposta.status === 401) {
        alert("Sua sessão expirou. Por favor, faça login novamente.");
        localStorage.removeItem("meuTokenJWT");
        window.parent.location.href = "login.html";
        throw new Error("Sessão expirada.");
    }

    return resposta;
}

// =========================================================
// INICIALIZAÇÃO
// =========================================================
document.addEventListener("DOMContentLoaded", function () {
    console.log("=================================");
    console.log("DASHBOARD.JS FOI CARREGADO");
    console.log("=================================");

    // ==========================================
    // MOSTRAR USUÁRIO
    // ==========================================
    const usuarioLogado = document.getElementById("usuarioLogado");
    if (usuarioLogado) {
        usuarioLogado.textContent = NOME_USUARIO;
    }

    // ==========================================
    // MOSTRAR DATA E HORA IMEDIATAMENTE
    // ==========================================
    atualizarDataHora();

    // ==========================================
    // ATUALIZAR RELÓGIO
    // ==========================================
    setInterval(atualizarDataHora, 1000);

    // ==========================================
    // CARREGAR DADOS DO DASHBOARD
    // ==========================================
    carregarDashboard();
});

// =========================================================
// DATA E HORA
// =========================================================
function atualizarDataHora() {
    const agora = new Date();

    // ==========================================
    // DATA
    // ==========================================
    const data = agora.toLocaleDateString("pt-BR");

    // ==========================================
    // HORA
    // ==========================================
    const hora = agora.toLocaleTimeString("pt-BR");

    // ==========================================
    // ELEMENTOS
    // ==========================================
    const dataAtual = document.getElementById("dataAtual");
    const horaAtual = document.getElementById("horaAtual");
    const dataResumo = document.getElementById("dataResumo");
    const horaResumo = document.getElementById("horaResumo");

    // ==========================================
    // ATUALIZAR DATA DO CABEÇALHO
    // ==========================================
    if (dataAtual) {
        dataAtual.textContent = data;
    }

    // ==========================================
    // ATUALIZAR HORA DO CABEÇALHO
    // ==========================================
    if (horaAtual) {
        horaAtual.textContent = hora;
    }

    // ==========================================
    // ATUALIZAR DATA DO RESUMO
    // ==========================================
    if (dataResumo) {
        dataResumo.textContent = data;
    }

    // ==========================================
    // ATUALIZAR HORA DO RESUMO
    // ==========================================
    if (horaResumo) {
        horaResumo.textContent = hora;
    }
}

// =========================================================
// CARREGAR DASHBOARD
// =========================================================
async function carregarDashboard() {
    const mensagem = document.getElementById("mensagemDashboard");

    if (mensagem) {
        mensagem.textContent = "Atualizando informações...";
    }

    try {
        console.log("Consultando API do Dashboard...");

        // ==========================================
        // USANDO FETCH COM TOKEN JWT
        // ==========================================
        const resposta = await fetchComToken(API_DASHBOARD);

        // ==========================================
        // VERIFICAR RESPOSTA
        // ==========================================
        if (!resposta.ok) {
            let texto = "Erro ao carregar dashboard.";

            try {
                const erro = await resposta.json();
                texto = erro.mensagem || texto;
            } catch {
                // Não conseguiu ler o JSON
            }

            throw new Error(texto);
        }

        // ==========================================
        // CONVERTER JSON
        // ==========================================
        const dados = await resposta.json();

        console.log("Dados recebidos:", dados);

        // ==========================================
        // MOSTRAR DADOS
        // ==========================================
        mostrarDashboard(dados);

        // ==========================================
        // MENSAGEM
        // ==========================================
        if (mensagem) {
            mensagem.textContent = `Atualizado às ${new Date().toLocaleTimeString("pt-BR")}`;
        }
    } catch (erro) {
        console.error("Erro no dashboard:", erro);

        if (mensagem) {
            mensagem.textContent = "Não foi possível carregar os dados do dashboard.";
        }

        alert(erro.message || "Erro ao carregar dashboard.");
    }
}

// =========================================================
// MOSTRAR DASHBOARD
// =========================================================
function mostrarDashboard(dados) {
    // =====================================================
    // FATURAMENTO
    // =====================================================
    const faturamento = Number(dados.faturamentoHoje || 0);
    const elementoFaturamento = document.getElementById("faturamentoHoje");

    if (elementoFaturamento) {
        elementoFaturamento.textContent = formatarMoeda(faturamento);
    }

    // =====================================================
    // FATURAMENTO DO RESUMO
    // =====================================================
    const faturamentoResumo = document.getElementById("faturamentoResumo");

    if (faturamentoResumo) {
        faturamentoResumo.textContent = formatarMoeda(faturamento);
    }

    // =====================================================
    // QUANTIDADE DE VENDAS
    // =====================================================
    const vendasHoje = document.getElementById("vendasHoje");

    if (vendasHoje) {
        vendasHoje.textContent = dados.quantidadeVendasHoje || 0;
    }

    // =====================================================
    // PRODUTO MAIS VENDIDO
    // =====================================================
    const produtoMaisVendido = document.getElementById("produtoMaisVendido");
    const quantidadeMaisVendido = document.getElementById("quantidadeMaisVendido");

    if (dados.produtoMaisVendido) {
        if (produtoMaisVendido) {
            produtoMaisVendido.textContent = dados.produtoMaisVendido.nomeProduto;
        }

        if (quantidadeMaisVendido) {
            quantidadeMaisVendido.textContent = `${dados.produtoMaisVendido.quantidadeVendida} unidades`;
        }
    } else {
        if (produtoMaisVendido) {
            produtoMaisVendido.textContent = "Nenhum";
        }

        if (quantidadeMaisVendido) {
            quantidadeMaisVendido.textContent = "Nenhuma venda hoje";
        }
    }

    // =====================================================
    // ESTOQUE
    // =====================================================
    mostrarEstoque(dados.produtosEstoqueMinimo || []);
}

// =========================================================
// MOSTRAR PRODUTOS ABAIXO DO ESTOQUE MÍNIMO
// =========================================================
function mostrarEstoque(produtos) {
    const tbody = document.getElementById("listaEstoque");
    const contador = document.getElementById("contadorEstoque");
    const resumo = document.getElementById("estoqueBaixoResumo");

    // ==========================================
    // CONTADOR
    // ==========================================
    if (contador) {
        contador.textContent = `${produtos.length} produto${produtos.length === 1 ? "" : "s"}`;
    }

    // ==========================================
    // RESUMO
    // ==========================================
    if (resumo) {
        resumo.textContent = produtos.length;
    }

    // ==========================================
    // SE NÃO EXISTIR TABELA
    // ==========================================
    if (!tbody) {
        return;
    }

    // ==========================================
    // NENHUM PRODUTO
    // ==========================================
    if (produtos.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5">
                    Nenhum produto está abaixo do estoque mínimo.
                </td>
            </tr>
        `;
        return;
    }

    // ==========================================
    // MONTAR TABELA
    // ==========================================
    tbody.innerHTML = produtos.map(produto => {
        const estoque = Number(produto.estoque || 0);
        const minimo = Number(produto.estoqueMinimo || 0);

        // ==================================
        // STATUS
        // ==================================
        let classeStatus = "status-baixo";
        let textoStatus = "BAIXO";

        // ==================================
        // SEM ESTOQUE
        // ==================================
        if (estoque <= 0) {
            classeStatus = "status-critico";
            textoStatus = "SEM ESTOQUE";
        }

        // ==================================
        // HTML DA LINHA
        // ==================================
        return `
            <tr>
                <td>#${produto.idProduto}</td>
                <td>
                    <strong>${produto.nomeProduto}</strong>
                </td>
                <td>${estoque}</td>
                <td>${minimo}</td>
                <td>
                    <span class="${classeStatus}">
                        ${textoStatus}
                    </span>
                </td>
            </tr>
        `;
    }).join("");
}

// =========================================================
// FORMATAR MOEDA
// =========================================================
function formatarMoeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

// =========================================================
// VOLTAR
// =========================================================
function voltar() {
    window.history.back();
}
// Transforma automaticamente qualquer texto digitado em inputs para MAIÚSCULO
document.addEventListener('input', function (e) {
    // Verifica se o elemento que disparou o evento é um campo de texto
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') {
        // Salva a posição do cursor para ele não pular para o final ao digitar no meio da palavra
        let start = e.target.selectionStart;
        let end = e.target.selectionEnd;
        
        // Converte o valor real para maiúsculo
        e.target.value = e.target.value.toUpperCase();
        
        // Restaura a posição do cursor
        e.target.setSelectionRange(start, end);
    }
});