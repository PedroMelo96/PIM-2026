﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("classe")]
    public class Classe
    {
        [Key]
        public int id_classe { get; set; }

        [Required]
        [MaxLength(255)] 
        public string nome_classe { get; set; }

        [MaxLength(1)]
        public string ativo { get; set; } = "S";


        public int? desconto { get; set; } = 0;

        public DateTime data_cadastro { get; set; } = DateTime.Now;
        public DateTime? data_atualizacao { get; set; }
        public DateTime? data_inativacao { get; set; }
    }
}