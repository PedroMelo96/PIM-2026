﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("Perfis")]
    public class Perfil
    {
        [Key]
        public int id_perfil { get; set; }

        [Required]
        [MaxLength(50)]
        public string perfil { get; set; }
    }
}