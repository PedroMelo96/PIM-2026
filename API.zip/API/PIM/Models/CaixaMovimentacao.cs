﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("CaixasMovimentacoes")]
    public class CaixaMovimentacao
    {
        [Key]
        public int Id_movimentacao { get; set; }

        public int Id_caixa { get; set; }

        public int Tipo { get; set; }

        [MaxLength(255)]
        public string? Descricao { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Valor { get; set; }

        [Required]
        public DateTime Data_movimentacao { get; set; }
    }
}