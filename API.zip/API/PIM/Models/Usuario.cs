﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("usuario")] 
    public class Usuario
    {
        [Key]
        public int id_usuario { get; set; }

        [Required]
        [MaxLength(255)] 
        public string nome_usuario { get; set; }

        [Required]
        [MaxLength(255)] 
        public string usuario { get; set; }

        [Required]
        [MaxLength(255)] 
        public string senha { get; set; }

        public int id_perfil { get; set; }

        [MaxLength(255)] 
        public string ativo { get; set; } = "S";

       
        public DateTime data_cadastro { get; set; } = DateTime.Now;
        public DateTime? data_atualizacao { get; set; }
        public DateTime? data_inativacao { get; set; }
    }
}