﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("VendasItens")]
    public class VendaItem
    {
        [Key]
        public int Id_item { get; set; }

        public int Id_venda { get; set; }

        public int Id_produto { get; set; }

        public int Quantidade { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Valor_unitario { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Valor_total { get; set; }
    }
}