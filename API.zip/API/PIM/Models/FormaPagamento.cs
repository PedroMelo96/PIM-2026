﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("FormasPagamento")]
    public class FormaPagamento
    {
        [Key]
        public int Id_forma_pagamento { get; set; }

        [Required]
        [MaxLength(50)]
        public string Nome_forma { get; set; } = string.Empty;
    }
}