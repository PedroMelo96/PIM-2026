﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("produto")]
    public class Produto
    {
        [Key]
        public int id_produto { get; set; }

        [Required(ErrorMessage = "O nome do produto é obrigatório.")]
        [MaxLength(255)]
        public string nome_produto { get; set; } = string.Empty;

        [MaxLength(50)]
        public string barras { get; set; } = string.Empty;

        public int estoque { get; set; }

        // ID da classe à qual o produto pertence
        public int? id_classe { get; set; }

        // Relacionamento com a classe
        [ForeignKey(nameof(id_classe))]
        public Classe? Classe { get; set; }

        [Required]
        [Column(TypeName = "decimal(12,2)")]
        public decimal valor_venda { get; set; }

        [Required]
        [Column(TypeName = "decimal(12,2)")]
        public decimal valor_compra { get; set; }

        public int estoque_minimo { get; set; }

        [MaxLength(255)]
        public string ativo { get; set; } = "S";

        public int? markup { get; set; }

        // Campos de auditoria
        public DateTime data_cadastro { get; set; } = DateTime.Now;
        public DateTime? data_atualizacao { get; set; }
        public DateTime? data_inativacao { get; set; }
    }
}
