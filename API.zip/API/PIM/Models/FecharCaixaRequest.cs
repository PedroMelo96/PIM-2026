﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [NotMapped]
    public class FecharCaixaRequest
    {
        public decimal Valor_fechamento { get; set; }
    }
}