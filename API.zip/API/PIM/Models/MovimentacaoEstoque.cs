﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("MovimentacoesEstoque")]
    public class MovimentacaoEstoque
    {
        [Key]
        public int Id_movimentacao { get; set; }

        public int Id_produto { get; set; }

        public int Id_usuario { get; set; }

        public int Tipo { get; set; }

        public int Quantidade { get; set; }

        public int Estoque_anterior { get; set; }

        public int Estoque_atual { get; set; }

        [MaxLength(255)]
        public string? Descricao { get; set; }

        [Required]
        public DateTime Data_movimentacao { get; set; }
    }
}