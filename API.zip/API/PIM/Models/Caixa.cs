﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("Caixas")]
    public class Caixa
    {
        [Key]
        public int Id_caixa { get; set; }

        public int Id_usuario { get; set; }

        [Required]
        public DateTime Data_abertura { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Valor_abertura { get; set; }

        public DateTime? Data_fechamento { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal? Valor_fechamento { get; set; }

        public int Status { get; set; }
    }
}