﻿namespace PIM.Models
{
    public class VendaPagamento
    {
        public int Id_venda_pagamento { get; set; }

        public int Id_venda { get; set; }

        public int Id_forma_pagamento { get; set; }

        public decimal Valor { get; set; }
    }
}
