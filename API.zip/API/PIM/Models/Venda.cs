﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("Vendas")]
    public class Venda
    {
        [Key]
        public int Id_venda { get; set; }

        [Required]
        public DateTime Data_venda { get; set; }

        public int Id_usuario { get; set; }

        public int Id_caixa { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Valor_total { get; set; }

        public int Status { get; set; }

        [NotMapped]
        public decimal Desconto { get; set; }

        public List<VendaItem> Itens { get; set; } = new();

        [NotMapped]
        public List<VendaPagamento> Pagamentos { get; set; } = new();
    }
}