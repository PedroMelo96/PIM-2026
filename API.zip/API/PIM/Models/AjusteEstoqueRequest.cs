﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [NotMapped]
    public class AjusteEstoqueRequest
    {
        public int Id_produto { get; set; }

        public int Tipo { get; set; }

        public int Quantidade { get; set; }

        public string? Descricao { get; set; }
    }
}