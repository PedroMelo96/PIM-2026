﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("Logs")]
    public class Log
    {
        [Key]
        public int Id_log { get; set; }

        public int Id_usuario { get; set; }

        [Required]
        [MaxLength(50)]
        public string Acao { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Tabela { get; set; } = string.Empty;

        public int? Id_registro { get; set; }

        [MaxLength(500)]
        public string? Descricao { get; set; }

        [Required]
        public DateTime Data_log { get; set; }
    }
}