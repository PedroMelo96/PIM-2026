﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class LogService
    {
        private readonly AppDbContext _context;

        public LogService(AppDbContext context) => _context = context;

        public async Task<List<Log>> ListarTodos() => await _context.Set<Log>().ToListAsync();

        public async Task RegistrarLog(int idUsuario, string acao, string tabela, int? idRegistro, string descricao)
        {
            var log = new Log
            {
                Id_usuario = idUsuario,
                Acao = acao,
                Tabela = tabela,
                Id_registro = idRegistro,
                Descricao = descricao,
                Data_log = DateTime.Now
            };

            _context.Set<Log>().Add(log);
            await _context.SaveChangesAsync();
        }
    }
}