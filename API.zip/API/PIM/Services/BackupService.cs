﻿
using MySqlConnector;
using System.Diagnostics;

namespace PIM.Services
{
    public class BackupService
    {
        private readonly IConfiguration _configuration;

        public BackupService(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        // ==========================================
        // GERAR BACKUP
        // ==========================================

        public async Task<string> GerarBackup()
        {
            // ------------------------------------------
            // PEGA A STRING DE CONEXÃO
            // ------------------------------------------

            var connectionString =
                _configuration.GetConnectionString(
                    "DefaultConnection"
                );

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new InvalidOperationException(
                    "A conexão com o banco de dados não foi encontrada."
                );
            }


            // ------------------------------------------
            // LÊ OS DADOS DA CONEXÃO MYSQL
            // ------------------------------------------

            var builder =
                new MySqlConnectionStringBuilder(
                    connectionString
                );


            string banco =
                builder.Database;

            string servidor =
                builder.Server;

            string usuario =
                builder.UserID;

            string senha =
                builder.Password;

            uint porta =
                builder.Port;


            if (string.IsNullOrWhiteSpace(banco))
            {
                throw new InvalidOperationException(
                    "O nome do banco de dados não foi encontrado."
                );
            }


            // ------------------------------------------
            // ÁREA DE TRABALHO
            // ------------------------------------------

            string areaTrabalho =
                Environment.GetFolderPath(
                    Environment.SpecialFolder.DesktopDirectory
                );


            // ------------------------------------------
            // PASTA DE BACKUPS
            // ------------------------------------------

            string pastaBackup =
                Path.Combine(
                    areaTrabalho,
                    "Backups_PIM"
                );


            Directory.CreateDirectory(
                pastaBackup
            );


            // ------------------------------------------
            // NOME DO ARQUIVO
            // ------------------------------------------

            string dataHora =
                DateTime.Now.ToString(
                    "yyyy-MM-dd_HH-mm-ss"
                );


            string nomeArquivo =
                $"Backup_PIM_{dataHora}.sql";


            string caminhoArquivo =
                Path.Combine(
                    pastaBackup,
                    nomeArquivo
                );


            // ------------------------------------------
            // LOCALIZAR MYSQLDUMP
            // ------------------------------------------

            string caminhoMysqlDump =
                LocalizarMysqlDump();


            if (string.IsNullOrWhiteSpace(
                caminhoMysqlDump))
            {
                throw new FileNotFoundException(
                    "O mysqldump.exe não foi encontrado."
                );
            }


            // ------------------------------------------
            // CONFIGURA O PROCESSO
            // ------------------------------------------

            var processo =
                new Process();


            processo.StartInfo =
                new ProcessStartInfo
                {
                    FileName =
                        caminhoMysqlDump,

                    UseShellExecute =
                        false,

                    RedirectStandardOutput =
                        false,

                    RedirectStandardError =
                        true,

                    CreateNoWindow =
                        true
                };


            // ------------------------------------------
            // ARGUMENTOS DO MYSQLDUMP
            // ------------------------------------------

            processo.StartInfo.ArgumentList.Add(
                $"--host={servidor}"
            );

            processo.StartInfo.ArgumentList.Add(
                $"--port={porta}"
            );

            processo.StartInfo.ArgumentList.Add(
                $"--user={usuario}"
            );

            processo.StartInfo.ArgumentList.Add(
                $"--password={senha}"
            );

            processo.StartInfo.ArgumentList.Add(
                "--single-transaction"
            );

            processo.StartInfo.ArgumentList.Add(
                "--routines"
            );

            processo.StartInfo.ArgumentList.Add(
                "--triggers"
            );

            processo.StartInfo.ArgumentList.Add(
                $"--result-file={caminhoArquivo}"
            );

            processo.StartInfo.ArgumentList.Add(
                banco
            );


            // ------------------------------------------
            // EXECUTA O MYSQLDUMP
            // ------------------------------------------

            processo.Start();


            string erro =
                await processo
                    .StandardError
                    .ReadToEndAsync();


            await processo
                .WaitForExitAsync();


            // ------------------------------------------
            // VERIFICA SE DEU ERRO
            // ------------------------------------------

            if (processo.ExitCode != 0)
            {
                if (File.Exists(caminhoArquivo))
                {
                    File.Delete(caminhoArquivo);
                }


                throw new InvalidOperationException(
                    "Erro ao executar o mysqldump: " +
                    erro
                );
            }


            // ------------------------------------------
            // VERIFICA SE O ARQUIVO FOI CRIADO
            // ------------------------------------------

            if (!File.Exists(caminhoArquivo))
            {
                throw new InvalidOperationException(
                    "O backup não foi criado."
                );
            }


            // ------------------------------------------
            // RETORNA O CAMINHO
            // ------------------------------------------

            return caminhoArquivo;
        }


        // ==========================================
        // LISTAR BACKUPS
        // ==========================================

        public List<object> ListarBackups()
        {
            // ------------------------------------------
            // ÁREA DE TRABALHO
            // ------------------------------------------

            string areaTrabalho =
                Environment.GetFolderPath(
                    Environment.SpecialFolder.DesktopDirectory
                );


            // ------------------------------------------
            // PASTA DE BACKUPS
            // ------------------------------------------

            string pastaBackup =
                Path.Combine(
                    areaTrabalho,
                    "Backups_PIM"
                );


            // ------------------------------------------
            // VERIFICA SE A PASTA EXISTE
            // ------------------------------------------

            if (!Directory.Exists(pastaBackup))
            {
                return new List<object>();
            }


            // ------------------------------------------
            // PEGA OS ARQUIVOS SQL
            // ------------------------------------------

            var arquivos =
                Directory
                    .GetFiles(
                        pastaBackup,
                        "*.sql"
                    )
                    .OrderByDescending(
                        x => File.GetCreationTime(x)
                    );


            // ------------------------------------------
            // RESULTADO
            // ------------------------------------------

            var resultado =
                new List<object>();


            foreach (var arquivo in arquivos)
            {
                var informacoes =
                    new FileInfo(arquivo);


                resultado.Add(
                    new
                    {
                        nome =
                            informacoes.Name,

                        data =
                            informacoes.CreationTime,

                        tamanho =
                            informacoes.Length
                    }
                );
            }


            return resultado;
        }


        // ==========================================
        // LOCALIZAR MYSQLDUMP
        // ==========================================

        private string LocalizarMysqlDump()
        {
            // ------------------------------------------
            // MYSQL 5.7
            // ------------------------------------------

            string caminhoMysql57 =
                @"C:\Program Files\MySQL\MySQL Server 5.7\bin\mysqldump.exe";


            if (File.Exists(caminhoMysql57))
            {
                return caminhoMysql57;
            }


            // ------------------------------------------
            // TENTA PELO PATH DO WINDOWS
            // ------------------------------------------

            try
            {
                using var processo =
                    new Process();


                processo.StartInfo =
                    new ProcessStartInfo
                    {
                        FileName =
                            "mysqldump.exe",

                        Arguments =
                            "--version",

                        UseShellExecute =
                            false,

                        RedirectStandardOutput =
                            true,

                        RedirectStandardError =
                            true,

                        CreateNoWindow =
                            true
                    };


                processo.Start();

                processo.WaitForExit();


                if (processo.ExitCode == 0)
                {
                    return "mysqldump.exe";
                }
            }
            catch
            {
                // Continua procurando nos outros locais.
            }


            // ------------------------------------------
            // OUTROS CAMINHOS COMUNS
            // ------------------------------------------

            string[] caminhos =
            {
                @"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe",

                @"C:\Program Files\MySQL\MySQL Server 8.4\bin\mysqldump.exe",

                @"C:\Program Files\MySQL\MySQL Server 9.0\bin\mysqldump.exe",

                @"C:\xampp\mysql\bin\mysqldump.exe",

                @"C:\wamp64\bin\mysql\mysql8.0.31\bin\mysqldump.exe"
            };


            // ------------------------------------------
            // PROCURA NOS CAMINHOS
            // ------------------------------------------

            foreach (var caminho in caminhos)
            {
                if (File.Exists(caminho))
                {
                    return caminho;
                }
            }


            // ------------------------------------------
            // NÃO ENCONTROU
            // ------------------------------------------

            return string.Empty;
        }
    }
}
