﻿
using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Services
{
    public class VendaService
    {
        private readonly AppDbContext _context;
        private readonly LogService _logService;

        public VendaService(
            AppDbContext context,
            LogService logService)
        {
            _context = context;
            _logService = logService;
        }

        // ==========================================
        // LISTAR TODAS
        // ==========================================

        public async Task<List<Venda>> ListarTodas()
        {
            return await _context.Set<Venda>()
                .Include(v => v.Itens)
                .Include(v => v.Pagamentos)
                .OrderByDescending(v => v.Data_venda)
                .ToListAsync();
        }
        // ==========================================
        // LISTAR VENDAS DO CAIXA
        // ==========================================

        public async Task<List<Venda>> ListarPorCaixa(int idCaixa)
        {
            return await _context.Venda
                .Include(v => v.Itens)
                .Include(v => v.Pagamentos)
                .Where(v => v.Id_caixa == idCaixa)
                .OrderByDescending(v => v.Data_venda)
                .ToListAsync();
        }

        // ==========================================
        // BUSCAR POR ID
        // ==========================================

        public async Task<Venda?> BuscarPorId(int id)
        {
            return await _context.Set<Venda>()
                .Include(v => v.Itens)
                .Include(v => v.Pagamentos)
                .FirstOrDefaultAsync(v =>
                    v.Id_venda == id);
        }


        // ==========================================
        // REALIZAR VENDA
        // ==========================================

        public async Task<Venda> RealizarVenda(Venda venda)
        {
            using var transaction =
                await _context.Database.BeginTransactionAsync();

            try
            {
                // ==========================================
                // VALIDAÇÕES BÁSICAS
                // ==========================================

                if (venda.Id_usuario <= 0)
                {
                    throw new InvalidOperationException(
                        "Usuário da venda não informado.");
                }

                if (venda.Id_caixa <= 0)
                {
                    throw new InvalidOperationException(
                        "Caixa da venda não informado.");
                }

                if (venda.Itens == null ||
                    venda.Itens.Count == 0)
                {
                    throw new InvalidOperationException(
                        "A venda precisa possuir pelo menos um produto.");
                }

                if (venda.Pagamentos == null ||
                    venda.Pagamentos.Count == 0)
                {
                    throw new InvalidOperationException(
                        "A venda precisa possuir pelo menos uma forma de pagamento.");
                }


                // ==========================================
                // VERIFICAR USUÁRIO
                // ==========================================

                var usuario = await _context.Usuario
                    .FirstOrDefaultAsync(u =>
                        u.id_usuario == venda.Id_usuario);

                if (usuario == null)
                {
                    throw new InvalidOperationException(
                        "Usuário não encontrado.");
                }

                if (usuario.ativo != "S")
                {
                    throw new InvalidOperationException(
                        "O usuário está inativo.");
                }


                // ==========================================
                // VERIFICAR CAIXA
                // ==========================================

                var caixa = await _context.Caixas
                    .FirstOrDefaultAsync(c =>
                        c.Id_caixa == venda.Id_caixa);

                if (caixa == null)
                {
                    throw new InvalidOperationException(
                        "Caixa não encontrado.");
                }

                if (caixa.Status == 0)
                {
                    throw new InvalidOperationException(
                        "O caixa está fechado.");
                }

                if (caixa.Id_usuario != venda.Id_usuario)
                {
                    throw new InvalidOperationException(
                        "O caixa pertence a outro usuário.");
                }


                // ==========================================
                // CALCULAR TOTAL DOS ITENS E VALIDAR DESCONTO DA CLASSE
                // ==========================================

                decimal totalVenda = 0;
                decimal descontoMaximoPermitidoPercentual = 100; // Padrão

                foreach (var item in venda.Itens)
                {
                    // Traz o produto junto com os dados da classe cadastrada
                    var produto = await _context.Produto
                        .Include(p => p.Classe)
                        .FirstOrDefaultAsync(p =>
                            p.id_produto == item.Id_produto);

                    if (produto == null)
                    {
                        throw new InvalidOperationException(
                            $"Produto {item.Id_produto} não encontrado.");
                    }

                    if (produto.ativo != "S")
                    {
                        throw new InvalidOperationException(
                            $"O produto {produto.nome_produto} está inativo.");
                    }

                    if (item.Quantidade <= 0)
                    {
                        throw new InvalidOperationException(
                            "A quantidade do produto deve ser maior que zero.");
                    }

                    if (produto.estoque < item.Quantidade)
                    {
                        throw new InvalidOperationException(
                            $"Estoque insuficiente para o produto {produto.nome_produto}.");
                    }

                    // Se o produto pertence a uma classe com limite de desconto definido
                    if (produto.Classe != null)
                    {
                        // Converte explicitamente caso a propriedade da classe seja int ou int?
                        decimal limiteClasse = Convert.ToDecimal(produto.Classe.desconto);

                        // Pega o menor limite entre os produtos da venda para garantir segurança total
                        if (limiteClasse < descontoMaximoPermitidoPercentual)
                        {
                            descontoMaximoPermitidoPercentual = limiteClasse;
                        }
                    }

                    // ==========================================
                    // PREÇO DO PRODUTO
                    // ==========================================

                    item.Valor_unitario = produto.valor_venda;

                    // ==========================================
                    // TOTAL DO ITEM
                    // ==========================================

                    item.Valor_total = item.Quantidade * item.Valor_unitario;

                    totalVenda += item.Valor_total;
                }

                totalVenda = Math.Round(totalVenda, 2);

                // ==========================================
                // VALIDAR DESCONTO DA VENDA CONTRA O TETO DA CLASSE
                // ==========================================

                if (venda.Desconto < 0)
                {
                    throw new InvalidOperationException(
                        "O desconto não pode ser negativo.");
                }

                // Converte o desconto em reais informado para percentual para comparar com a classe
                decimal percentualDescontoInformado = totalVenda > 0 ? (venda.Desconto / totalVenda) * 100 : 0;

                if (percentualDescontoInformado > descontoMaximoPermitidoPercentual)
                {
                    throw new InvalidOperationException(
                        $"O desconto informado ultrapassa o limite permitido pelas classes dos produtos ({descontoMaximoPermitidoPercentual}%).");
                }

                if (venda.Desconto > totalVenda)
                {
                    throw new InvalidOperationException(
                        "O desconto não pode ser maior que o valor da venda.");
                }

                venda.Desconto = Math.Round(venda.Desconto, 2);

                // ==========================================
                // ARREDONDAR SUBTOTAL
                // ==========================================

                totalVenda =
                    Math.Round(
                        totalVenda,
                        2);


                // ==========================================
                // VALIDAR DESCONTO
                // ==========================================

                if (venda.Desconto < 0)
                {
                    throw new InvalidOperationException(
                        "O desconto não pode ser negativo.");
                }

                if (venda.Desconto > totalVenda)
                {
                    throw new InvalidOperationException(
                        "O desconto não pode ser maior que o valor da venda.");
                }


                // ==========================================
                // ARREDONDAR DESCONTO
                // ==========================================

                venda.Desconto =
                    Math.Round(
                        venda.Desconto,
                        2);


                // ==========================================
                // CALCULAR TOTAL FINAL
                // ==========================================

                decimal totalFinal =
                    totalVenda -
                    venda.Desconto;


                totalFinal =
                    Math.Round(
                        totalFinal,
                        2);


                // ==========================================
                // GRAVAR TOTAL FINAL
                // ==========================================

                venda.Valor_total =
                    totalFinal;


                // ==========================================
                // VALIDAR PAGAMENTOS
                // ==========================================

                decimal totalPagamentos = 0;

                foreach (var pagamento in venda.Pagamentos)
                {
                    if (pagamento.Id_forma_pagamento <= 0)
                    {
                        throw new InvalidOperationException(
                            "Forma de pagamento inválida.");
                    }

                    if (pagamento.Valor <= 0)
                    {
                        throw new InvalidOperationException(
                            "O valor do pagamento deve ser maior que zero.");
                    }


                    // ==========================================
                    // VERIFICAR FORMA DE PAGAMENTO
                    // ==========================================

                    var forma =
                        await _context.FormasPagamento
                            .FirstOrDefaultAsync(f =>
                                f.Id_forma_pagamento ==
                                pagamento.Id_forma_pagamento);

                    if (forma == null)
                    {
                        throw new InvalidOperationException(
                            "Forma de pagamento não encontrada.");
                    }


                    totalPagamentos +=
                        pagamento.Valor;
                }


                // ==========================================
                // ARREDONDAR PAGAMENTOS
                // ==========================================

                totalPagamentos =
                    Math.Round(
                        totalPagamentos,
                        2);


                // ==========================================
                // CONFERIR PAGAMENTOS
                // ==========================================

                if (totalPagamentos != venda.Valor_total)
                {
                    throw new InvalidOperationException(
                        $"O total dos pagamentos " +
                        $"(R$ {totalPagamentos:F2}) " +
                        $"não corresponde ao total da venda " +
                        $"(R$ {venda.Valor_total:F2}).");
                }


                // ==========================================
                // DADOS DA VENDA
                // ==========================================

                venda.Data_venda =
                    DateTime.Now;

                venda.Status = 1;


                // ==========================================
                // SALVAR VENDA
                // ==========================================

                _context.Venda.Add(venda);

                await _context.SaveChangesAsync();


                // ==========================================
                // BAIXAR ESTOQUE
                // ==========================================

                foreach (var item in venda.Itens)
                {
                    var produto =
                        await _context.Produto
                            .FirstAsync(p =>
                                p.id_produto ==
                                item.Id_produto);


                    int estoqueAnterior =
                        produto.estoque;


                    produto.estoque -=
                        item.Quantidade;


                    // ==========================================
                    // MOVIMENTAÇÃO DE ESTOQUE
                    // ==========================================

                    var movimentacao =
                        new MovimentacaoEstoque
                        {
                            Id_produto =
                                produto.id_produto,

                            Id_usuario =
                                venda.Id_usuario,

                            Tipo = 2,

                            Quantidade =
                                item.Quantidade,

                            Estoque_anterior =
                                estoqueAnterior,

                            Estoque_atual =
                                produto.estoque,

                            Descricao =
                                $"Venda realizada #{venda.Id_venda}",

                            Data_movimentacao =
                                DateTime.Now
                        };


                    _context.MovimentacoesEstoque
                        .Add(movimentacao);
                }


                // ==========================================
                // MOVIMENTAÇÃO DO CAIXA
                // ==========================================

                var movimentacaoCaixa =
                    new CaixaMovimentacao
                    {
                        Id_caixa =
                            venda.Id_caixa,

                        Tipo = 1,

                        Descricao =
                            $"Venda #{venda.Id_venda}",

                        // Aqui entra o valor FINAL
                        // já descontado
                        Valor =
                            venda.Valor_total,

                        Data_movimentacao =
                            DateTime.Now
                    };


                _context.CaixaMovimentacao
                    .Add(movimentacaoCaixa);


                // ==========================================
                // SALVAR ALTERAÇÕES
                // ==========================================

                await _context.SaveChangesAsync();


                // ==========================================
                // LOG
                // ==========================================

                string descricaoLog;

                if (venda.Desconto > 0)
                {
                    descricaoLog =
                        $"Venda #{venda.Id_venda} realizada. " +
                        $"Subtotal: R$ {totalVenda:F2}. " +
                        $"Desconto: R$ {venda.Desconto:F2}. " +
                        $"Total: R$ {venda.Valor_total:F2}.";
                }
                else
                {
                    descricaoLog =
                        $"Venda #{venda.Id_venda} realizada " +
                        $"no valor de R$ {venda.Valor_total:F2}.";
                }


                await _logService.RegistrarLog(
                    idUsuario:
                        venda.Id_usuario,

                    acao:
                        "CRIAR",

                    tabela:
                        "vendas",

                    idRegistro:
                        venda.Id_venda,

                    descricao:
                        descricaoLog
                );


                // ==========================================
                // CONFIRMAR TRANSAÇÃO
                // ==========================================

                await transaction.CommitAsync();


                return venda;
            }
            catch
            {
                await transaction.RollbackAsync();

                throw;
            }
        }


        // ==========================================
        // ESTORNAR VENDA
        // ==========================================

        public async Task<bool> EstornarVenda(
            int id,
            int idUsuario)
        {
            using var transaction =
                await _context.Database.BeginTransactionAsync();

            try
            {
                // ==========================================
                // BUSCAR VENDA
                // ==========================================

                var venda =
                    await _context.Venda
                        .Include(v => v.Itens)
                        .Include(v => v.Pagamentos)
                        .FirstOrDefaultAsync(v =>
                            v.Id_venda == id);


                if (venda == null)
                {
                    return false;
                }


                // ==========================================
                // VERIFICAR SE JÁ FOI ESTORNADA
                // ==========================================

                if (venda.Status == 0)
                {
                    throw new InvalidOperationException(
                        "Esta venda já está estornada.");
                }


                // ==========================================
                // VERIFICAR USUÁRIO
                // ==========================================

                var usuario =
                    await _context.Usuario
                        .FirstOrDefaultAsync(u =>
                            u.id_usuario == idUsuario);


                if (usuario == null)
                {
                    throw new InvalidOperationException(
                        "Usuário não encontrado.");
                }


                // ==========================================
                // VERIFICAR USUÁRIO ATIVO
                // ==========================================

                if (usuario.ativo != "S")
                {
                    throw new InvalidOperationException(
                        "O usuário está inativo.");
                }


                // ==========================================
                // ESTORNAR VENDA
                // ==========================================

                venda.Status = 0;


                // ==========================================
                // DEVOLVER ESTOQUE
                // ==========================================

                foreach (var item in venda.Itens)
                {
                    var produto =
                        await _context.Produto
                            .FirstOrDefaultAsync(p =>
                                p.id_produto ==
                                item.Id_produto);


                    if (produto == null)
                    {
                        continue;
                    }


                    int estoqueAnterior =
                        produto.estoque;


                    produto.estoque +=
                        item.Quantidade;


                    // ==========================================
                    // MOVIMENTAÇÃO DE ESTOQUE
                    // ==========================================

                    var movimentacao =
                        new MovimentacaoEstoque
                        {
                            Id_produto =
                                produto.id_produto,

                            Id_usuario =
                                idUsuario,

                            Tipo = 1,

                            Quantidade =
                                item.Quantidade,

                            Estoque_anterior =
                                estoqueAnterior,

                            Estoque_atual =
                                produto.estoque,

                            Descricao =
                                $"Estorno da Venda #{venda.Id_venda}",

                            Data_movimentacao =
                                DateTime.Now
                        };


                    _context.MovimentacoesEstoque
                        .Add(movimentacao);
                }


                // ==========================================
                // MOVIMENTAÇÃO NEGATIVA NO CAIXA
                // ==========================================

                var movimentacaoCaixa =
                    new CaixaMovimentacao
                    {
                        Id_caixa =
                            venda.Id_caixa,

                        Tipo = 2,

                        Descricao =
                            $"Estorno da Venda #{venda.Id_venda}",

                        Valor =
                            venda.Valor_total,

                        Data_movimentacao =
                            DateTime.Now
                    };


                _context.CaixaMovimentacao
                    .Add(movimentacaoCaixa);


                // ==========================================
                // SALVAR
                // ==========================================

                await _context.SaveChangesAsync();


                // ==========================================
                // LOG
                // ==========================================

                await _logService.RegistrarLog(
                    idUsuario:
                        idUsuario,

                    acao:
                        "ESTORNAR",

                    tabela:
                        "vendas",

                    idRegistro:
                        venda.Id_venda,

                    descricao:
                        $"Venda #{venda.Id_venda} " +
                        $"estornada no valor de " +
                        $"R$ {venda.Valor_total:F2}."
                );


                // ==========================================
                // CONFIRMAR TRANSAÇÃO
                // ==========================================

                await transaction.CommitAsync();


                return true;
            }
            catch
            {
                await transaction.RollbackAsync();

                throw;
            }
        }
    }
}
