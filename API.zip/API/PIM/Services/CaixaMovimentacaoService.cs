﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class CaixaMovimentacaoService
    {
        private readonly AppDbContext _context;

        public CaixaMovimentacaoService(AppDbContext context)
        {
            _context = context;
        }

        // ==========================================
        // LISTAR MOVIMENTAÇÕES DO CAIXA
        // ==========================================

        public async Task<List<CaixaMovimentacao>> ListarPorCaixa(
            int idCaixa)
        {
            return await _context.Set<CaixaMovimentacao>()
                .Where(m => m.Id_caixa == idCaixa)
                .OrderByDescending(m => m.Data_movimentacao)
                .ToListAsync();
        }

        // ==========================================
        // REGISTRAR MOVIMENTAÇÃO
        // ==========================================

        public async Task<CaixaMovimentacao> RegistrarMovimentacao(
            CaixaMovimentacao movimentacao)
        {
            var caixa = await _context.Set<Caixa>()
                .FirstOrDefaultAsync(c =>
                    c.Id_caixa == movimentacao.Id_caixa);

            if (caixa == null)
            {
                throw new InvalidOperationException(
                    "Caixa não encontrado.");
            }

            if (caixa.Status == 0)
            {
                throw new InvalidOperationException(
                    "Não é possível movimentar um caixa fechado.");
            }

            if (movimentacao.Tipo != 1 &&
                movimentacao.Tipo != 2)
            {
                throw new InvalidOperationException(
                    "Tipo de movimentação inválido. Use 1 para entrada ou 2 para saída.");
            }

            if (movimentacao.Valor <= 0)
            {
                throw new InvalidOperationException(
                    "O valor da movimentação deve ser maior que zero.");
            }

            movimentacao.Data_movimentacao = DateTime.Now;

            _context.Set<CaixaMovimentacao>()
                .Add(movimentacao);

            await _context.SaveChangesAsync();

            return movimentacao;
        }
    }
}