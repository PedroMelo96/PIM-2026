﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class CaixaService
    {
        private readonly AppDbContext _context;

        public CaixaService(AppDbContext context)
        {
            _context = context;
        }

        // ==========================================
        // LISTAR TODOS
        // ==========================================

        public async Task<List<Caixa>> ListarTodos()
        {
            return await _context.Set<Caixa>()
                .OrderByDescending(c => c.Id_caixa)
                .ToListAsync();
        }

        // ==========================================
        // BUSCAR POR ID
        // ==========================================

        public async Task<Caixa?> BuscarPorId(int id)
        {
            return await _context.Set<Caixa>()
                .FirstOrDefaultAsync(c => c.Id_caixa == id);
        }

        // ==========================================
        // BUSCAR CAIXA ABERTO DO USUÁRIO
        // ==========================================

        public async Task<Caixa?> BuscarCaixaAberto(int idUsuario)
        {
            return await _context.Set<Caixa>()
                .FirstOrDefaultAsync(c =>
                    c.Id_usuario == idUsuario &&
                    c.Status == 1);
        }

        // ==========================================
        // ABRIR CAIXA
        // ==========================================

        public async Task<Caixa> AbrirCaixa(Caixa caixa)
        {
            var caixaAberto =
                await BuscarCaixaAberto(caixa.Id_usuario);

            if (caixaAberto != null)
            {
                throw new InvalidOperationException(
                    $"O utilizador já tem o caixa #{caixaAberto.Id_caixa} aberto."
                );
            }

            if (caixa.Valor_abertura < 0)
            {
                throw new InvalidOperationException(
                    "O valor de abertura não pode ser negativo."
                );
            }

            caixa.Data_abertura = DateTime.Now;
            caixa.Data_fechamento = null;
            caixa.Valor_fechamento = null;
            caixa.Status = 1;

            _context.Set<Caixa>().Add(caixa);

            await _context.SaveChangesAsync();

            return caixa;
        }

        // ==========================================
        // FECHAR CAIXA
        // ==========================================

        public async Task<bool> FecharCaixa(
            int id,
            decimal valorFechamento)
        {
            var caixa = await BuscarPorId(id);

            if (caixa == null)
            {
                return false;
            }

            if (caixa.Status == 0)
            {
                throw new InvalidOperationException(
                    "Este caixa já está fechado."
                );
            }

            if (valorFechamento < 0)
            {
                throw new InvalidOperationException(
                    "O valor de fechamento não pode ser negativo."
                );
            }

            // ==========================================
            // FECHAR
            // ==========================================

            caixa.Valor_fechamento =
                Math.Round(valorFechamento, 2);

            caixa.Data_fechamento =
                DateTime.Now;

            caixa.Status = 0;

            await _context.SaveChangesAsync();

            return true;
        }
    }
}