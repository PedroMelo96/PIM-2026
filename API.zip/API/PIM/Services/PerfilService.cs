﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class PerfilService
    {
        private readonly AppDbContext _context;

        public PerfilService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Perfil>> Listar()
        {
            return await _context.Perfil
                .OrderBy(p => p.id_perfil)
                .ToListAsync();
        }
    }
}