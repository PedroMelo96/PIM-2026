﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.DTOs;
using PIM.Models;

namespace PIM.Services
{
    public class UsuarioService
    {
        private readonly AppDbContext _context;
        private readonly LogService _logService;

        public UsuarioService(AppDbContext context, LogService logService)
        {
            _context = context;
            _logService = logService;
        }

        public async Task<Usuario?> Login(LoginDto login)
        {
            var usuario = await _context.Usuario
                .FirstOrDefaultAsync(u =>
                    u.usuario == login.usuario &&
                    u.senha == login.senha &&
                    u.ativo == "S"
                );

            return usuario;
        }

        public async Task<Usuario> Cadastrar(Usuario usuario, int idUsuarioLogado)
        {
            usuario.ativo = "S";
            usuario.data_cadastro = DateTime.Now; // Nova linha

            _context.Usuario.Add(usuario);
            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "CADASTRO", "usuarios", usuario.id_usuario, $"Usuário '{usuario.nome_usuario}' cadastrado."
            );

            return usuario;
        }

        public async Task<bool> Alterar(int id, Usuario usuario, int idUsuarioLogado)
        {
            var usuarioBanco = await _context.Usuario.FirstOrDefaultAsync(u => u.id_usuario == id);

            if (usuarioBanco == null) return false;

            usuarioBanco.nome_usuario = usuario.nome_usuario;
            usuarioBanco.usuario = usuario.usuario;
            usuarioBanco.id_perfil = usuario.id_perfil;

            if (!string.IsNullOrWhiteSpace(usuario.senha))
            {
                usuarioBanco.senha = usuario.senha;
            }

            usuarioBanco.data_atualizacao = DateTime.Now; // Nova linha

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ALTERAÇÃO", "usuarios", usuarioBanco.id_usuario, $"Usuário '{usuarioBanco.nome_usuario}' alterado."
            );

            return true;
        }

        public async Task<bool> Inativar(int id, int idUsuarioLogado)
        {
            var usuario = await _context.Usuario.FirstOrDefaultAsync(u => u.id_usuario == id);

            if (usuario == null) return false;

            usuario.ativo = "N";
            usuario.data_inativacao = DateTime.Now; // Nova linha

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "INATIVAÇÃO", "usuarios", usuario.id_usuario, $"Usuário '{usuario.nome_usuario}' foi inativado."
            );

            return true;
        }

        public async Task<bool> Ativar(int id, int idUsuarioLogado)
        {
            var usuario = await _context.Usuario.FirstOrDefaultAsync(u => u.id_usuario == id);

            if (usuario == null) return false;

            usuario.ativo = "S";
            usuario.data_atualizacao = DateTime.Now; // Nova linha
            usuario.data_inativacao = null; // Limpa a inativação

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ATIVAÇÃO", "usuarios", usuario.id_usuario, $"Usuário '{usuario.nome_usuario}' foi ativado."
            );

            return true;
        }

        public async Task<List<Usuario>> Listar()
        {
            return await _context.Usuario.OrderBy(u => u.id_usuario).ToListAsync();
        }
    }
}