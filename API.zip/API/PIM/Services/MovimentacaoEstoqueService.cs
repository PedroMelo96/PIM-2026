﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class MovimentacaoEstoqueService
    {
        private readonly AppDbContext _context;
        private readonly LogService _logService;

        public MovimentacaoEstoqueService(
            AppDbContext context,
            LogService logService)
        {
            _context = context;
            _logService = logService;
        }


        // ==========================================
        // LISTAR MOVIMENTAÇÕES DO PRODUTO
        // ==========================================

        public async Task<List<MovimentacaoEstoque>> ListarPorProduto(
            int idProduto)
        {
            return await _context.Set<MovimentacaoEstoque>()
                .Where(m => m.Id_produto == idProduto)
                .OrderByDescending(m => m.Data_movimentacao)
                .ToListAsync();
        }


        // ==========================================
        // AJUSTAR ESTOQUE
        // ==========================================

        public async Task<bool> AjustarEstoque(
            AjusteEstoqueRequest request,
            int idUsuarioLogado)
        {
            // ==========================================
            // BUSCA O PRODUTO
            // ==========================================

            var produto = await _context.Produto
                .FirstOrDefaultAsync(p =>
                    p.id_produto == request.Id_produto);

            if (produto == null)
            {
                return false;
            }


            // ==========================================
            // VALIDA QUANTIDADE
            // ==========================================

            if (request.Quantidade <= 0)
            {
                throw new Exception(
                    "A quantidade deve ser maior que zero."
                );
            }


            // ==========================================
            // GUARDA ESTOQUE ANTERIOR
            // ==========================================

            int estoqueAnterior = produto.estoque;

            int estoqueAtual;


            // ==========================================
            // ENTRADA
            // Tipo = 1
            // ==========================================

            if (request.Tipo == 1)
            {
                estoqueAtual =
                    estoqueAnterior + request.Quantidade;
            }


            // ==========================================
            // SAÍDA
            // Tipo = 2
            // ==========================================

            else if (request.Tipo == 2)
            {
                estoqueAtual =
                    estoqueAnterior - request.Quantidade;

                if (estoqueAtual < 0)
                {
                    throw new Exception(
                        "Estoque insuficiente."
                    );
                }
            }


            // ==========================================
            // AJUSTE
            // Tipo = 3
            // ==========================================

            else if (request.Tipo == 3)
            {
                estoqueAtual =
                    request.Quantidade;
            }


            // ==========================================
            // TIPO INVÁLIDO
            // ==========================================

            else
            {
                throw new Exception(
                    "Tipo de movimentação inválido."
                );
            }


            // ==========================================
            // ATUALIZA ESTOQUE DO PRODUTO
            // ==========================================

            produto.estoque = estoqueAtual;


            // ==========================================
            // CRIA MOVIMENTAÇÃO
            // ==========================================

            var movimentacao = new MovimentacaoEstoque
            {
                Id_produto = produto.id_produto,

                // Usuário que realizou a operação
                Id_usuario = idUsuarioLogado,

                // 1 = Entrada
                // 2 = Saída
                // 3 = Ajuste
                Tipo = request.Tipo,

                Quantidade = request.Quantidade,

                Estoque_anterior = estoqueAnterior,

                Estoque_atual = estoqueAtual,

                Descricao = request.Descricao,

                Data_movimentacao = DateTime.Now
            };


            _context.Set<MovimentacaoEstoque>()
                .Add(movimentacao);


            // ==========================================
            // SALVA PRODUTO + MOVIMENTAÇÃO
            // ==========================================

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                var erro = ex;

                while (erro.InnerException != null)
                {
                    erro = erro.InnerException;
                }

                throw new Exception(
                    "Erro ao salvar movimentação no banco: "
                    + erro.Message
                );
            }


            // ==========================================
            // DESCRIÇÃO DO LOG
            // ==========================================

            string tipoDescricao;

            if (request.Tipo == 1)
            {
                tipoDescricao = "Entrada";
            }
            else if (request.Tipo == 2)
            {
                tipoDescricao = "Saída";
            }
            else
            {
                tipoDescricao = "Ajuste";
            }


            // ==========================================
            // REGISTRA LOG
            // ==========================================

            await _logService.RegistrarLog(
                idUsuarioLogado,
                "MOVIMENTAÇÃO_ESTOQUE",
                "movimentacao_estoque",
                movimentacao.Id_movimentacao,
                $"Produto '{produto.nome_produto}' - " +
                $"{tipoDescricao} de {request.Quantidade} unidade(s). " +
                $"Estoque: {estoqueAnterior} -> {estoqueAtual}."
            );


            return true;
        }
        // ==========================================
        // LISTAR TODAS AS MOVIMENTAÇÕES
        // ==========================================

        public async Task<List<MovimentacaoEstoque>> ListarTodas()
        {
            return await _context.Set<MovimentacaoEstoque>()
                .OrderByDescending(m => m.Data_movimentacao)
                .ToListAsync();
        }
    }
}