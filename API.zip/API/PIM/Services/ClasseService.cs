﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class ClasseService
    {
        private readonly AppDbContext _context;
        private readonly LogService _logService;

        public ClasseService(AppDbContext context, LogService logService)
        {
            _context = context;
            _logService = logService;
        }

        public async Task<Classe> Cadastrar(Classe classe, int idUsuarioLogado)
        {
            classe.ativo = "S";
            classe.data_cadastro = DateTime.Now;

            // EF Core pega o valor de 'desconto' automaticamente da requisição

            _context.Classe.Add(classe);
            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "CADASTRO", "classes", classe.id_classe, $"Classe '{classe.nome_classe}' cadastrada."
            );

            return classe;
        }

        public async Task<bool> Alterar(int id, Classe classe, int idUsuarioLogado)
        {
            var classeBanco = await _context.Classe.FirstOrDefaultAsync(c => c.id_classe == id);
            if (classeBanco == null) return false;

            // Atualiza os campos necessários
            classeBanco.nome_classe = classe.nome_classe;
            classeBanco.desconto = classe.desconto; // <-- Atualiza o desconto
            classeBanco.data_atualizacao = DateTime.Now;

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ALTERAÇÃO", "classes", classeBanco.id_classe, $"Classe '{classeBanco.nome_classe}' alterada."
            );

            return true;
        }

        public async Task<bool> Inativar(int id, int idUsuarioLogado)
        {
            var classe = await _context.Classe.FirstOrDefaultAsync(c => c.id_classe == id);
            if (classe == null) return false;

            classe.ativo = "N";
            classe.data_inativacao = DateTime.Now; // <-- Registra a data de inativação

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "INATIVAÇÃO", "classes", classe.id_classe, $"Classe '{classe.nome_classe}' foi inativada."
            );

            return true;
        }

        public async Task<bool> Ativar(int id, int idUsuarioLogado)
        {
            var classe = await _context.Classe.FirstOrDefaultAsync(c => c.id_classe == id);
            if (classe == null) return false;

            classe.ativo = "S";
            classe.data_atualizacao = DateTime.Now;
            classe.data_inativacao = null; // <-- Limpa a data de inativação ao ativar o produto!

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ATIVAÇÃO", "classes", classe.id_classe, $"Classe '{classe.nome_classe}' foi ativada."
            );

            return true;
        }

        public async Task<List<Classe>> Listar()
        {
            return await _context.Classe.OrderBy(c => c.id_classe).ToListAsync();
        }

        public async Task<Classe?> BuscarPorId(int id)
        {
            return await _context.Classe.FirstOrDefaultAsync(c => c.id_classe == id);
        }
    }
}