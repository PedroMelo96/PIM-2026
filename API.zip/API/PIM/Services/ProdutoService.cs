﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class ProdutoService
    {
        private readonly AppDbContext _context;
        private readonly LogService _logService;

        public ProdutoService(AppDbContext context, LogService logService)
        {
            _context = context;
            _logService = logService;
        }

        public async Task<Produto> Cadastrar(Produto produto, int idUsuarioLogado)
        {
            produto.ativo = "S";
            produto.data_cadastro = DateTime.Now;

            _context.Produto.Add(produto);
            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "CADASTRO", "produtos", produto.id_produto, $"Produto '{produto.nome_produto}' cadastrado."
            );

            return produto;
        }

        public async Task<bool> Alterar(int id, Produto produto, int idUsuarioLogado)
        {
            var produtoBanco = await _context.Produto.FirstOrDefaultAsync(p => p.id_produto == id);
            if (produtoBanco == null) return false;

            // Atualiza os dados
            produtoBanco.nome_produto = produto.nome_produto;
            produtoBanco.barras = produto.barras;
            produtoBanco.Classe = produto.Classe;
            produtoBanco.valor_venda = produto.valor_venda;
            produtoBanco.valor_compra = produto.valor_compra;
            produtoBanco.estoque_minimo = produto.estoque_minimo;

            // <-- Atualiza o Markup
            produtoBanco.markup = produto.markup;

            // Atualiza a data
            produtoBanco.data_atualizacao = DateTime.Now;

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ALTERAÇÃO", "produtos", produtoBanco.id_produto, $"Produto '{produtoBanco.nome_produto}' alterado."
            );

            return true;
        }

        public async Task<bool> Inativar(int id, int idUsuarioLogado)
        {
            var produto = await _context.Produto.FirstOrDefaultAsync(p => p.id_produto == id);
            if (produto == null) return false;

            produto.ativo = "N";
            produto.data_inativacao = DateTime.Now;

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "INATIVAÇÃO", "produtos", produto.id_produto, $"Produto '{produto.nome_produto}' foi inativado."
            );

            return true;
        }

        public async Task<bool> Ativar(int id, int idUsuarioLogado)
        {
            var produto = await _context.Produto.FirstOrDefaultAsync(p => p.id_produto == id);
            if (produto == null) return false;

            produto.ativo = "S";
            produto.data_atualizacao = DateTime.Now;
            produto.data_inativacao = null;

            await _context.SaveChangesAsync();

            await _logService.RegistrarLog(
                idUsuarioLogado, "ATIVAÇÃO", "produtos", produto.id_produto, $"Produto '{produto.nome_produto}' foi ativado."
            );

            return true;
        }

        public async Task<List<Produto>> Listar()
        {
            return await _context.Produto
                .Include(p => p.Classe) // <-- Traz os dados da classe junto
                .OrderBy(p => p.id_produto)
                .ToListAsync();
        }

        public async Task<Produto?> BuscarPorId(int id)
        {
            return await _context.Produto
                .Include(p => p.Classe) // <-- Traz os dados da classe junto
                .FirstOrDefaultAsync(p => p.id_produto == id);
        }
    }
}