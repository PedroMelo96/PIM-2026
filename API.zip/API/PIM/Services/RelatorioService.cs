﻿
using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Dto;
using PIM.DTOs;

namespace PIM.Services
{
    public class RelatorioService
    {
        private readonly AppDbContext _context;

        public RelatorioService(AppDbContext context)
        {
            _context = context;
        }

        // =====================================================
        // VENDAS POR FORMA DE PAGAMENTO
        // =====================================================

        public async Task<List<RelatorioVendaPagamentoDto>>
            VendasPorPagamento(
                DateTime? inicio,
                DateTime? fim)
        {
            var query =
                from pagamento in _context.VendaPagamento

                join forma in _context.FormasPagamento
                    on pagamento.Id_forma_pagamento
                    equals forma.Id_forma_pagamento

                join venda in _context.Venda
                    on pagamento.Id_venda
                    equals venda.Id_venda

                where venda.Status == 1

                select new
                {
                    FormaPagamento = forma.Nome_forma,

                    IdVenda = venda.Id_venda,

                    Valor = pagamento.Valor,

                    Data = venda.Data_venda
                };


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data.Date >= inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data < fimData);
            }


            return await query
                .GroupBy(x => x.FormaPagamento)
                .Select(g => new RelatorioVendaPagamentoDto
                {
                    FormaPagamento = g.Key,

                    QuantidadeVendas =
                        g.Select(x => x.IdVenda)
                         .Distinct()
                         .Count(),

                    ValorTotal =
                        g.Sum(x => x.Valor)
                })
                .OrderByDescending(x => x.ValorTotal)
                .ToListAsync();
        }


        // =====================================================
        // VENDAS POR PRODUTO
        // =====================================================

        public async Task<List<RelatorioVendaProdutoDto>>
            VendasPorProduto(
                DateTime? inicio,
                DateTime? fim)
        {
            var query =
                from item in _context.VendaItem

                join venda in _context.Venda
                    on item.Id_venda
                    equals venda.Id_venda

                join produto in _context.Produto
                    on item.Id_produto
                    equals produto.id_produto

                where venda.Status == 1

                select new
                {
                    IdProduto =
                        produto.id_produto,

                    NomeProduto =
                        produto.nome_produto,

                    Quantidade =
                        item.Quantidade,

                    ValorTotal =
                        item.Valor_total,

                    Data =
                        venda.Data_venda
                };


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data.Date >= inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data < fimData);
            }


            return await query

                .GroupBy(x => new
                {
                    x.IdProduto,
                    x.NomeProduto
                })

                .Select(g =>
                    new RelatorioVendaProdutoDto
                    {
                        IdProduto =
                            g.Key.IdProduto,

                        NomeProduto =
                            g.Key.NomeProduto,

                        QuantidadeVendida =
                            g.Sum(x =>
                                x.Quantidade),

                        ValorTotal =
                            g.Sum(x =>
                                x.ValorTotal)
                    })

                .OrderByDescending(x =>
                    x.QuantidadeVendida)

                .ToListAsync();
        }


        // =====================================================
        // VENDAS DIÁRIAS
        // =====================================================

        public async Task<List<RelatorioVendaDiariaDto>>
            VendasDiarias(
                DateTime? inicio,
                DateTime? fim)
        {
            var query =
                _context.Venda
                    .Where(x =>
                        x.Status == 1)
                    .AsQueryable();


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data_venda.Date >=
                    inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data_venda < fimData);
            }


            return await query

                .GroupBy(x =>
                    x.Data_venda.Date)

                .Select(g =>
                    new RelatorioVendaDiariaDto
                    {
                        Data =
                            g.Key,

                        QuantidadeVendas =
                            g.Count(),

                        ValorTotal =
                            g.Sum(x =>
                                x.Valor_total)
                    })

                .OrderBy(x =>
                    x.Data)

                .ToListAsync();
        }


        // =====================================================
        // PRODUTOS MAIS VENDIDOS
        // =====================================================

        public async Task<List<RelatorioProdutoMaisVendidoDto>>
            ProdutosMaisVendidos(
                DateTime? inicio,
                DateTime? fim,
                int limite = 20)
        {
            var query =
                from item in _context.VendaItem

                join venda in _context.Venda
                    on item.Id_venda
                    equals venda.Id_venda

                join produto in _context.Produto
                    on item.Id_produto
                    equals produto.id_produto

                where venda.Status == 1

                select new
                {
                    IdProduto =
                        produto.id_produto,

                    NomeProduto =
                        produto.nome_produto,

                    Quantidade =
                        item.Quantidade,

                    ValorTotal =
                        item.Valor_total,

                    Data =
                        venda.Data_venda
                };


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data.Date >=
                    inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data < fimData);
            }


            return await query

                .GroupBy(x => new
                {
                    x.IdProduto,
                    x.NomeProduto
                })

                .Select(g =>
                    new RelatorioProdutoMaisVendidoDto
                    {
                        IdProduto =
                            g.Key.IdProduto,

                        NomeProduto =
                            g.Key.NomeProduto,

                        QuantidadeVendida =
                            g.Sum(x =>
                                x.Quantidade),

                        ValorTotal =
                            g.Sum(x =>
                                x.ValorTotal)
                    })

                .OrderByDescending(x =>
                    x.QuantidadeVendida)

                .ThenByDescending(x =>
                    x.ValorTotal)

                .Take(limite)

                .ToListAsync();
        }


        // =====================================================
        // PRODUTOS MAIS VENDIDOS POR CLASSE
        // =====================================================

        public async Task<List<RelatorioProdutoClasseDto>>
            ProdutosMaisVendidosPorClasse(
                DateTime? inicio,
                DateTime? fim)
        {
            var query =
                from item in _context.VendaItem

                join venda in _context.Venda
                    on item.Id_venda
                    equals venda.Id_venda

                join produto in _context.Produto
                    on item.Id_produto
                    equals produto.id_produto

                join classe in _context.Classe
    on produto.id_classe
    equals classe.id_classe

                where venda.Status == 1

                select new
                {
                    IdClasse =
                        classe.id_classe,

                    NomeClasse =
                        classe.nome_classe,

                    IdProduto =
                        produto.id_produto,

                    NomeProduto =
                        produto.nome_produto,

                    Quantidade =
                        item.Quantidade,

                    ValorTotal =
                        item.Valor_total,

                    Data =
                        venda.Data_venda
                };


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data.Date >=
                    inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data < fimData);
            }


            return await query

                .GroupBy(x => new
                {
                    x.IdClasse,
                    x.NomeClasse,

                    x.IdProduto,
                    x.NomeProduto
                })

                .Select(g =>
                    new RelatorioProdutoClasseDto
                    {
                        IdClasse =
                            g.Key.IdClasse,

                        NomeClasse =
                            g.Key.NomeClasse,

                        IdProduto =
                            g.Key.IdProduto,

                        NomeProduto =
                            g.Key.NomeProduto,

                        QuantidadeVendida =
                            g.Sum(x =>
                                x.Quantidade),

                        ValorTotal =
                            g.Sum(x =>
                                x.ValorTotal)
                    })

                .OrderBy(x =>
                    x.NomeClasse)

                .ThenByDescending(x =>
                    x.QuantidadeVendida)

                .ToListAsync();
        }


        // =====================================================
        // VENDAS ESTORNADAS
        // =====================================================

        public async Task<List<RelatorioVendaEstornadaDto>>
            VendasEstornadas(
                DateTime? inicio,
                DateTime? fim)
        {
            var query =
                _context.Venda
                    .Where(x =>
                        x.Status != 1)
                    .AsQueryable();


            if (inicio.HasValue)
            {
                query = query.Where(x =>
                    x.Data_venda.Date >=
                    inicio.Value.Date);
            }


            if (fim.HasValue)
            {
                var fimData =
                    fim.Value.Date.AddDays(1);

                query = query.Where(x =>
                    x.Data_venda < fimData);
            }


            return await query

                .Select(x =>
                    new RelatorioVendaEstornadaDto
                    {
                        IdVenda =
                            x.Id_venda,

                        DataVenda =
                            x.Data_venda,

                        IdUsuario =
                            x.Id_usuario,

                        ValorTotal =
                            x.Valor_total,

                        Status =
                            "ESTORNADA"
                    })

                .OrderByDescending(x =>
                    x.DataVenda)

                .ToListAsync();
        }
    }
}

