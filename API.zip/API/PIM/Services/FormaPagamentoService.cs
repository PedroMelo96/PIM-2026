﻿using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Models;

namespace PIM.Services
{
    public class FormaPagamentoService
    {
        private readonly AppDbContext _context;

        public FormaPagamentoService(AppDbContext context)
        {
            _context = context;
        }

        // ==========================================
        // LISTAR TODAS
        // ==========================================

        public async Task<List<FormaPagamento>> ListarTodas()
        {
            return await _context.Set<FormaPagamento>()
                .OrderBy(f => f.Nome_forma)
                .ToListAsync();
        }

        // ==========================================
        // CADASTRAR
        // ==========================================

        public async Task<FormaPagamento> Cadastrar(
            FormaPagamento forma)
        {
            if (string.IsNullOrWhiteSpace(forma.Nome_forma))
            {
                throw new InvalidOperationException(
                    "Informe o nome da forma de pagamento.");
            }

            forma.Nome_forma = forma.Nome_forma.Trim();

            var existe = await _context.Set<FormaPagamento>()
                .AnyAsync(f =>
                    f.Nome_forma.ToLower() ==
                    forma.Nome_forma.ToLower());

            if (existe)
            {
                throw new InvalidOperationException(
                    "Essa forma de pagamento já está cadastrada.");
            }

            _context.Set<FormaPagamento>().Add(forma);

            await _context.SaveChangesAsync();

            return forma;
        }

        // ==========================================
        // EXCLUIR
        // ==========================================

        public async Task<bool> Excluir(int id)
        {
            var forma = await _context.Set<FormaPagamento>()
                .FindAsync(id);

            if (forma == null)
            {
                return false;
            }

            // Verifica se já foi utilizada em alguma venda
            var utilizada = await _context.Set<VendaPagamento>()
                .AnyAsync(p =>
                    p.Id_forma_pagamento == id);

            if (utilizada)
            {
                throw new InvalidOperationException(
                    "Essa forma de pagamento já foi utilizada em uma venda e não pode ser excluída.");
            }

            _context.Set<FormaPagamento>().Remove(forma);

            await _context.SaveChangesAsync();

            return true;
        }
    }
}