﻿namespace PIM.Dto
{
    public class RelatorioVendaPagamentoDto
    {
        public string FormaPagamento { get; set; }
        public int QuantidadeVendas { get; set; }
        public decimal ValorTotal { get; set; }
    }
}
