﻿namespace PIM.Dto
{
    public class RelatorioVendaProdutoDto
    {
        public int IdProduto { get; set; }
        public string NomeProduto { get; set; } = "";
        public int QuantidadeVendida { get; set; }
        public decimal ValorTotal { get; set; }
    }

}
