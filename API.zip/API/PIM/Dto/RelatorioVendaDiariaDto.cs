﻿namespace PIM.Dto
{
    public class RelatorioVendaDiariaDto
    {
        public DateTime Data { get; set; }
        public int QuantidadeVendas { get; set; }
        public decimal ValorTotal { get; set; }
    }
}
