﻿namespace PIM.DTOs
{
    public class LoginDto
    {
        public string usuario { get; set; }
        public string senha { get; set; }
    }
}