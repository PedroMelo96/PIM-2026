﻿namespace PIM.Dto
{
    public class RelatorioProdutoClasseDto
    {
        public int IdClasse { get; set; }
        public string NomeClasse { get; set; } = "";

        public int IdProduto { get; set; }
        public string NomeProduto { get; set; } = "";

        public int QuantidadeVendida { get; set; }
        public decimal ValorTotal { get; set; }
    }
}
