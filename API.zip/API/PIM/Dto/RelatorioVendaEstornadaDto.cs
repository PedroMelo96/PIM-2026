﻿namespace PIM.Dto
{
    public class RelatorioVendaEstornadaDto
    {
        public int IdVenda { get; set; }
        public DateTime DataVenda { get; set; }
        public int IdUsuario { get; set; }
        public int IdCaixa { get; set; }
        public decimal ValorTotal { get; set; }
        public string Status { get; set; } = "ESTORNADA";
    }

}
