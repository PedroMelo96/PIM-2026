using Microsoft.EntityFrameworkCore;
using PIM.Data;
using PIM.Services;
// 1. ADICIONADO: Importações do JWT
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Digite o token JWT. Exemplo: Bearer seu_token"
    });

    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        ServerVersion.AutoDetect(
            builder.Configuration.GetConnectionString("DefaultConnection")
        )
    ));

//services
builder.Services.AddScoped<ProdutoService>();
builder.Services.AddScoped<ClasseService>();
builder.Services.AddScoped<UsuarioService>();
//backup
builder.Services.AddScoped<BackupService>();
// CAIXA
builder.Services.AddScoped<CaixaService>();
builder.Services.AddScoped<CaixaMovimentacaoService>();
// PAGAMENTO
builder.Services.AddScoped<FormaPagamentoService>();
// ESTOQUE
builder.Services.AddScoped<MovimentacaoEstoqueService>();
// VENDA
builder.Services.AddScoped<VendaService>();
// LOG
builder.Services.AddScoped<LogService>();
// PERFIL
builder.Services.AddScoped<PerfilService>();
// RELATÓRIOS
builder.Services.AddScoped<RelatorioService>();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("Frontend", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// ==========================================
// 2. ADICIONADO: Configuração do JWT
// ==========================================
// Coloquei um valor padrão caso esqueça de colocar no appsettings.json
var chaveJwt = builder.Configuration.GetSection("Jwt:Key").Value ?? "K9mR2xT7vB4nQ8pL5zW1cD6hF3jA0sY2";
var chaveEmBytes = Encoding.ASCII.GetBytes(chaveJwt);

builder.Services.AddAuthentication(x =>
{
    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(x =>
{
    x.RequireHttpsMetadata = false; // Permite rodar sem HTTPS localmente
    x.SaveToken = true;
    x.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(chaveEmBytes),
        ValidateIssuer = false,
        ValidateAudience = false,
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
});
// ==========================================

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.UseHttpsRedirection();
app.UseCors("Frontend");

// ==========================================
// 3. ADICIONADO: Ativação da Autenticação (Sempre antes do UseAuthorization)
// ==========================================
app.UseAuthentication();

app.UseAuthorization();
app.MapControllers();

app.Run();