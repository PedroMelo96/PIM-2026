﻿using Microsoft.AspNetCore.Authorization; // <-- Adicionado
using Microsoft.AspNetCore.Mvc;
using PIM.Services;
using System.IO;

namespace PIM.Controllers
{
    [Authorize(Roles = "1")] // <-- Somente administradores podem acessar backups!
    [ApiController]
    [Route("api/[controller]")]
    public class BackupController : ControllerBase
    {
        private readonly BackupService _service;

        public BackupController(BackupService service)
        {
            _service = service;
        }

        // ==========================================
        // LISTAR BACKUPS
        // ==========================================

        [HttpGet]
        public IActionResult ListarBackups()
        {
            try
            {
                var backups = _service.ListarBackups();
                return Ok(backups);
            }
            catch (Exception ex)
            {
                return StatusCode(
                    500,
                    new
                    {
                        mensagem = "Erro ao listar os backups.",
                        erro = ex.Message
                    }
                );
            }
        }

        // ==========================================
        // GERAR BACKUP
        // ==========================================

        [HttpPost("gerar")]
        public async Task<IActionResult> GerarBackup()
        {
            try
            {
                var caminho = await _service.GerarBackup();

                return Ok(
                    new
                    {
                        mensagem = "Backup realizado com sucesso.",
                        arquivo = Path.GetFileName(caminho),
                        caminho = caminho
                    }
                );
            }
            catch (FileNotFoundException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(
                    500,
                    new
                    {
                        mensagem = "Erro interno ao gerar o backup.",
                        erro = ex.Message
                    }
                );
            }
        }
    }
}