﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PIM.Data;

namespace PIM.Controllers
{
    [Authorize] 
 
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DashboardController(AppDbContext context)
        {
            _context = context;
        }

        // =====================================================
        // DASHBOARD
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> ObterDashboard()
        {
            try
            {
                // -------------------------------------------------
                // DATA DE HOJE
                // -------------------------------------------------
                DateTime hoje = DateTime.Today;
                DateTime amanha = hoje.AddDays(1);

                // -------------------------------------------------
                // VENDAS REALIZADAS HOJE (Status 1 = venda realizada)
                // -------------------------------------------------
                var vendasHoje = await _context.Venda
                    .Where(v => v.Status == 1 && v.Data_venda >= hoje && v.Data_venda < amanha)
                    .ToListAsync();

                // -------------------------------------------------
                // FATURAMENTO DO DIA
                // -------------------------------------------------
                decimal faturamentoHoje = vendasHoje.Sum(v => v.Valor_total);

                // -------------------------------------------------
                // QUANTIDADE DE VENDAS
                // -------------------------------------------------
                int quantidadeVendasHoje = vendasHoje.Count;

                // -------------------------------------------------
                // PRODUTO MAIS VENDIDO
                // -------------------------------------------------
                var idsVendasHoje = vendasHoje.Select(v => v.Id_venda).ToList();

                var produtoMaisVendido = await (
                    from item in _context.VendaItem
                    join produto in _context.Produto on item.Id_produto equals produto.id_produto
                    where idsVendasHoje.Contains(item.Id_venda)
                    group item by new { produto.id_produto, produto.nome_produto } into grupo
                    select new
                    {
                        IdProduto = grupo.Key.id_produto,
                        NomeProduto = grupo.Key.nome_produto,
                        QuantidadeVendida = grupo.Sum(x => x.Quantidade),
                        ValorTotal = grupo.Sum(x => x.Valor_total)
                    }
                )
                .OrderByDescending(x => x.QuantidadeVendida)
                .ThenByDescending(x => x.ValorTotal)
                .FirstOrDefaultAsync();

                // -------------------------------------------------
                // PRODUTOS ABAIXO DO ESTOQUE MÍNIMO
                // -------------------------------------------------
                var produtosEstoqueMinimo = await _context.Produto
                    .Where(p => p.ativo == "S" && p.estoque <= p.estoque_minimo)
                    .OrderBy(p => p.estoque)
                    .ThenBy(p => p.nome_produto)
                    .Select(p => new
                    {
                        IdProduto = p.id_produto,
                        NomeProduto = p.nome_produto,
                        Estoque = p.estoque,
                        EstoqueMinimo = p.estoque_minimo
                    })
                    .ToListAsync();

                // -------------------------------------------------
                // RETORNO
                // -------------------------------------------------
                return Ok(new
                {
                    faturamentoHoje,
                    quantidadeVendasHoje,
                    produtoMaisVendido,
                    produtosEstoqueMinimo
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao carregar o dashboard.",
                    erro = ex.Message
                });
            }
        }
    }
}