﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;
using System.Security.Claims;

namespace PIM.Controllers
{
    [Authorize(Roles = "1,3")]

    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        private readonly ProdutoService _service;

        public ProdutoController(ProdutoService service)
        {
            _service = service;
        }

        // ==========================================
        // LISTAR
        // GET: api/Produto
        // ==========================================

        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            var produtos = await _service.Listar();
            return Ok(produtos);
        }

        // ==========================================
        // BUSCAR POR ID
        // GET: api/Produto/5
        // ==========================================

        [HttpGet("{id}")]
        public async Task<IActionResult> BuscarPorId(int id)
        {
            var produto = await _service.BuscarPorId(id);

            if (produto == null)
            {
                return NotFound(new { mensagem = "Produto não encontrado." });
            }

            return Ok(produto);
        }

        // ==========================================
        // CADASTRAR
        // POST: api/Produto
        // ==========================================

        [HttpPost]
        public async Task<IActionResult> Cadastrar(Produto produto)
        {
            try
            {
                // Extrai o ID do usuário diretamente do Token JWT
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Cadastrar(produto, idUsuarioLogado);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // ALTERAR
        // PUT: api/Produto/5
        // ==========================================

        [HttpPut("{id}")]
        public async Task<IActionResult> Alterar(int id, Produto produto)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Alterar(id, produto, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Produto não encontrado." });
                }

                return Ok(new { mensagem = "Produto alterado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // INATIVAR
        // PUT: api/Produto/5/inativar
        // ==========================================

        [HttpPut("{id}/inativar")]
        public async Task<IActionResult> Inativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Inativar(id, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Produto não encontrado." });
                }

                return Ok(new { mensagem = "Produto inativado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // ATIVAR
        // PUT: api/Produto/5/ativar
        // ==========================================

        [HttpPut("{id}/ativar")]
        public async Task<IActionResult> Ativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Ativar(id, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Produto não encontrado." });
                }

                return Ok(new { mensagem = "Produto ativado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }
    }
}