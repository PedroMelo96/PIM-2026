﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;

namespace PIM.Controllers
{
    [Authorize(Roles = "1,2")]

    [ApiController]
    [Route("api/[controller]")]
    public class FormaPagamentoController : ControllerBase
    {
        private readonly FormaPagamentoService _service;

        public FormaPagamentoController(FormaPagamentoService service) => _service = service;

        [HttpGet]
        public async Task<IActionResult> ListarTodas() => Ok(await _service.ListarTodas());

        
        [HttpPost]
        public async Task<IActionResult> Cadastrar(FormaPagamento forma)
        {
            var novaForma = await _service.Cadastrar(forma);
            return Ok(novaForma);
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var sucesso = await _service.Excluir(id);
            if (!sucesso) return NotFound(new { mensagem = "Forma de pagamento não encontrada." });
            return Ok(new { mensagem = "Forma de pagamento excluída com sucesso." });
        }
    }
}