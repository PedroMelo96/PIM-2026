﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;
using System.Security.Claims; // Necessário para ler o ID do Token

namespace PIM.Controllers
{
    [Authorize(Roles = "1,3")]

    [ApiController]
    [Route("api/[controller]")]
    public class MovimentacaoEstoqueController : ControllerBase
    {
        private readonly MovimentacaoEstoqueService _service;

        public MovimentacaoEstoqueController(MovimentacaoEstoqueService service)
        {
            _service = service;
        }

        // ==========================================
        // LISTAR MOVIMENTAÇÕES DO PRODUTO
        // ==========================================

        // GET: api/MovimentacaoEstoque/produto/5
        [HttpGet("produto/{idProduto}")]
        public async Task<IActionResult> ListarPorProduto(int idProduto)
        {
            var movimentacoes = await _service.ListarPorProduto(idProduto);
            return Ok(movimentacoes);
        }

        // ==========================================
        // AJUSTAR ESTOQUE
        // ==========================================

        // POST: api/MovimentacaoEstoque/ajustar
        [HttpPost("ajustar")]
        public async Task<IActionResult> AjustarEstoque(AjusteEstoqueRequest request)
        {
            try
            {
                // Extrai o ID do usuário diretamente do Token JWT!
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.AjustarEstoque(request, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Produto não encontrado." });
                }

                return Ok(new { mensagem = "Estoque alterado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // LISTAR TODAS AS MOVIMENTAÇÕES
        // ==========================================

        // GET: api/MovimentacaoEstoque
        [HttpGet]
        public async Task<IActionResult> ListarTodas()
        {
            var movimentacoes = await _service.ListarTodas();
            return Ok(movimentacoes);
        }
    }
}