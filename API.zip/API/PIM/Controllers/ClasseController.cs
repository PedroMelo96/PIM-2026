﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;
using System.Security.Claims;

namespace PIM.Controllers
{
    [Authorize(Roles = "1,3")]
    [ApiController]
    [Route("api/[controller]")]
    public class ClasseController : ControllerBase
    {
        private readonly ClasseService _service;

        public ClasseController(ClasseService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            var classes = await _service.Listar();
            return Ok(classes);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> BuscarPorId(int id)
        {
            var classe = await _service.BuscarPorId(id);
            if (classe == null) return NotFound(new { mensagem = "Classe não encontrada." });

            return Ok(classe);
        }

        [HttpPost]
        public async Task<IActionResult> Cadastrar(Classe classe)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var resultado = await _service.Cadastrar(classe, idUsuarioLogado);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Alterar(int id, Classe classe)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var resultado = await _service.Alterar(id, classe, idUsuarioLogado);

                if (!resultado) return NotFound(new { mensagem = "Classe não encontrada." });

                return Ok(new { mensagem = "Classe alterada com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        [HttpPut("{id}/inativar")]
        public async Task<IActionResult> Inativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var resultado = await _service.Inativar(id, idUsuarioLogado);

                if (!resultado) return NotFound(new { mensagem = "Classe não encontrada." });

                return Ok(new { mensagem = "Classe inativada com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        [HttpPut("{id}/ativar")]
        public async Task<IActionResult> Ativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var resultado = await _service.Ativar(id, idUsuarioLogado);

                if (!resultado) return NotFound(new { mensagem = "Classe não encontrada." });

                return Ok(new { mensagem = "Classe ativada com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }
    }
}