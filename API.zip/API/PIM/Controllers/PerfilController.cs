﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Services;

namespace PIM.Controllers
{
    [Authorize] // <-- Tranca a rota (exige token)
    [ApiController]
    [Route("api/[controller]")]
    public class PerfilController : ControllerBase
    {
        private readonly PerfilService _service;

        public PerfilController(PerfilService service)
        {
            _service = service;
        }

        // GET: api/Perfil
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            var perfis = await _service.Listar();
            return Ok(perfis);
        }
    }
}