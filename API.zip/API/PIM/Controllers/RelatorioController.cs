﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Services;

namespace PIM.Controllers
{

    [Authorize(Roles = "1")]
    [ApiController]
    [Route("api/[controller]")]
    public class RelatorioController : ControllerBase
    {
        private readonly RelatorioService _service;

        public RelatorioController(RelatorioService service)
        {
            _service = service;
        }

        // =====================================================
        // VENDAS POR FORMA DE PAGAMENTO
        // =====================================================

        [HttpGet("vendas-pagamento")]
        public async Task<IActionResult> VendasPorPagamento([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim)
        {
            try
            {
                var resultado = await _service.VendasPorPagamento(inicio, fim);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório de vendas por pagamento.",
                    erro = ex.Message
                });
            }
        }

        // =====================================================
        // VENDAS POR PRODUTO
        // =====================================================

        [HttpGet("vendas-produtos")]
        public async Task<IActionResult> VendasPorProduto([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim)
        {
            try
            {
                var resultado = await _service.VendasPorProduto(inicio, fim);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório de vendas por produto.",
                    erro = ex.Message
                });
            }
        }

        // =====================================================
        // VENDAS DIÁRIAS
        // =====================================================

        [HttpGet("vendas-diarias")]
        public async Task<IActionResult> VendasDiarias([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim)
        {
            try
            {
                var resultado = await _service.VendasDiarias(inicio, fim);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório de vendas diárias.",
                    erro = ex.Message
                });
            }
        }

        // =====================================================
        // PRODUTOS MAIS VENDIDOS
        // =====================================================

        [HttpGet("produtos-mais-vendidos")]
        public async Task<IActionResult> ProdutosMaisVendidos([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim, [FromQuery] int limite = 20)
        {
            try
            {
                if (limite <= 0)
                {
                    limite = 20;
                }

                var resultado = await _service.ProdutosMaisVendidos(inicio, fim, limite);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório de produtos mais vendidos.",
                    erro = ex.Message
                });
            }
        }

        // =====================================================
        // PRODUTOS MAIS VENDIDOS POR CLASSE
        // =====================================================

        [HttpGet("produtos-por-classe")]
        public async Task<IActionResult> ProdutosPorClasse([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim)
        {
            try
            {
                var resultado = await _service.ProdutosMaisVendidosPorClasse(inicio, fim);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório por classe.",
                    erro = ex.Message
                });
            }
        }

        // =====================================================
        // VENDAS ESTORNADAS
        // =====================================================

        [HttpGet("vendas-estornadas")]
        public async Task<IActionResult> VendasEstornadas([FromQuery] DateTime? inicio, [FromQuery] DateTime? fim)
        {
            try
            {
                var resultado = await _service.VendasEstornadas(inicio, fim);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao gerar relatório de vendas estornadas.",
                    erro = ex.Message
                });
            }
        }
    }
}