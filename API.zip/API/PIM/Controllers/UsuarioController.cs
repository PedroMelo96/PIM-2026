﻿using Microsoft.AspNetCore.Mvc;
using PIM.DTOs;
using PIM.Models;
using PIM.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;

namespace PIM.Controllers
{
    [Authorize(Roles = "1")]

    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly UsuarioService _service;
        private readonly IConfiguration _configuration;

        public UsuarioController(UsuarioService service, IConfiguration configuration)
        {
            _service = service;
            _configuration = configuration;
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginDto login)
        {
            var usuario = await _service.Login(login);

            if (usuario == null)
            {
                return Unauthorized(new { mensagem = "Usuário ou senha inválidos." });
            }

            if (usuario.ativo != "S")
            {
                return Unauthorized(new { mensagem = "Usuário inativo." });
            }

            // ==========================================
            // LER A CHAVE DO APPSETTINGS
            // ==========================================
            var chaveJwt = _configuration.GetSection("Jwt:Key").Value ?? "K9mR2xT7vB4nQ8pL5zW1cD6hF3jA0sY2";
            var key = Encoding.ASCII.GetBytes(chaveJwt);

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, usuario.id_usuario.ToString()),
                    new Claim(ClaimTypes.Name, usuario.nome_usuario),
                    
                    // ==========================================
                    // ADICIONADO: Perfil do usuário para liberar acessos!
                    // ==========================================
                    new Claim(ClaimTypes.Role, usuario.id_perfil.ToString())
                }),
                Expires = DateTime.UtcNow.AddHours(8),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return Ok(new
            {
                mensagem = "Login realizado com sucesso.",
                token = tokenString,
                usuario = new
                {
                    id_usuario = usuario.id_usuario,
                    nome_usuario = usuario.nome_usuario,
                    usuario = usuario.usuario,
                    id_perfil = usuario.id_perfil,
                    ativo = usuario.ativo
                }
            });
        }

        // ==========================================
        // LISTAR USUÁRIOS
        // ==========================================

        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            var usuarios = await _service.Listar();
            return Ok(usuarios);
        }

        // ==========================================
        // CADASTRAR USUÁRIO
        // ==========================================

        [HttpPost]
        public async Task<IActionResult> Cadastrar(Usuario usuario)
        {
            try
            {
                // Extrai o ID do usuário que fez a requisição direto do Token JWT!
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Cadastrar(usuario, idUsuarioLogado);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // ALTERAR USUÁRIO
        // ==========================================

        [HttpPut("{id}")]
        public async Task<IActionResult> Alterar(int id, Usuario usuario)
        {
            try
            {
                // Extrai do token
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Alterar(id, usuario, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Usuário não encontrado." });
                }

                return Ok(new { mensagem = "Usuário alterado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // INATIVAR USUÁRIO
        // ==========================================

        [HttpPut("{id}/inativar")]
        public async Task<IActionResult> Inativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Inativar(id, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Usuário não encontrado." });
                }

                return Ok(new { mensagem = "Usuário inativado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        // ==========================================
        // ATIVAR USUÁRIO
        // ==========================================

        [HttpPut("{id}/ativar")]
        public async Task<IActionResult> Ativar(int id)
        {
            try
            {
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var resultado = await _service.Ativar(id, idUsuarioLogado);

                if (!resultado)
                {
                    return NotFound(new { mensagem = "Usuário não encontrado." });
                }

                return Ok(new { mensagem = "Usuário ativado com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }
    }
}