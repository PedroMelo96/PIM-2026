﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;
using System.Security.Claims; // Necessário para ler o ClaimTypes

namespace PIM.Controllers
{
    [Authorize(Roles = "1,2")]
    [ApiController]
    [Route("api/[controller]")]
    public class VendaController : ControllerBase
    {
        private readonly VendaService _service;

        public VendaController(VendaService service)
        {
            _service = service;
        }

        // ==========================================
        // LISTAR TODAS
        // ==========================================

        [HttpGet]
        public async Task<IActionResult> ListarTodas()
        {
            return Ok(await _service.ListarTodas());
        }

        // ==========================================
        // BUSCAR POR ID
        // ==========================================

        [HttpGet("{id}")]
        public async Task<IActionResult> BuscarPorId(int id)
        {
            var venda = await _service.BuscarPorId(id);

            if (venda == null)
            {
                return NotFound(new { mensagem = "Venda não encontrada." });
            }

            return Ok(venda);
        }

        // ==========================================
        // LISTAR VENDAS DO CAIXA
        // ==========================================

        [HttpGet("caixa/{idCaixa}")]
        public async Task<IActionResult> ListarPorCaixa(int idCaixa)
        {
            try
            {
                var vendas = await _service.ListarPorCaixa(idCaixa);
                return Ok(vendas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao buscar vendas do caixa.",
                    erro = ex.Message
                });
            }
        }

        // ==========================================
        // REALIZAR VENDA
        // ==========================================

        [HttpPost]
        public async Task<IActionResult> RealizarVenda([FromBody] Venda venda)
        {
            try
            {
                var idUsuarioClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);

                if (string.IsNullOrEmpty(idUsuarioClaim))
                {
                    return Unauthorized(new { mensagem = "Sessão inválida. Usuário não identificado no Token." });
                }

                // ========================================================
                // CORRIGIDO AQUI: Letra "I" maiúscula combinando com a sua classe Venda.cs
                // ========================================================
                venda.Id_usuario = int.Parse(idUsuarioClaim);

                var novaVenda = await _service.RealizarVenda(venda);

                return Ok(new
                {
                    mensagem = "Venda realizada com sucesso.",
                    venda = novaVenda
                });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro interno ao realizar venda.",
                    erro = ex.Message
                });
            }
        }

        // ==========================================
        // ESTORNAR VENDA
        // ==========================================

        [HttpPut("{id}/estornar")]
        // [Authorize(Roles = "1")] // <-- DESCOMENTE ESTA LINHA se quiser que SÓ O ADMIN (Role 1) possa estornar vendas
        public async Task<IActionResult> Estornar(int id)
        {
            try
            {
                // Extrai o ID do usuário diretamente do Token JWT!
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var sucesso = await _service.EstornarVenda(id, idUsuarioLogado);

                if (!sucesso)
                {
                    return NotFound(new { mensagem = "Venda não encontrada." });
                }

                return Ok(new { mensagem = "Venda estornada com sucesso e estoque restituído." });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao estornar venda.",
                    erro = ex.Message
                });
            }
        }
    }
}