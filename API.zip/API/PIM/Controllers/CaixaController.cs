﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Models;
using PIM.Services;
using System.Security.Claims;

namespace PIM.Controllers
{
    [Authorize(Roles = "1,2")] 
    [ApiController]
    [Route("api/[controller]")]
    public class CaixaController : ControllerBase
    {
        private readonly CaixaService _service;

        public CaixaController(CaixaService service)
        {
            _service = service;
        }

        // ==========================================
        // LISTAR TODOS
        // ==========================================

        [HttpGet]
        public async Task<IActionResult> ListarTodos()
        {
            return Ok(await _service.ListarTodos());
        }

        // ==========================================
        // BUSCAR POR ID
        // ==========================================

        [HttpGet("{id}")]
        public async Task<IActionResult> BuscarPorId(int id)
        {
            var caixa = await _service.BuscarPorId(id);

            if (caixa == null)
            {
                return NotFound(new { mensagem = "Caixa não encontrado." });
            }

            return Ok(caixa);
        }

        // ==========================================
        // BUSCAR CAIXA ABERTO DO USUÁRIO LOGADO
        // ==========================================

        [HttpGet("aberto")]
        public async Task<IActionResult> BuscarCaixaAberto()
        {
            // Pega o ID do usuário diretamente do Token JWT!
            var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            var caixa = await _service.BuscarCaixaAberto(idUsuarioLogado);

            if (caixa == null)
            {
                return NotFound(new { mensagem = "Nenhum caixa aberto encontrado." });
            }

            return Ok(caixa);
        }

        // ==========================================
        // ABRIR CAIXA
        // ==========================================

        [HttpPost("abrir")]
        public async Task<IActionResult> Abrir([FromBody] Caixa caixa)
        {
            try
            {
                // Garante que o caixa está sendo aberto pelo usuário autenticado
                var idUsuarioLogado = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                caixa.Id_usuario = idUsuarioLogado;

                var resultado = await _service.AbrirCaixa(caixa);

                return Ok(new
                {
                    mensagem = "Caixa aberto com sucesso.",
                    caixa = resultado
                });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro ao abrir caixa.",
                    erro = ex.Message
                });
            }
        }

        // ==========================================
        // FECHAR CAIXA
        // ==========================================

        [HttpPut("{id}/fechar")]
        public async Task<IActionResult> Fechar(int id, [FromBody] FecharCaixaRequest request)
        {
            try
            {
                var sucesso = await _service.FecharCaixa(id, request.Valor_fechamento);

                if (!sucesso)
                {
                    return NotFound(new { mensagem = "Caixa não encontrado." });
                }

                return Ok(new { mensagem = "Caixa fechado com sucesso." });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensagem = "Erro interno ao fechar o caixa.",
                    erro = ex.Message
                });
            }
        }
    }

    // ==========================================
    // REQUEST PARA FECHAR CAIXA (Agora fora do Controller)
    // ==========================================
    public class FecharCaixaRequest
    {
        public decimal Valor_fechamento { get; set; }
    }
}