﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PIM.Services;

namespace PIM.Controllers
{

    [Authorize(Roles = "1")]
    [ApiController]
    [Route("api/[controller]")]
    public class LogController : ControllerBase
    {
        private readonly LogService _service;

        public LogController(LogService service) => _service = service;

        // GET: api/Log
        [HttpGet]
        public async Task<IActionResult> ListarTodos()
        {
            var logs = await _service.ListarTodos();
            return Ok(logs);
        }
    }
}