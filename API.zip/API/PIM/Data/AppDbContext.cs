﻿using Microsoft.EntityFrameworkCore;
using PIM.Models;

namespace PIM.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // ==========================================
        // PRODUTOS
        // ==========================================

        public DbSet<Produto> Produto { get; set; }

        public DbSet<Classe> Classe { get; set; }


        // ==========================================
        // USUÁRIOS
        // ==========================================

        public DbSet<Usuario> Usuario { get; set; }

        public DbSet<Perfil> Perfil { get; set; }


        // ==========================================
        // ESTOQUE
        // ==========================================

        public DbSet<MovimentacaoEstoque> MovimentacoesEstoque { get; set; }


        // ==========================================
        // CAIXA
        // ==========================================

        public DbSet<Caixa> Caixas { get; set; }

        public DbSet<CaixaMovimentacao> CaixaMovimentacao { get; set; }


        // ==========================================
        // VENDAS
        // ==========================================

        public DbSet<Venda> Venda { get; set; }

        public DbSet<VendaItem> VendaItem { get; set; }

        public DbSet<VendaPagamento> VendaPagamento { get; set; }


        // ==========================================
        // FORMAS DE PAGAMENTO
        // ==========================================

        public DbSet<FormaPagamento> FormasPagamento { get; set; }


        // ==========================================
        // LOG
        // ==========================================

        public DbSet<Log> Log { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            // ==========================================
            // PRODUTO
            // ==========================================

            modelBuilder.Entity<Produto>()
                .ToTable("produto");

            modelBuilder.Entity<Produto>()
                .HasKey(p => p.id_produto);

            modelBuilder.Entity<Produto>()
                .Property(p => p.id_produto)
                .HasColumnName("id_produto")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<Produto>()
                .Property(p => p.nome_produto)
                .HasColumnName("nome_produto");

            modelBuilder.Entity<Produto>()
                .Property(p => p.barras)
                .HasColumnName("barras");

            modelBuilder.Entity<Produto>()
                .Property(p => p.estoque)
                .HasColumnName("estoque");

            modelBuilder.Entity<Produto>()
    .Property(p => p.id_classe)
    .HasColumnName("id_classe");

            modelBuilder.Entity<Produto>()
                .Property(p => p.valor_venda)
                .HasColumnName("valor_venda")
                .HasPrecision(12, 2);

            modelBuilder.Entity<Produto>()
                .Property(p => p.valor_compra)
                .HasColumnName("valor_compra")
                .HasPrecision(12, 2);

            modelBuilder.Entity<Produto>()
                .Property(p => p.estoque_minimo)
                .HasColumnName("estoque_minimo");

            modelBuilder.Entity<Produto>()
                .Property(p => p.ativo)
                .HasColumnName("ativo");


            // ==========================================
            // CLASSE
            // ==========================================

            modelBuilder.Entity<Classe>()
                .ToTable("classe");

            modelBuilder.Entity<Classe>()
                .HasKey(c => c.id_classe);


            // ==========================================
            // USUÁRIO
            // ==========================================

            modelBuilder.Entity<Usuario>()
                .ToTable("usuario");

            modelBuilder.Entity<Usuario>()
                .HasKey(u => u.id_usuario);


            // ==========================================
            // PERFIL
            // ==========================================

            modelBuilder.Entity<Perfil>()
                .ToTable("perfil");

            modelBuilder.Entity<Perfil>()
                .HasKey(p => p.id_perfil);


            // ==========================================
            // MOVIMENTAÇÃO DE ESTOQUE
            // ==========================================

            modelBuilder.Entity<MovimentacaoEstoque>()
                .ToTable("movimentacoes_estoque");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .HasKey(m => m.Id_movimentacao);

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Id_movimentacao)
                .HasColumnName("id_movimentacao")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Id_produto)
                .HasColumnName("id_produto");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Id_usuario)
                .HasColumnName("id_usuario");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Tipo)
                .HasColumnName("tipo");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Quantidade)
                .HasColumnName("quantidade");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Estoque_anterior)
                .HasColumnName("estoque_anterior");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Estoque_atual)
                .HasColumnName("estoque_atual");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Descricao)
                .HasColumnName("descricao");

            modelBuilder.Entity<MovimentacaoEstoque>()
                .Property(m => m.Data_movimentacao)
                .HasColumnName("data_movimentacao");


            // ==========================================
            // LOG
            // ==========================================

            modelBuilder.Entity<Log>()
                .ToTable("log");

            modelBuilder.Entity<Log>()
                .HasKey(l => l.Id_log);


            // ==========================================
            // CAIXA
            // ==========================================

            modelBuilder.Entity<Caixa>()
                .ToTable("caixa");

            modelBuilder.Entity<Caixa>()
                .HasKey(c => c.Id_caixa);

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Id_caixa)
                .HasColumnName("id_caixa")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Id_usuario)
                .HasColumnName("id_usuario");

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Data_abertura)
                .HasColumnName("data_abertura");

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Valor_abertura)
                .HasColumnName("valor_abertura")
                .HasPrecision(12, 2);

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Data_fechamento)
                .HasColumnName("data_fechamento");

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Valor_fechamento)
                .HasColumnName("valor_fechamento")
                .HasPrecision(12, 2);

            modelBuilder.Entity<Caixa>()
                .Property(c => c.Status)
                .HasColumnName("status");


            // ==========================================
            // MOVIMENTAÇÃO DO CAIXA
            // ==========================================

            modelBuilder.Entity<CaixaMovimentacao>()
                .ToTable("caixa_movimentacao");

            modelBuilder.Entity<CaixaMovimentacao>()
                .HasKey(c => c.Id_movimentacao);

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Id_movimentacao)
                .HasColumnName("id_movimentacao")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Id_caixa)
                .HasColumnName("id_caixa");

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Tipo)
                .HasColumnName("tipo");

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Descricao)
                .HasColumnName("descricao");

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Valor)
                .HasColumnName("valor")
                .HasPrecision(12, 2);

            modelBuilder.Entity<CaixaMovimentacao>()
                .Property(c => c.Data_movimentacao)
                .HasColumnName("data_movimentacao");


            // ==========================================
            // FORMAS DE PAGAMENTO
            // ==========================================

            modelBuilder.Entity<FormaPagamento>()
                .ToTable("formas_pagamento");

            modelBuilder.Entity<FormaPagamento>()
                .HasKey(f => f.Id_forma_pagamento);

            modelBuilder.Entity<FormaPagamento>()
                .Property(f => f.Id_forma_pagamento)
                .HasColumnName("id_forma_pagamento")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<FormaPagamento>()
                .Property(f => f.Nome_forma)
                .HasColumnName("nome_forma");


            // ==========================================
            // VENDA
            // ==========================================

            modelBuilder.Entity<Venda>()
                .ToTable("venda");

            modelBuilder.Entity<Venda>()
                .HasKey(v => v.Id_venda);

            modelBuilder.Entity<Venda>()
                .Property(v => v.Id_venda)
                .HasColumnName("id_venda")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<Venda>()
                .Property(v => v.Data_venda)
                .HasColumnName("data_venda");

            modelBuilder.Entity<Venda>()
                .Property(v => v.Id_usuario)
                .HasColumnName("id_usuario");

            modelBuilder.Entity<Venda>()
                .Property(v => v.Id_caixa)
                .HasColumnName("id_caixa");

            modelBuilder.Entity<Venda>()
                .Property(v => v.Valor_total)
                .HasColumnName("valor_total")
                .HasPrecision(12, 2);

            modelBuilder.Entity<Venda>()
                .Property(v => v.Status)
                .HasColumnName("status");


            // ==========================================
            // ITENS DA VENDA
            // ==========================================

            modelBuilder.Entity<VendaItem>()
                .ToTable("vendas_item");

            modelBuilder.Entity<VendaItem>()
                .HasKey(i => i.Id_item);

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Id_item)
                .HasColumnName("id_item")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Id_venda)
                .HasColumnName("id_venda");

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Id_produto)
                .HasColumnName("id_produto");

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Quantidade)
                .HasColumnName("quantidade");

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Valor_unitario)
                .HasColumnName("valor_unitario")
                .HasPrecision(12, 2);

            modelBuilder.Entity<VendaItem>()
                .Property(i => i.Valor_total)
                .HasColumnName("valor_total")
                .HasPrecision(12, 2);


            // ==========================================
            // PAGAMENTOS DA VENDA
            // ==========================================

            modelBuilder.Entity<VendaPagamento>()
                .ToTable("vendas_pagamento");

            modelBuilder.Entity<VendaPagamento>()
                .HasKey(p => p.Id_venda_pagamento);

            modelBuilder.Entity<VendaPagamento>()
                .Property(p => p.Id_venda_pagamento)
                .HasColumnName("id_venda_pagamento")
                .ValueGeneratedOnAdd();

            modelBuilder.Entity<VendaPagamento>()
                .Property(p => p.Id_venda)
                .HasColumnName("id_venda");

            modelBuilder.Entity<VendaPagamento>()
                .Property(p => p.Id_forma_pagamento)
                .HasColumnName("id_forma_pagamento");

            modelBuilder.Entity<VendaPagamento>()
                .Property(p => p.Valor)
                .HasColumnName("valor")
                .HasPrecision(12, 2);


            // ==========================================
            // RELACIONAMENTO CAIXA -> USUÁRIO
            // ==========================================

            modelBuilder.Entity<Caixa>()
                .HasOne<Usuario>()
                .WithMany()
                .HasForeignKey(c => c.Id_usuario);


            // ==========================================
            // RELACIONAMENTO MOVIMENTAÇÃO -> CAIXA
            // ==========================================

            modelBuilder.Entity<CaixaMovimentacao>()
                .HasOne<Caixa>()
                .WithMany()
                .HasForeignKey(c => c.Id_caixa);


            // ==========================================
            // RELACIONAMENTO VENDA -> USUÁRIO
            // ==========================================

            modelBuilder.Entity<Venda>()
                .HasOne<Usuario>()
                .WithMany()
                .HasForeignKey(v => v.Id_usuario);


            // ==========================================
            // RELACIONAMENTO VENDA -> CAIXA
            // ==========================================

            modelBuilder.Entity<Venda>()
                .HasOne<Caixa>()
                .WithMany()
                .HasForeignKey(v => v.Id_caixa);


            // ==========================================
            // VENDA -> ITENS
            // ==========================================

            modelBuilder.Entity<Venda>()
                .HasMany(v => v.Itens)
                .WithOne()
                .HasForeignKey(i => i.Id_venda)
                .OnDelete(DeleteBehavior.Cascade);


            // ==========================================
            // VENDA -> PAGAMENTOS
            // ==========================================

            modelBuilder.Entity<Venda>()
                .HasMany(v => v.Pagamentos)
                .WithOne()
                .HasForeignKey(p => p.Id_venda)
                .OnDelete(DeleteBehavior.Cascade);


            // ==========================================
            // ITEM -> PRODUTO
            // ==========================================

            modelBuilder.Entity<VendaItem>()
                .HasOne<Produto>()
                .WithMany()
                .HasForeignKey(i => i.Id_produto);


            // ==========================================
            // PAGAMENTO -> FORMA DE PAGAMENTO
            // ==========================================

            modelBuilder.Entity<VendaPagamento>()
                .HasOne<FormaPagamento>()
                .WithMany()
                .HasForeignKey(p => p.Id_forma_pagamento);
        }
    }
}